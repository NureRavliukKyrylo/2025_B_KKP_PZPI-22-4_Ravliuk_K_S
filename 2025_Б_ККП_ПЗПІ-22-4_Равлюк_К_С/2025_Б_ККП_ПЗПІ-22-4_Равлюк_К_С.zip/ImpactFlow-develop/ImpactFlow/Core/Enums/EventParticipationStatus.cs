﻿namespace Core.Enums
{
    public enum EventParticipationStatus
    {
        Pending,
        Accepted,
        Rejected,
        Cancelled,
        Completed
    }
}
