﻿namespace Core.Enums
{
    public enum ProjectSortingParams
    {
        Default = 0,
        Newest,
        TitleAsc,
        TitleDesc,
        EndingSoon
    }
}
