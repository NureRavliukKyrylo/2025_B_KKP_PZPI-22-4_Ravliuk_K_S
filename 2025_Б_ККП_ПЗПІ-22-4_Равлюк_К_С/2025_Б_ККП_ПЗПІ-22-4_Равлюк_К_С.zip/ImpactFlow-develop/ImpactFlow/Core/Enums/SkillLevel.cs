﻿namespace Core.Enums
{
    public enum SkillLevel
    {
        Beginner,
        Intermediate,
        Advanced,
        Expert
    }
}
