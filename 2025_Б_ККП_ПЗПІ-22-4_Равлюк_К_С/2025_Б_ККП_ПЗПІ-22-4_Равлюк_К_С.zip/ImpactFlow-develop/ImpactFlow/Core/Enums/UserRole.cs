﻿namespace Core.Enums
{
    public enum UserRole
    {
        Volunteer,
        Initiator,
        Admin
    }
}
