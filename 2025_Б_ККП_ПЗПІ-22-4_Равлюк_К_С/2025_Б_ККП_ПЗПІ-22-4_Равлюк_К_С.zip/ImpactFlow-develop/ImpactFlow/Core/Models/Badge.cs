﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Core.Models
{
    public class Badge
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = null!;

        [BsonElement("title")]
        public string Title { get; set; } = null!;

        [BsonElement("description")]
        [BsonIgnoreIfNull]
        public string? Description { get; set; }

        [BsonElement("iconUrl")]
        public string IconUrl { get; set; } = null!;

        [BsonElement("criteria")]
        public string Criteria { get; set; } // yмова отримання

        [BsonElement("isHidden")]
        public bool IsHidden { get; set; } = false; // "секретні" значки
    }
}
