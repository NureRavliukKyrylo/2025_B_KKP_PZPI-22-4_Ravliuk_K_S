﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Core.Models
{
    public class Project
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = null!;

        [BsonElement("title")]
        public string Title { get; set; } = null!;

        [BsonElement("description")]
        public string Description { get; set; } = null!;

        [BsonElement("createdAt")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [BsonElement("endAt")]
        public DateTime EndAt { get; set; } = DateTime.UtcNow.AddMonths(1);

        [BsonElement("ownerId")]
        public string OwnerId { get; set; } = null!;

        [BsonElement("volunteerIds")]
        public List<string> VolunteerIds { get; set; } = new();

        [BsonElement("locations")]
        public List<GeoLocation> Location { get; set; } = new();

        [BsonElement("categoryIds")]
        public List<string> CategoryIds { get; set; } = new();
    }
}
