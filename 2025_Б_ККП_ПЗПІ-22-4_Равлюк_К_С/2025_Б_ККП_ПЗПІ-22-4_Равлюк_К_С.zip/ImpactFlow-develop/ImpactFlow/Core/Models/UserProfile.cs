﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver.GeoJsonObjectModel;

namespace Core.Models
{
    [BsonIgnoreExtraElements]
    public class UserProfile
    {
        [BsonElement("bio")]
        public string? Bio { get; set; }

        [BsonElement("phone")]
        public string? Phone { get; set; }

        [BsonElement("dateOfBirth")]
        public DateTime? DateOfBirth { get; set; }

        [BsonElement("telegram")]
        public string? Telegram { get; set; }

        [BsonElement("coordinates")]
        [BsonIgnoreIfNull]
        public GeoJsonPoint<GeoJson2DGeographicCoordinates>? Coordinates { get; set; }

        [BsonElement("avatarUrl")]
        public string? AvatarUrl { get; set; }
    }
}
