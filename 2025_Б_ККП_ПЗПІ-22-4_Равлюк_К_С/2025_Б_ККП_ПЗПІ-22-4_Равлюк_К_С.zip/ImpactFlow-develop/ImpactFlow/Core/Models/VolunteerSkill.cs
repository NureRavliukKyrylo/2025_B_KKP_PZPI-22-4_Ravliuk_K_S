﻿using Core.Enums;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Core.Models
{
    public class VolunteerSkill
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = null!;

        [BsonElement("userId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string UserId { get; set; } = null!;

        [BsonElement("skillId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string SkillId { get; set; } = null!;

        [BsonElement("level")]
        [BsonRepresentation(BsonType.String)]
        public SkillLevel Level { get; set; } = SkillLevel.Beginner;

        [BsonElement("verified")]
        public bool Verified { get; set; } = false;

        [BsonElement("addedAt")]
        public DateTime AddedAt { get; set; } = DateTime.UtcNow;
    }
}
