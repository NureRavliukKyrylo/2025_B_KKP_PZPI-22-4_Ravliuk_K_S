﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Core.Models
{
    public class Review
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = null!;

        [BsonElement("fromUserId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string FromUserId { get; set; } = null!;

        [BsonElement("toUserId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string ToUserId { get; set; } = null!;

        [BsonElement("projectId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string ProjectId { get; set; }

        [BsonElement("eventId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? EventId { get; set; }

        [BsonElement("rating")]
        public int Rating { get; set; } // 1–5

        [BsonElement("comment")]
        public string? Comment { get; set; }

        [BsonElement("createdAt")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
