﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Core.Models
{
    public class Participation
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = null!;

        [BsonElement("projectId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string ProjectId { get; set; } = null!;

        [BsonElement("userId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string UserId { get; set; } = null!;

        [BsonElement("roleInProject")]
        [BsonIgnoreIfNull]
        public string? RoleInProject { get; set; }

        [BsonElement("joinDates")]
        public List<DateTime> JoinDates { get; set; } = new();

        [BsonElement("leaveDates")]
        [BsonIgnoreIfNull]
        public List<DateTime>? LeaveDates { get; set; } = new();
    }
}
