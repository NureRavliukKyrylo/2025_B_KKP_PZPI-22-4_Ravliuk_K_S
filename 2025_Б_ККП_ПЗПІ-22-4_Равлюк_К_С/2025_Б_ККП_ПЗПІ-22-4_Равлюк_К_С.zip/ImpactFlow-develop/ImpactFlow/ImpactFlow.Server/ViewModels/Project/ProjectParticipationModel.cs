﻿namespace ImpactFlow.Server.ViewModels.Project
{
    public class ProjectParticipationModel
    {
        public Core.Models.Project Project { get; set; } = null!;
        public Core.Models.Participation Participation { get; set; } = null!;
    }
}
