﻿using ImpactFlow.Server.ViewModels.LocationHelper;

namespace ImpactFlow.Server.ViewModels.Project
{
    public class CreateProjectModel
    {
        public string Title { get; set; } = null!;
        public string Description { get; set; } = null!;
        public DateTime? EndAt { get; set; }
        public List<SimpleGeoPoint> Location { get; set; } = new();
        public List<string> CategoryIds { get; set; } = new();
    }
}
