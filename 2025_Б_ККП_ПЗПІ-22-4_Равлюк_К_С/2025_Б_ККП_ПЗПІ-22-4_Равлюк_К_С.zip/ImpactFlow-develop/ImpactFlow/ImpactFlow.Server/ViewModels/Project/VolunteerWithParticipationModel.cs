﻿using ImpactFlow.Server.ViewModels.Participation;
using ImpactFlow.Server.ViewModels.User;

namespace ImpactFlow.Server.ViewModels.Project
{
    public class VolunteerWithParticipationModel
    {
        private UserModel _user = null!;

        public UserModel User
        {
            get
            {
                _user.Profile = null;
                return _user;
            }
            set => _user = value;
        }

        public ParticipationModel? Participation { get; set; }
    }
}
