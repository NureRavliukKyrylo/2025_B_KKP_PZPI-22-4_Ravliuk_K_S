﻿using Core.Models;
using ImpactFlow.Server.ViewModels.Category;
using ImpactFlow.Server.ViewModels.User;

namespace ImpactFlow.Server.ViewModels.Project
{
    public class ProjectFullDetailsModel
    {
        public string Id { get; set; } = null!;
        public string Title { get; set; } = null!;
        public string Description { get; set; } = null!;
        public DateTime CreatedAt { get; set; }
        public DateTime EndAt { get; set; }

        public UserModel Owner { get; set; } = null!;
        public List<VolunteerWithParticipationModel> Volunteers { get; set; } = new();
        public List<Core.Models.Category> Categories { get; set; } = new();
        public List<GeoLocation> Location { get; set; } = new();
    }
}
