﻿using System.ComponentModel.DataAnnotations;

namespace ImpactFlow.Server.ViewModels.AvailabilitySlot
{
    public class AvailabilitySlotModel
    {
        [Required]
        public DayOfWeek Day { get; set; }

        [Required]
        public TimeSpan Start { get; set; }

        [Required]
        public TimeSpan End { get; set; }

        public bool? IsAvailable { get; set; }
        public bool? IsRecurring { get; set; }
    }
}
