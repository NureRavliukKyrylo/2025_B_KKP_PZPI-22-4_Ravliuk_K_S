﻿namespace ImpactFlow.Server.ViewModels.Category
{
    public class CreateCategoryModel
    {
        public string Name { get; set; } = null!;
        public string? Description { get; set; }
    }
}
