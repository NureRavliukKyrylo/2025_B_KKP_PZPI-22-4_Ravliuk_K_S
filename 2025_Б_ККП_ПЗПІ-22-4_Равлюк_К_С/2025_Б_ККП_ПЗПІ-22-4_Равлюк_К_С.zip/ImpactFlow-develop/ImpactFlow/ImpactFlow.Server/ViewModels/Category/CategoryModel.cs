﻿namespace ImpactFlow.Server.ViewModels.Category
{
    public class CategoryModel
    {
        public string Id { get; set; } = null!;
        public string Name { get; set; } = null!;
        public string? Description { get; set; }
    }
}
