﻿namespace ImpactFlow.Server.ViewModels.Auth
{
    public class ForgotPasswordRequest
    {
        public string Email { get; set; } = null!;
    }
}
