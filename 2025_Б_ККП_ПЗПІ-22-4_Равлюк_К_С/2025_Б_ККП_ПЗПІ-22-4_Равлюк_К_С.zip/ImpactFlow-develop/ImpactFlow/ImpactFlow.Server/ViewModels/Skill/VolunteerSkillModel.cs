﻿using Core.Enums;

namespace ImpactFlow.Server.ViewModels.Skill
{
    public class VolunteerSkillModel
    {
        public string SkillId { get; set; } = null!;
        public SkillLevel Level { get; set; }
    }
}