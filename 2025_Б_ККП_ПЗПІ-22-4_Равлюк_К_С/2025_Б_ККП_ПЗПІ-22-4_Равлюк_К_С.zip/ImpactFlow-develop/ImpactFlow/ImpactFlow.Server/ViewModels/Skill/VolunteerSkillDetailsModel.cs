﻿using Core.Enums;

namespace ImpactFlow.Server.ViewModels.Skill
{
    public class VolunteerSkillDetailsModel
    {
        public string SkillId { get; set; } = null!;
        public string Name { get; set; } = null!;
        public string? Description { get; set; }
        public SkillLevel Level { get; set; }
        public bool Verified { get; set; }
    }
}
