﻿namespace ImpactFlow.Server.ViewModels.Skill
{
    public class CreateSkillModel
    {
        public string Name { get; set; } = null!;
        public string? Description { get; set; }
    }
}
