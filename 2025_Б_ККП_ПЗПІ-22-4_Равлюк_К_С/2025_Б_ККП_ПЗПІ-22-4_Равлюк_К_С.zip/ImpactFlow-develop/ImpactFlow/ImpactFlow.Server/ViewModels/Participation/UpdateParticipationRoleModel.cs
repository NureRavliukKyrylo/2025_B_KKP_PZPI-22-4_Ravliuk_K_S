﻿namespace ImpactFlow.Server.ViewModels.Participation
{
    public class UpdateParticipationRoleModel
    {
        public string ProjectId { get; set; } = null!;
        public string VolunteerId { get; set; } = null!;
        public string RoleInProject { get; set; } = null!;
    }
}
