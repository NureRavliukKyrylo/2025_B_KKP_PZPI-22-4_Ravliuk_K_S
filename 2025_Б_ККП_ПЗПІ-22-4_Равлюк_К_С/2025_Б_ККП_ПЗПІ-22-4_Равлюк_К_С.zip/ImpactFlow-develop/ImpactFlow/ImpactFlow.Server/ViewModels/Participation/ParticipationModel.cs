﻿namespace ImpactFlow.Server.ViewModels.Participation
{
    public class ParticipationModel
    {
        public string Id { get; set; } = null!;
        public string ProjectId { get; set; } = null!;
        public string UserId { get; set; } = null!;
        public string? RoleInProject { get; set; }
        public List<DateTime> JoinDates { get; set; } = new();
        public List<DateTime>? LeaveDates { get; set; }
    }
}
