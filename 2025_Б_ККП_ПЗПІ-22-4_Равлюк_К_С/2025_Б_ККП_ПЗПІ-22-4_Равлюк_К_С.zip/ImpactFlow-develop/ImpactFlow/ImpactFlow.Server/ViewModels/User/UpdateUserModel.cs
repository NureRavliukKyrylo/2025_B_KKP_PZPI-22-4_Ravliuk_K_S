﻿using System.ComponentModel.DataAnnotations;
using ImpactFlow.Server.ViewModels.AvailabilitySlot;
using ImpactFlow.Server.ViewModels.UserProfile;

namespace ImpactFlow.Server.ViewModels.User
{
    public class UpdateUserModel
    {
        [Required]
        [MaxLength(100)]
        public string FullName { get; set; } = null!;

        public string Email { get; set; } = null!;

        public UserProfileModel? Profile { get; set; }

        public List<AvailabilitySlotModel>? Availability { get; set; }
    }
}
