﻿using Core.Enums;
using ImpactFlow.Server.ViewModels.Skill;

namespace ImpactFlow.Server.ViewModels.User
{
    public class UserModel
    {
        public string Id { get; set; } = null!;
        public string FullName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public UserRole Role { get; set; } = UserRole.Volunteer;
        public DateTime RegisteredAt { get; set; } = DateTime.UtcNow;
        public Core.Models.UserProfile? Profile { get; set; }
        public List<Core.Models.AvailabilitySlot>? Availability { get; set; } = new();
        public List<VolunteerSkillDetailsModel> Skills { get; set; } = new();
    }
}
