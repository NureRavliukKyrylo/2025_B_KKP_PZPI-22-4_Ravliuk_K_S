﻿using System.ComponentModel.DataAnnotations;
using ImpactFlow.Server.ViewModels.LocationHelper;

namespace ImpactFlow.Server.ViewModels.UserProfile
{
    public class UserProfileModel
    {
        [MaxLength(500)]
        public string? Bio { get; set; }

        [Phone]
        public string? Phone { get; set; }

        [DataType(DataType.Date)]
        public DateTime? DateOfBirth { get; set; }

        [MaxLength(100)]
        public string? Telegram { get; set; }

        public SimpleGeoPoint? Coordinates { get; set; }
    }
}
