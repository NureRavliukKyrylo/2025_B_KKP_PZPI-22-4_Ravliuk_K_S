using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BLL.Interfaces;
using BLL.Services;
using Core.Configurations;
using Core.Enums;
using Core.Helpers;
using Core.Models;
using DAL.Repositories;
using ImpactFlow.Server.ViewModels.Auth;
using ImpactFlow.Server.ViewModels.Skill;
using ImpactFlow.Server.ViewModels.User;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace ImpactFlow.Server.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly UnitOfWork _unitOfWork;
    private readonly JwtTokenGenerator _jwtTokenGenerator;
    private readonly ILogger<AuthController> _logger;
    private readonly JwtSettings _jwtSettings;
    private readonly ISkillService _skillService;
    private readonly IEmailSender _emailSender;

    public AuthController(UnitOfWork unitOfWork, JwtTokenGenerator jwtTokenGenerator, ILogger<AuthController> logger, JwtSettings jwtSettings, ISkillService skillService, IEmailSender emailSender)
    {
        _unitOfWork = unitOfWork;
        _jwtTokenGenerator = jwtTokenGenerator;
        _logger = logger;
        _jwtSettings = jwtSettings;
        _skillService = skillService;
        _emailSender = emailSender;
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
        _logger.LogInformation("Attempt to register user with email: {Email}", request.Email);

        var existing = await _unitOfWork.Users.FindAsync(u => u.Email == request.Email);
        if (existing.Any())
        {
            _logger.LogWarning("Registration failed: user with email {Email} already exists", request.Email);
            return Conflict(new { error = "User with this email already exists." });
        }
        var user = new User();
        user.MapFrom(request);

        user.PasswordHash = PasswordHasher.HashPassword(request.Password);
        user.RegisteredAt = DateTime.UtcNow;
        user.Role = UserRole.Volunteer;

        await _unitOfWork.Users.AddAsync(user);

        _logger.LogInformation("User {Email} registered successfully with ID: {UserId}", user.Email, user.Id);

        var accessToken = _jwtTokenGenerator.GenerateToken(user, 15);
        var refreshToken = _jwtTokenGenerator.GenerateToken(user, 60 * 24 * 7);

        Response.Headers.Append("Authorization", $"Bearer {accessToken}");

        Response.Cookies.Append("access_token", accessToken, new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.None,
            Expires = DateTime.UtcNow.AddMinutes(15)
        });

        Response.Cookies.Append("refresh_token", refreshToken, new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.None,
            Expires = DateTime.UtcNow.AddDays(7)
        });

        return Ok(new AuthResponse
        {
            AccessToken = accessToken,
            RefreshToken = refreshToken,
            UserId = user.Id,
            FullName = user.FullName,
            Role = user.Role.ToString()
        });
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        _logger.LogInformation("Attempt to login with email: {Email}", request.Email);

        var users = await _unitOfWork.Users.FindAsync(u => u.Email == request.Email);
        var user = users.FirstOrDefault();

        if (user == null)
        {
            _logger.LogWarning("Login failed: user not found with email {Email}", request.Email);
            return BadRequest(new { error = "Invalid email or password" });
        }

        if (!PasswordHasher.VerifyPassword(request.Password, user.PasswordHash))
        {
            _logger.LogWarning("Login failed: invalid password for user {Email}", request.Email);
            return BadRequest(new { error = "Invalid email or password" });
        }

        var accessToken = _jwtTokenGenerator.GenerateToken(user, 15);
        var refreshToken = _jwtTokenGenerator.GenerateToken(user, 60 * 24 * 7);

        Response.Cookies.Append("access_token", accessToken, new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.None,
            Expires = DateTime.UtcNow.AddMinutes(15)
        });

        _logger.LogInformation("User {Email} logged in successfully", request.Email);

        Response.Cookies.Append("refresh_token", refreshToken, new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.None,
            Expires = DateTime.UtcNow.AddDays(7)
        });

        return Ok(new AuthResponse
        {
            AccessToken = accessToken,
            RefreshToken = refreshToken,
            UserId = user.Id,
            FullName = user.FullName,
            Role = user.Role.ToString(),
            AvatarUrl = user.Profile?.AvatarUrl,
            Latitude = user.Profile?.Coordinates?.Coordinates.Latitude,
            Longitude = user.Profile?.Coordinates?.Coordinates.Longitude
        });
    }

    [HttpPost("logout")]
    public IActionResult Logout()
    {
        Response.Cookies.Delete("access_token");
        Response.Cookies.Delete("refresh_token");
        return Ok(new { message = "Logout successful" });
    }

    [HttpGet("profile")]
    [Authorize]
    public async Task<IActionResult> GetCurrentUser()
    {
        _logger.LogInformation("Request to fetch current user profile initiated.");

        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        if (string.IsNullOrEmpty(userId))
        {
            _logger.LogWarning("Authorization failed: missing or invalid JWT claim 'NameIdentifier'.");
            return Unauthorized(new { error = "Unable to determine user identity." });
        }

        _logger.LogInformation("Extracted user ID from token: {UserId}", userId);

        var users = await _unitOfWork.Users.FindAsync(u => u.Id == userId);
        var user = users.FirstOrDefault();

        if (user is null)
        {
            _logger.LogWarning("User with ID {UserId} not found in database.", userId);
            return Unauthorized(new { error = "User not found." });
        }

        _logger.LogInformation("Successfully retrieved user profile for ID {UserId}. Returning user data.", user.Id);

        var viewModel = new UserModel();
        viewModel.MapFrom(user);

        var volunteerSkillsResult = await _skillService.GetSkillsForVolunteer(user.Id);
        if (volunteerSkillsResult.IsSuccessful)
        {
            var skillIds = volunteerSkillsResult.Data.Select(vs => vs.SkillId).ToList();
            var skillEntitiesResult = await _skillService.GetByPredicate(s => skillIds.Contains(s.Id));

            if (skillEntitiesResult.IsSuccessful)
            {
                var skillDict = skillEntitiesResult.Data.ToDictionary(s => s.Id);
                viewModel.Skills = volunteerSkillsResult.Data
                    .Select(vs => new VolunteerSkillDetailsModel
                    {
                        SkillId = vs.SkillId,
                        Name = skillDict[vs.SkillId].Name,
                        Description = skillDict[vs.SkillId].Description,
                        Level = vs.Level,
                        Verified = vs.Verified
                    })
                    .ToList();
            }
        }

        return Ok(viewModel);
    }

    [HttpGet("role")]
    [Authorize]
    public async Task<IActionResult> GetUserRole()
    {
        _logger.LogInformation("Getting current user role");

        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(userId))
        {
            _logger.LogWarning("Missing user ID in JWT token.");
            return Unauthorized(new { error = "User not authenticated." });
        }

        var users = await _unitOfWork.Users.FindAsync(u => u.Id == userId);
        var user = users.FirstOrDefault();

        if (user == null)
        {
            _logger.LogWarning("User not found for ID {UserId}", userId);
            return Unauthorized(new { error = "User not found." });
        }

        return Ok(new { role = user.Role.ToString() });
    }

    [HttpPost("refresh")]
    public async Task<IActionResult> Refresh()
    {
        var refreshToken = Request.Cookies["refresh_token"];

        if (string.IsNullOrEmpty(refreshToken))
            return Unauthorized(new { error = "Refresh token not found." });

        var tokenHandler = new JwtSecurityTokenHandler();
        var validationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidIssuer = _jwtSettings.Issuer,
            ValidAudience = _jwtSettings.Audience,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.SecretKey)),
            ClockSkew = TimeSpan.Zero
        };

        try
        {
            var principal = tokenHandler.ValidateToken(refreshToken, validationParameters, out var validatedToken);

            var jwtToken = validatedToken as JwtSecurityToken;

            if (jwtToken == null)
                return Unauthorized(new { error = "Invalid token format" });

            //var timeLeft = jwtToken.ValidTo - DateTime.UtcNow;
            //if (timeLeft > TimeSpan.FromMinutes(10))
            //{
            //    _logger.LogInformation("Refresh skipped: token still valid for {TimeLeft} min", timeLeft.TotalMinutes);
            //    return StatusCode(204);
            //}

            var userId = principal.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId is null)
                return Unauthorized(new { error = "Invalid refresh token" });

            var users = await _unitOfWork.Users.FindAsync(u => u.Id == userId);
            var user = users.FirstOrDefault();
            if (user == null)
                return Unauthorized(new { error = "User not found" });

            var newAccessToken = _jwtTokenGenerator.GenerateToken(user, 15);
            var newRefreshToken = _jwtTokenGenerator.GenerateToken(user, 60 * 24 * 7);

            Response.Cookies.Append("access_token", newAccessToken, new CookieOptions
            {
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.None,
                Expires = DateTime.UtcNow.AddMinutes(15)
            });

            Response.Cookies.Append("refresh_token", newRefreshToken, new CookieOptions
            {
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.None,
                Expires = DateTime.UtcNow.AddDays(7)
            });

            return Ok(new { message = "Token refreshed successfully" });
        }
        catch (SecurityTokenException)
        {
            return Unauthorized(new { error = "Invalid or expired refresh token" });
        }
        catch (Exception ex)
        {
            _logger.LogError("Error refreshing token: {Message}", ex.Message);
            return StatusCode(500, new { error = "Server error during token refresh" });
        }
    }

    [HttpPost("forgot-password")]
    public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordRequest request)
    {
        var users = await _unitOfWork.Users.FindAsync(u => u.Email == request.Email);
        var user = users.FirstOrDefault();

        if (user is null)
            return BadRequest(new { error = "User not found" });

        var tokenService = new PasswordResetTokenService(_jwtSettings);
        var token = tokenService.GenerateResetToken(user.Id);
        var resetLink = $"http://localhost:5173/reset-password?token={token}";

        try
        {
            await _emailSender.SendEmailAsync(
                user.Email,
                "Reset your ImpactFlow password",
                $"Hello {user.FullName},\n\nClick the link below to reset your password:\n\n{resetLink}\n\nThis link will expire in 15 minutes.\n\n- ImpactFlow Team"
            );
            _logger.LogInformation("Reset password email sent to {Email}", user.Email);
        }
        catch (Exception ex)
        {
            _logger.LogError("Failed to send reset email to {Email}: {Error}", user.Email, ex.Message);
            return StatusCode(500, new { error = "Failed to send reset email. Please try again later." });
        }

        return Ok(new { email = user.Email });
    }

    [HttpPost("reset-password")]
    public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequest request)
    {
        var tokenService = new PasswordResetTokenService(_jwtSettings);
        var principal = tokenService.ValidateToken(request.Token);

        if (principal == null)
            return BadRequest(new { error = "Invalid or expired token" });

        var userId = principal.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (userId == null)
            return BadRequest(new { error = "Invalid token payload" });

        var users = await _unitOfWork.Users.FindAsync(u => u.Id == userId);
        var user = users.FirstOrDefault();

        if (user == null)
            return BadRequest(new { error = "User not found" });

        user.PasswordHash = PasswordHasher.HashPassword(request.NewPassword);
        await _unitOfWork.Users.UpdateAsync(user.Id, user);

        return Ok(new { message = "Password updated successfully" });
    }

}
