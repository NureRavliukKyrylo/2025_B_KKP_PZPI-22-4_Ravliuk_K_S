﻿using BLL.Interfaces;
using Core.Helpers;
using Core.Models;
using ImpactFlow.Server.ViewModels.Category;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ImpactFlow.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class CategoriesController : ControllerBase
    {
        private readonly ILogger<CategoriesController> _logger;
        private readonly ICategoryService _categoryService;

        public CategoriesController(ILogger<CategoriesController> logger, ICategoryService categoryService)
        {
            _logger = logger;
            _categoryService = categoryService;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetAllCategories()
        {
            _logger.LogInformation("Attempting to retrieve all categories");

            var result = await _categoryService.GetAll();

            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve categories");
                return StatusCode(500, new { error = "Unable to retrieve categories" });
            }

            _logger.LogInformation("Successfully retrieved {Count} categories", result.Data?.Count ?? 0);
            return Ok(new { data = result.Data });
        }

        [HttpPost("create")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> CreateCategory([FromBody] CreateCategoryModel model)
        {
            _logger.LogInformation("Attempting to create a new category");

            if (!ModelState.IsValid)
            {
                _logger.LogError("Invalid category data received");
                return BadRequest(new { error = "Invalid category data" });
            }

            var category = new Category();
            category.MapFrom(model);

            var result = await _categoryService.CreateCategory(category);

            if (!result.IsSuccessful || string.IsNullOrEmpty(result.Data))
            {
                _logger.LogError("Failed to create category");
                return BadRequest(new { error = "Failed to create category" });
            }

            _logger.LogInformation("Successfully created category with ID {CategoryId}", result.Data);
            return CreatedAtAction(nameof(GetAllCategories), new { id = result.Data }, new { id = result.Data });
        }

        [HttpPut("update/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateCategory(string id, [FromBody] CreateCategoryModel model)
        {
            _logger.LogInformation("Attempting to update category with route ID {Id}", id);

            if (!ModelState.IsValid)
            {
                _logger.LogError("Invalid update model received");
                return BadRequest(new { error = "Invalid data for update" });
            }

            var category = new Category();
            category.MapFrom(model);
            category.Id = id;

            var result = await _categoryService.UpdateCategory(category);

            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to update category with ID {Id}", id);
                return NotFound(new { error = $"Category with ID {id} not found or update failed" });
            }

            _logger.LogInformation("Successfully updated category with ID {Id}", id);
            return Ok(new { message = "Category updated successfully" });
        }

        [HttpDelete("delete/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteCategoryІ(string id)
        {
            _logger.LogInformation("Attempting to delete category with ID {CategoryId}", id);

            var result = await _categoryService.DeleteCategory(id);

            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to delete category with ID {CategoryId}", id);
                return NotFound(new { error = $"Category with ID {id} not found or delete failed" });
            }

            _logger.LogInformation("Successfully deleted category with ID {CategoryId}", id);
            return Ok(new { message = "Category deleted successfully" });
        }
    }
}
