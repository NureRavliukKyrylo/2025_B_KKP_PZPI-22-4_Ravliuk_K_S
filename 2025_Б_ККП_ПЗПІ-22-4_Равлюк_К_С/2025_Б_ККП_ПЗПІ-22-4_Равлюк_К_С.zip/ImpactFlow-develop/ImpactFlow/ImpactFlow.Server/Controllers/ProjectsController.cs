﻿using System.Security.Claims;
using BLL.Interfaces;
using Core.Enums;
using Core.Helpers;
using Core.Models;
using ImpactFlow.Server.ViewModels.Participation;
using ImpactFlow.Server.ViewModels.Project;
using ImpactFlow.Server.ViewModels.User;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ImpactFlow.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProjectsController : ControllerBase
    {
        private readonly ILogger<ProjectsController> _logger;
        private readonly IProjectService _projectService;
        private readonly IUserService _userService;
        private readonly ICategoryService _categoryService;

        public ProjectsController(
            ILogger<ProjectsController> logger,
            IProjectService projectService,
            IUserService userService,
            ICategoryService categoryService)
        {
            _logger = logger;
            _projectService = projectService;
            _userService = userService;
            _categoryService = categoryService;
        }

        private string GetUserId() => User.FindFirstValue(ClaimTypes.NameIdentifier) ?? throw new UnauthorizedAccessException();

        private bool IsAdmin() => User.IsInRole("Admin");
        private bool IsInitiator() => User.IsInRole("Initiator");

        private bool IsOwner(Project project) => project.OwnerId == GetUserId();


        [HttpGet("{id}")]
        public async Task<IActionResult> GetProject(string id)
        {
            _logger.LogInformation("Getting project with ID {Id}", id);

            var projectResult = await _projectService.GetById(id);
            if (!projectResult.IsSuccessful || projectResult.Data == null)
            {
                _logger.LogError("Project with ID {Id} not found", id);
                return NotFound(new { error = "Project not found" });
            }

            var project = projectResult.Data;

            var ownerResult = await _userService.GetById(project.OwnerId);
            if (!ownerResult.IsSuccessful || ownerResult.Data == null)
            {
                _logger.LogError("Owner with ID {OwnerId} not found", project.OwnerId);
                return NotFound(new { error = "Owner not found" });
            }

            var ownerDto = new UserModel();
            ownerDto.MapFrom(ownerResult.Data);

            var participationListResult = await _projectService.GetAllParticipationsForProject(project.Id);
            var participations = participationListResult.Data ?? new List<Participation>();

            var volunteers = new List<VolunteerWithParticipationModel>();
            foreach (var volunteerId in project.VolunteerIds)
            {
                var volunteerResult = await _userService.GetById(volunteerId);
                if (volunteerResult.IsSuccessful && volunteerResult.Data != null)
                {
                    var volunteerDto = new UserModel();
                    volunteerDto.MapFrom(volunteerResult.Data);

                    var participation = participations.FirstOrDefault(p => p.UserId == volunteerId);

                    ParticipationModel? participationDto = null;
                    if (participation != null)
                    {
                        participationDto = new ParticipationModel();
                        participationDto.MapFrom(participation);
                    }

                    volunteers.Add(new VolunteerWithParticipationModel
                    {
                        User = volunteerDto,
                        Participation = participationDto
                    });
                }
            }

            var categoryDtos = new List<Category>();
            foreach (var categoryId in project.CategoryIds)
            {
                var categoryResult = await _categoryService.GetById(categoryId);
                if (categoryResult.IsSuccessful && categoryResult.Data != null)
                {
                    var categoryDto = new Category();
                    categoryDto.MapFrom(categoryResult.Data);
                    categoryDtos.Add(categoryDto);
                }
            }

            var detailed = new ProjectFullDetailsModel
            {
                Id = project.Id,
                Title = project.Title,
                Description = project.Description,
                CreatedAt = project.CreatedAt,
                EndAt = project.EndAt,
                Owner = ownerDto,
                Volunteers = volunteers,
                Categories = categoryDtos,
                Location = project.Location
            };

            _logger.LogInformation("Successfully retrieved full details for project {Id}", id);
            return Ok(new { data = detailed });
        }

        [HttpGet("my/list")]
        public async Task<IActionResult> GetMyProjects()
        {
            var userId = GetUserId();
            if (!IsAdmin() && !IsInitiator())
            {
                _logger.LogWarning("Access denied to retrieve own projects by user {UserId}", userId);
                return Forbid();
            }

            _logger.LogInformation("Getting projects for owner {OwnerId}", userId);

            var result = await _projectService.GetProjectsByOwner(userId);
            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve projects for owner {OwnerId}", userId);
                return StatusCode(500, new { error = "Failed to retrieve your projects" });
            }

            _logger.LogInformation("Successfully retrieved {Count} projects", result.Data.Count);
            return Ok(new { data = result.Data });
        }

        [HttpPost("create")]
        public async Task<IActionResult> CreateProject([FromBody] CreateProjectModel model)
        {
            _logger.LogInformation("Creating new project");

            if (!ModelState.IsValid)
            {
                _logger.LogError("Invalid model for project creation");
                return BadRequest(new { error = "Invalid data" });
            }

            var userId = GetUserId();
            if (!IsAdmin() && !IsInitiator())
            {
                _logger.LogWarning("Access denied to create project for user {UserId}", GetUserId());
                return Forbid();
            }

            foreach (var point in model.Location)
            {
                if (point.Latitude < -90 || point.Latitude > 90 || point.Longitude < -180 || point.Longitude > 180)
                {
                    _logger.LogWarning("Invalid coordinates: ({Lat}, {Lon})", point.Latitude, point.Longitude);
                    return BadRequest(new { error = "Invalid coordinates. Latitude must be between -90 and 90, longitude between -180 and 180." });
                }
            }

            var project = new Project();
            project.MapFrom(model);
            project.OwnerId = userId;

            project.Location = model.Location
                .Select(p => new GeoLocation
                {
                    Location = new MongoDB.Driver.GeoJsonObjectModel.GeoJsonPoint<MongoDB.Driver.GeoJsonObjectModel.GeoJson2DGeographicCoordinates>(
                        new MongoDB.Driver.GeoJsonObjectModel.GeoJson2DGeographicCoordinates(p.Longitude, p.Latitude))
                })
                .ToList();

            var result = await _projectService.CreateProject(project);
            if (!result.IsSuccessful || string.IsNullOrEmpty(result.Data))
            {
                _logger.LogError("Failed to create project");
                return BadRequest(new { error = "Failed to create project" });
            }

            _logger.LogInformation("Project created successfully with ID {Id}", result.Data);
            return Ok(new { id = result.Data });
        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateProject([FromBody] UpdateProjectModel model)
        {
            _logger.LogInformation("Updating project with ID {Id}", model.Id);

            if (!ModelState.IsValid)
            {
                _logger.LogError("Invalid model for project update");
                return BadRequest(new { error = "Invalid data" });
            }

            var existingProject = await _projectService.GetById(model.Id);
            if (!existingProject.IsSuccessful || existingProject.Data == null)
            {
                _logger.LogError("Project with ID {Id} not found", model.Id);
                return NotFound(new { error = "Project not found" });
            }

            if (!IsAdmin() && !IsOwner(existingProject.Data))
            {
                _logger.LogWarning("Access denied to update project {Id} by user {UserId}", model.Id, GetUserId());
                return Forbid();
            }

            foreach (var point in model.Location)
            {
                if (point.Latitude < -90 || point.Latitude > 90 || point.Longitude < -180 || point.Longitude > 180)
                {
                    _logger.LogWarning("Invalid coordinates: ({Lat}, {Lon})", point.Latitude, point.Longitude);
                    return BadRequest(new { error = "Invalid coordinates. Latitude must be between -90 and 90, longitude between -180 and 180." });
                }
            }

            existingProject.Data.MapFrom(model);

            existingProject.Data.Location = model.Location
                .Select(p => new GeoLocation
                {
                    Location = new MongoDB.Driver.GeoJsonObjectModel.GeoJsonPoint<MongoDB.Driver.GeoJsonObjectModel.GeoJson2DGeographicCoordinates>(
                        new MongoDB.Driver.GeoJsonObjectModel.GeoJson2DGeographicCoordinates(p.Longitude, p.Latitude))
                })
                .ToList();

            if (model.EndAt.HasValue)
            {
                if (model.EndAt.Value.Date < DateTime.UtcNow.Date)
                {
                    _logger.LogWarning("Invalid EndAt value {EndAt} for project {Id}", model.EndAt.Value, model.Id);
                    return BadRequest(new { error = "Дата завершення проєкту не може бути в минулому." });
                }

                existingProject.Data.EndAt = model.EndAt.Value;
            }

            var result = await _projectService.UpdateProject(existingProject.Data);

            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to update project with ID {Id}", model.Id);
                return BadRequest(new { error = "Failed to update project" });
            }

            _logger.LogInformation("Successfully updated project with ID {Id}", model.Id);
            return Ok(new { message = "Project updated successfully" });
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteProject(string id)
        {
            _logger.LogInformation("Deleting project with ID {Id}", id);

            var existingProject = await _projectService.GetById(id);
            if (!existingProject.IsSuccessful || existingProject.Data == null)
            {
                _logger.LogError("Project with ID {Id} not found", id);
                return NotFound(new { error = "Project not found" });
            }

            if (!IsAdmin() && !IsOwner(existingProject.Data))
            {
                _logger.LogWarning("Access denied to delete project {Id} by user {UserId}", id, GetUserId());
                return Forbid();
            }

            var result = await _projectService.DeleteProject(id);

            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to delete project with ID {Id}", id);
                return NotFound(new { error = "Failed to delete project" });
            }

            _logger.LogInformation("Project with ID {Id} deleted successfully", id);
            return Ok(new { message = "Project deleted successfully" });
        }

        [HttpGet("list")]
        [Authorize]
        public async Task<IActionResult> GetAllProjects([FromQuery] ProjectSortingParams orderBy = ProjectSortingParams.Default,
            [FromQuery] DateTime? endBefore = null,
            [FromQuery] List<string>? categoryIds = null,
            [FromQuery] double? radiusKm = null,
            [FromQuery] string? search = null)
        {
            var userId = GetUserId();
            _logger.LogInformation("Request to retrieve available projects for volunteer {UserId}", userId);

            var result = await _projectService.GetAllProjects(
                orderBy: orderBy,
                endBefore: endBefore,
                categoryIds: categoryIds,
                radiusKm: radiusKm,
                userId: userId,
                search: search
            );

            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve filtered projects for volunteer {UserId}", userId);

                if (result.ErrorCode == 400)
                    return BadRequest(new { error = "To retrive projects with radius firstly set your location in profile" });

                return StatusCode(500, new { error = "Failed to retrieve available projects" });
            }

            _logger.LogInformation("Returned {Count} filtered projects for volunteer {UserId}", result.Data.Count, userId);
            return Ok(new { data = result.Data });
        }

        [HttpPost("{projectId}/signup")]
        [Authorize(Roles = "Volunteer")]
        public async Task<IActionResult> SignUpForProject(string projectId)
        {
            var userId = GetUserId();
            _logger.LogInformation("User {UserId} attempting to sign up for project {ProjectId}", userId, projectId);

            var result = await _projectService.SignUpVolunteer(projectId, userId);

            if (!result.IsSuccessful)
            {
                _logger.LogWarning("Sign-up failed for user {UserId} to project {ProjectId}", userId, projectId);
                return BadRequest(new { error = "You are already signed up or project not found" });
            }

            _logger.LogInformation("User {UserId} successfully signed up for project {ProjectId}", userId, projectId);
            return Ok(new { message = "Signed up successfully" });
        }

        [HttpGet("enrolled")]
        [Authorize(Roles = "Volunteer")]
        public async Task<IActionResult> GetEnrolledProjects()
        {
            var userId = GetUserId();
            _logger.LogInformation("Retrieving enrolled projects for user {UserId}", userId);

            var result = await _projectService.GetEnrolledProjects(userId);
            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to get enrolled projects for user {UserId}", userId);
                return StatusCode(500, new { error = "Failed to retrieve enrolled projects" });
            }

            _logger.LogInformation("Successfully retrieved {Count} projects", result.Data.Count);
            return Ok(new { data = result.Data });
        }

        [HttpDelete("{projectId}/volunteers/{volunteerId}")]
        public async Task<IActionResult> RemoveVolunteerFromProject(string projectId, string volunteerId)
        {
            var currentUserId = GetUserId();
            var isAdmin = IsAdmin();

            _logger.LogInformation("Request to remove volunteer {VolunteerId} from project {ProjectId} by user {UserId}",
                volunteerId, projectId, currentUserId);

            var result = await _projectService.RemoveVolunteerFromProject(
                projectId: projectId,
                volunteerId: volunteerId,
                currentUserId: currentUserId,
                isAdmin: isAdmin
            );

            if (!result.IsSuccessful)
            {
                _logger.LogWarning("Failed to remove volunteer {VolunteerId} from project {ProjectId}", volunteerId, projectId);
                return Forbid();
            }

            _logger.LogInformation("Successfully removed volunteer {VolunteerId} from project {ProjectId}", volunteerId, projectId);
            return Ok(new { message = "Volunteer removed successfully" });
        }

        [HttpGet("participations/me")]
        [Authorize(Roles = "Volunteer")]
        public async Task<IActionResult> GetMyActiveProjectParticipation(
            [FromQuery] List<string>? categories = null,
            [FromQuery] DateTime? endBefore = null,
            [FromQuery] string? search = null)
        {
            var userId = GetUserId();
            _logger.LogInformation("Getting filtered participations for volunteer {UserId}", userId);

            var participationsResult = await _projectService.GetActiveParticipationsForUser(userId);
            if (!participationsResult.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve participations for user {UserId}", userId);
                return StatusCode(500, new { error = "Failed to retrieve participations" });
            }

            var projectIds = participationsResult.Data.Select(p => p.ProjectId).Distinct().ToList();
            var projectsResult = await _projectService.GetAllProjects();

            var matchedProjects = projectsResult.Data
                .Where(p => projectIds.Contains(p.Id))
                .Where(p => string.IsNullOrEmpty(search) || p.Title.Contains(search, StringComparison.OrdinalIgnoreCase))
                .Where(p => endBefore == null || p.EndAt <= endBefore.Value)
                .Where(p => categories == null || !categories.Any() || categories.All(id => p.CategoryIds.Contains(id)))
                .ToList();

            var combined = participationsResult.Data
                .Where(p => matchedProjects.Any(mp => mp.Id == p.ProjectId))
                .Select(p => new ProjectParticipationModel
                {
                    Project = matchedProjects.First(mp => mp.Id == p.ProjectId),
                    Participation = p
                })
                .ToList();

            _logger.LogInformation("Returning {Count} filtered participations for user {UserId}", combined.Count, userId);
            return Ok(new { data = combined });
        }


        [HttpGet("participations/as-owner")]
        [Authorize(Roles = "Initiator")]
        public async Task<IActionResult> GetOwnedProjectParticipations()
        {
            var ownerId = GetUserId();
            _logger.LogInformation("Getting active participations for owner {OwnerId}", ownerId);

            var participationsResult = await _projectService.GetActiveParticipationsForOwner(ownerId);

            if (!participationsResult.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve participations for owner {OwnerId}", ownerId);
                return StatusCode(500, new { error = "Failed to retrieve participations" });
            }

            var projectIds = participationsResult.Data.Select(p => p.ProjectId).Distinct().ToList();
            var projectsResult = await _projectService.GetAllProjects();
            var ownedProjects = projectsResult.Data.Where(p => projectIds.Contains(p.Id)).ToList();

            var combined = participationsResult.Data
                .Select(part => new ProjectParticipationModel
                {
                    Project = ownedProjects.FirstOrDefault(p => p.Id == part.ProjectId)!,
                    Participation = part
                })
                .Where(pp => pp.Project != null)
                .ToList();

            _logger.LogInformation("Returning {Count} project-participation pairs for owner {OwnerId}", combined.Count, ownerId);
            return Ok(new { data = combined });
        }

        [HttpGet("{projectId}/history/participations")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetProjectParticipationHistory(string projectId)
        {
            _logger.LogInformation("Admin requested full participation history for project {ProjectId}", projectId);

            var projectResult = await _projectService.GetById(projectId);
            if (!projectResult.IsSuccessful || projectResult.Data == null)
            {
                _logger.LogWarning("Project {ProjectId} not found", projectId);
                return NotFound(new { error = "Project not found" });
            }

            var participationsResult = await _projectService.GetAllParticipationsForProject(projectId);
            if (!participationsResult.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve participations for project {ProjectId}", projectId);
                return StatusCode(500, new { error = "Failed to retrieve participations" });
            }

            var combined = participationsResult.Data
                .Select(part => new ProjectParticipationModel
                {
                    Project = projectResult.Data,
                    Participation = part
                })
                .ToList();

            _logger.LogInformation("Successfully retrieved {Count} participation records for project {ProjectId}",
                combined.Count, projectId);

            return Ok(new { data = combined });
        }

        [HttpPut("participation/assign-role")]
        [Authorize]
        public async Task<IActionResult> AssignVolunteerRole([FromBody] UpdateParticipationRoleModel model)
        {
            var currentUserId = GetUserId();
            var isAdmin = IsAdmin();

            _logger.LogInformation("Request to assign role to volunteer {VolunteerId} in project {ProjectId}", model.VolunteerId, model.ProjectId);

            var result = await _projectService.UpdateParticipationRole(
                projectId: model.ProjectId,
                volunteerId: model.VolunteerId,
                newRole: model.RoleInProject,
                currentUserId: currentUserId,
                isAdmin: isAdmin);

            if (!result.IsSuccessful)
            {
                _logger.LogWarning("Failed to assign role to volunteer {VolunteerId} in project {ProjectId}", model.VolunteerId, model.ProjectId);
                return Forbid();
            }

            _logger.LogInformation("Successfully assigned role {Role} to volunteer {VolunteerId} in project {ProjectId}",
                model.RoleInProject, model.VolunteerId, model.ProjectId);

            return Ok(new { message = "Volunteer role assigned successfully" });
        }

        [HttpPut("{projectId}/leave")]
        [Authorize(Roles = "Volunteer")]
        public async Task<IActionResult> LeaveProject(string projectId)
        {
            var userId = GetUserId();
            _logger.LogInformation("User {UserId} requested to leave project {ProjectId}", userId, projectId);

            var result = await _projectService.LeaveProject(projectId, userId);

            if (!result.IsSuccessful)
            {
                _logger.LogWarning("Failed to leave project {ProjectId} for user {UserId}", projectId, userId);
                return BadRequest(new { error = "Failed to leave project or already left" });
            }

            _logger.LogInformation("User {UserId} successfully left project {ProjectId}", userId, projectId);
            return Ok(new { message = "You have left the project" });
        }
    }
}
