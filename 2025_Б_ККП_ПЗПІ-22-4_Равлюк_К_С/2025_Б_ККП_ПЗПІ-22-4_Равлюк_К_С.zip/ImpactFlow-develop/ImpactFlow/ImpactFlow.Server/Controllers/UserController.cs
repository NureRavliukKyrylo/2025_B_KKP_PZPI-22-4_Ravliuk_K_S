﻿using BLL.Interfaces;
using Core.Enums;
using Core.Helpers;
using Core.Models;
using ImpactFlow.Server.ViewModels.User;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver.GeoJsonObjectModel;

namespace ImpactFlow.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UserController : ControllerBase
    {
        private readonly ILogger<UserController> _logger;
        private readonly IUserService _userService;
        private readonly ISkillService _skillService;

        public UserController(ILogger<UserController> logger, IUserService userService, ISkillService skillService)
        {
            _logger = logger;
            _userService = userService;
            _skillService = skillService;
        }

        [HttpGet("get")]
        public async Task<IActionResult> GetUser()
        {
            _logger.LogInformation("Attempting to retrieve current user");

            var result = await _userService.GetUser();

            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve current user: user not found or service error");
                return BadRequest(new { error = "User not found" });
            }

            var user = result.Data;

            var volunteerSkillsResult = await _skillService.GetSkillsForVolunteer(user.Id);
            if (!volunteerSkillsResult.IsSuccessful)
            {
                _logger.LogError("Failed to get volunteer skills for user {UserId}", user.Id);
                return StatusCode(500, new { error = "Failed to load user skills" });
            }

            var skillIds = volunteerSkillsResult.Data.Select(vs => vs.SkillId).Distinct().ToList();
            var skillEntitiesResult = await _skillService.GetByPredicate(s => skillIds.Contains(s.Id));
            if (!skillEntitiesResult.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve skill details for user {UserId}", user.Id);
                return StatusCode(500, new { error = "Failed to retrieve skill details" });
            }

            var skillDict = skillEntitiesResult.Data.ToDictionary(s => s.Id);

            var skillModels = user.Skills
                .Where(s => skillDict.ContainsKey(s.SkillId))
                .Select(s => new
                {
                    Id = s.SkillId,
                    Name = skillDict[s.SkillId].Name,
                    Description = skillDict[s.SkillId].Description,
                    Level = s.Level
                })
                .ToList();

            _logger.LogInformation("Successfully retrieved current user with ID {UserId}", user.Id);

            return Ok(new
            {
                data = new
                {
                    user.Id,
                    user.FullName,
                    user.Email,
                    user.PasswordHash,
                    user.Role,
                    user.RegisteredAt,
                    profile = user.Profile == null ? null : new
                    {
                        user.Profile.Bio,
                        user.Profile.Phone,
                        user.Profile.Telegram,
                        dateOfBirth = user.Profile.DateOfBirth?.ToLocalTime().ToString("yyyy-MM-dd"),
                        user.Profile.Coordinates,
                        user.Profile.AvatarUrl
                    },
                    user.Availability,
                    Skills = skillModels
                }
            });
        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateUser([FromBody] UpdateUserModel model)
        {
            _logger.LogInformation("Attempting to update user");

            if (!ModelState.IsValid)
            {
                _logger.LogError("UpdateUser - received null user model");
                return BadRequest(new { error = "Invalid user data" });
            }

            var result = await _userService.GetUser();
            if (!result.IsSuccessful || result.Data == null)
            {
                _logger.LogError("UpdateUser - user not found");
                return NotFound(new { error = "User not found" });
            }

            var user = result.Data;
            user.MapFrom(model);

            if (model.Profile is not null)
            {
                user.Profile ??= new UserProfile();
                user.Profile.MapFrom(model.Profile);

                if (user.Profile.DateOfBirth.HasValue)
                {
                    user.Profile.DateOfBirth = DateTime.SpecifyKind(
                        user.Profile.DateOfBirth.Value.Date,
                        DateTimeKind.Utc
                    );
                }

                if (model.Profile.Coordinates != null)
                {
                    user.Profile.Coordinates = new GeoJsonPoint<GeoJson2DGeographicCoordinates>(
                        new GeoJson2DGeographicCoordinates(
                            model.Profile.Coordinates.Longitude,
                            model.Profile.Coordinates.Latitude));
                }
            }

            user.Availability = model.Availability?
                 .Select(a => new AvailabilitySlot
                 {
                     Day = a.Day,
                     Start = a.Start,
                     End = a.End,
                     IsAvailable = a.IsAvailable ?? true,
                     IsRecurring = a.IsRecurring ?? false
                 })
            .ToList() ?? new List<AvailabilitySlot>();

            var updateResult = await _userService.UpdateUser(user);

            if (!updateResult.IsSuccessful)
            {
                _logger.LogError("Failed to update user with ID {UserId}", user.Id);
                return BadRequest(new { error = "Failed to update user" });
            }

            _logger.LogInformation("Successfully updated user with ID {UserId}", user.Id);
            return Ok(new { message = "User updated successfully" });
        }

        [HttpDelete("delete")]
        public async Task<IActionResult> DeleteUser()
        {
            _logger.LogInformation("Attempting to delete current user's profile and availability");

            var result = await _userService.DeleteUser();

            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to delete current user's profile");
                return BadRequest(new { error = "Failed to delete user" });
            }

            _logger.LogInformation("Successfully deleted current user's profile and availability");
            return Ok(new { message = "User profile and availability deleted successfully" });
        }

        [HttpPost("avatar")]
        [RequestSizeLimit(2 * 1024 * 1024)] // 2 МБ
        public async Task<IActionResult> UploadAvatar(IFormFile avatar)
        {
            _logger.LogInformation("Uploading user avatar");

            if (avatar == null || avatar.Length == 0)
                return BadRequest("No file provided.");

            if (avatar.Length > 2 * 1024 * 1024)
                return BadRequest("File too large. Max 2MB allowed.");

            var allowedTypes = new[] { "image/jpeg", "image/png", "image/webp" };
            if (!allowedTypes.Contains(avatar.ContentType))
                return BadRequest("Invalid file type. Only PNG, JPEG and WEBP allowed.");

            var result = await _userService.UpdateUserAvatarAsync(avatar);

            if (!result.IsSuccessful || string.IsNullOrEmpty(result.Data))
            {
                _logger.LogError("Failed to upload avatar");
                return StatusCode(500, new { error = "Failed to upload avatar." });
            }

            return Ok(new { avatarUrl = result.Data });
        }

        [HttpPut("role")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ChangeUserRole([FromQuery] string userId, [FromQuery] UserRole role)
        {
            _logger.LogInformation("Admin attempts to change role of user {UserId} to {Role}", userId, role);

            var user = await _userService.GetById(userId);
            if (!user.IsSuccessful || user.Data == null)
            {
                return NotFound(new { error = "User not found" });
            }

            user.Data.Role = role;
            var update = await _userService.UpdateUser(user.Data);

            if (!update.IsSuccessful)
            {
                return StatusCode(500, new { error = "Failed to update role" });
            }

            return Ok(new { message = "Role updated successfully" });
        }

        [HttpGet("all")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllUsers([FromQuery] string? search = null)
        {
            try
            {
                _logger.LogInformation("Admin requested user list with search = {Search}", search);

                var result = string.IsNullOrWhiteSpace(search)
                    ? await _userService.GetAllUsers()
                    : await _userService.GetByPredicate(u => u.FullName.ToLower().Contains(search.ToLower()));

                if (!result.IsSuccessful)
                {
                    _logger.LogError("Failed to retrieve users from service");
                    return StatusCode(500, new { error = "Failed to retrieve users" });
                }

                return Ok(new { data = result.Data.Select(u => new { u.Id, u.FullName, u.Email, u.Role,u.Profile?.AvatarUrl }) });
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception in GetAllUsers: {Error}", ex.Message);
                return StatusCode(500, new { error = "Unexpected server error" });
            }
        }

        [HttpDelete("admin-delete")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteUserById([FromQuery] string userId)
        {
            _logger.LogInformation("Admin attempts to delete user {UserId}", userId);

            var result = await _userService.DeleteUserById(userId);

            if (!result.IsSuccessful)
            {
                return StatusCode(500, new { error = "Failed to delete user" });
            }

            return Ok(new { message = "User deleted successfully" });
        }

    }
}
