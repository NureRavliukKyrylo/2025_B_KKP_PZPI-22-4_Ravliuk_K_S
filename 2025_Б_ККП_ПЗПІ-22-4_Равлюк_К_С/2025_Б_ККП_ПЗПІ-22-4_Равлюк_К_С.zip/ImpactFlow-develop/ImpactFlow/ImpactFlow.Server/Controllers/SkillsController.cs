﻿using System.Security.Claims;
using BLL.Interfaces;
using Core.Enums;
using Core.Helpers;
using Core.Models;
using ImpactFlow.Server.ViewModels.Skill;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ImpactFlow.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class SkillsController : ControllerBase
    {
        private readonly ILogger<SkillsController> _logger;
        private readonly ISkillService _skillService;

        public SkillsController(ILogger<SkillsController> logger, ISkillService skillService)
        {
            _logger = logger;
            _skillService = skillService;
        }

        private string GetUserId() =>
            User.FindFirstValue(ClaimTypes.NameIdentifier) ?? throw new UnauthorizedAccessException();

        [HttpPost("create")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> CreateSkill([FromBody] CreateSkillModel model)
        {
            _logger.LogInformation("Creating new skill");

            if (!ModelState.IsValid)
            {
                _logger.LogError("Invalid skill creation model received");
                return BadRequest(new { error = "Invalid skill data" });
            }

            var skill = new Skill();
            skill.MapFrom(model);

            var result = await _skillService.CreateSkill(skill);
            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to create skill");
                return BadRequest(new { error = "Failed to create skill" });
            }

            _logger.LogInformation("Skill created successfully with ID {Id}", result.Data);
            return Ok(new { id = result.Data });
        }

        [HttpPut("update/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateSkill(string id, [FromBody] CreateSkillModel model)
        {
            _logger.LogInformation("Attempting to update skill with route ID {Id}", id);

            if (!ModelState.IsValid)
            {
                _logger.LogError("Invalid update model received");
                return BadRequest(new { error = "Invalid data for update" });
            }

            var existing = await _skillService.GetById(id);
            if (!existing.IsSuccessful || existing.Data == null)
            {
                _logger.LogError("Skill with ID {Id} not found", id);
                return NotFound(new { error = "Skill not found" });
            }

            var skill = new Skill();
            skill.MapFrom(model);
            skill.Id = id;

            var result = await _skillService.UpdateSkill(skill);

            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to update skill with ID {Id}", id);
                return NotFound(new { error = $"Skill with ID {id} not found or update failed" });
            }

            _logger.LogInformation("Successfully updated skill with ID {Id}", id);
            return Ok(new { message = "Skill updated successfully" });
        }

        [HttpDelete("delete/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteSkill(string id)
        {
            _logger.LogInformation("Deleting skill with ID {Id}", id);

            var existing = await _skillService.GetById(id);
            if (!existing.IsSuccessful || existing.Data == null)
            {
                _logger.LogError("Skill with ID {Id} not found", id);
                return NotFound(new { error = "Skill not found" });
            }

            var result = await _skillService.DeleteSkill(id);
            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to delete skill with ID {Id}", id);
                return NotFound(new { error = "Failed to delete skill" });
            }

            _logger.LogInformation("Skill with ID {Id} deleted successfully", id);
            return Ok(new { message = "Skill deleted successfully" });
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetAllSkills([FromQuery] string? search = null)
        {
            _logger.LogInformation("Retrieving skills{SearchInfo}", string.IsNullOrWhiteSpace(search) ? "" : $" with search = '{search}'");

            var result = await _skillService.GetAllSkills(search);
            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve skills");
                return StatusCode(500, new { error = "Unable to retrieve skills" });
            }

            _logger.LogInformation("Successfully retrieved {Count} skills", result.Data.Count);
            return Ok(new { data = result.Data });
        }

        [HttpPost("assign")]
        public async Task<IActionResult> AssignSkill([FromQuery] string skillId, [FromQuery] SkillLevel level)
        {
            var userId = GetUserId();
            _logger.LogInformation("User {UserId} assigns skill {SkillId} with level {Level}", userId, skillId, level);

            var skillExists = await _skillService.GetById(skillId);
            if (!skillExists.IsSuccessful || skillExists.Data == null)
            {
                _logger.LogError("Skill with ID {Id} not found", skillId);
                return NotFound(new { error = "Skill not found" });
            }

            var result = await _skillService.AddSkillToVolunteer(userId, skillId, level);
            if (!result.IsSuccessful)
            {
                _logger.LogWarning("Failed to assign skill {SkillId} to user {UserId}", skillId, userId);
                return BadRequest(new { error = "Failed to assign skill" });
            }

            _logger.LogInformation("Skill {SkillId} successfully assigned to user {UserId}", skillId, userId);
            return Ok(new { message = "Skill assigned successfully" });
        }

        [HttpPut("update-level")]
        public async Task<IActionResult> UpdateSkillLevel([FromBody] VolunteerSkillModel model)
        {
            var userId = GetUserId();
            _logger.LogInformation("User {UserId} updates skill {SkillId} level to {Level}", userId, model.SkillId, model.Level.ToString());

            var skillExists = await _skillService.GetById(model.SkillId);
            if (!skillExists.IsSuccessful || skillExists.Data == null)
            {
                _logger.LogError("Skill with ID {Id} not found", model.SkillId);
                return NotFound(new { error = "Skill not found" });
            }

            var result = await _skillService.UpdateVolunteerSkillLevel(userId, model.SkillId, model.Level);
            if (!result.IsSuccessful)
            {
                _logger.LogWarning("Failed to update skill level for user {UserId}", userId);
                return BadRequest(new { error = "Failed to update level" });
            }

            return Ok(new { message = "Skill level updated" });
        }

        [HttpPut("verify")]
        [Authorize(Roles = "Admin,Initiator")]
        public async Task<IActionResult> VerifySkill([FromQuery] string userId, [FromQuery] string skillId)
        {
            _logger.LogInformation("Verifying skill {SkillId} for user {UserId}", skillId, userId);

            var skillExists = await _skillService.GetById(skillId);
            if (!skillExists.IsSuccessful || skillExists.Data == null)
            {
                _logger.LogError("Skill with ID {Id} not found", skillId);
                return NotFound(new { error = "Skill not found" });
            }

            var result = await _skillService.VerifyVolunteerSkill(userId, skillId);
            if (!result.IsSuccessful)
            {
                _logger.LogWarning("Failed to verify skill {SkillId} for user {UserId}", skillId, userId);
                return BadRequest(new { error = "Failed to verify skill" });
            }

            return Ok(new { message = "Skill verified successfully" });
        }

        [HttpDelete("remove")]
        public async Task<IActionResult> RemoveSkill([FromQuery] string skillId)
        {
            var userId = GetUserId();
            _logger.LogInformation("Removing skill {SkillId} from user {UserId}", skillId, userId);

            var skillExists = await _skillService.GetById(skillId);
            if (!skillExists.IsSuccessful || skillExists.Data == null)
            {
                _logger.LogError("Skill with ID {Id} not found", skillId);
                return NotFound(new { error = "Skill not found" });
            }

            var result = await _skillService.RemoveVolunteerSkill(userId, skillId);
            if (!result.IsSuccessful)
            {
                _logger.LogWarning("Failed to remove skill {SkillId} from user {UserId}", skillId, userId);
                return BadRequest(new { error = "Failed to remove skill" });
            }

            return Ok(new { message = "Skill removed successfully" });
        }

        [HttpGet("my")]
        public async Task<IActionResult> GetMySkills()
        {
            var userId = GetUserId();
            _logger.LogInformation("Retrieving skills for user {UserId}", userId);

            var volunteerSkillsResult = await _skillService.GetSkillsForVolunteer(userId);
            if (!volunteerSkillsResult.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve skills for user {UserId}", userId);
                return StatusCode(500, new { error = "Failed to retrieve skills" });
            }

            var skillIds = volunteerSkillsResult.Data.Select(vs => vs.SkillId).Distinct().ToList();
            var skillModelsResult = await _skillService.GetByPredicate(s => skillIds.Contains(s.Id));

            if (!skillModelsResult.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve skill names for user {UserId}", userId);
                return StatusCode(500, new { error = "Failed to retrieve skill names" });
            }

            var skillDict = skillModelsResult.Data.ToDictionary(s => s.Id);

            var dtoList = volunteerSkillsResult.Data
                .Where(vs => skillDict.ContainsKey(vs.SkillId))
                .Select(vs => new VolunteerSkillDetailsModel
                {
                    SkillId = vs.SkillId,
                    Name = skillDict[vs.SkillId].Name,
                    Description = skillDict[vs.SkillId].Description,
                    Level = vs.Level,
                    Verified = vs.Verified
                })
                .ToList();

            _logger.LogInformation("Successfully returned {Count} skills for user {UserId}", dtoList.Count, userId);
            return Ok(new { data = dtoList });
        }

        [HttpGet("volunteers")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetVolunteersForSkill([FromQuery] string skillId)
        {
            _logger.LogInformation("Retrieving volunteers with skill {SkillId}", skillId);

            var skillExists = await _skillService.GetById(skillId);
            if (!skillExists.IsSuccessful || skillExists.Data == null)
            {
                _logger.LogError("Skill with ID {Id} not found", skillId);
                return NotFound(new { error = "Skill not found" });
            }

            var result = await _skillService.GetVolunteersWithSkill(skillId);
            if (!result.IsSuccessful)
            {
                _logger.LogError("Failed to retrieve volunteers with skill {SkillId}", skillId);
                return StatusCode(500, new { error = "Failed to retrieve volunteers" });
            }

            return Ok(new { data = result.Data });
        }
    }
}
