﻿namespace ImpactFlow.Server.Middlewares
{
    public class LogClaimsMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<LogClaimsMiddleware> _logger;

        public LogClaimsMiddleware(RequestDelegate next, ILogger<LogClaimsMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var path = context.Request.Path;

            if (path.StartsWithSegments("/api/auth", StringComparison.OrdinalIgnoreCase))
            {
                if (context.User?.Identity?.IsAuthenticated == true)
                {
                    _logger.LogInformation("[AuthClaims] {Method} {Path}", context.Request.Method, path);
                    foreach (var claim in context.User.Claims)
                    {
                        _logger.LogInformation("  - {Type}: {Value}", claim.Type, claim.Value);
                    }
                }
                else
                {
                    _logger.LogInformation("[AuthClaims] Unauthenticated request to {Path}", path);
                }
            }

            await _next(context);
        }
    }
}
