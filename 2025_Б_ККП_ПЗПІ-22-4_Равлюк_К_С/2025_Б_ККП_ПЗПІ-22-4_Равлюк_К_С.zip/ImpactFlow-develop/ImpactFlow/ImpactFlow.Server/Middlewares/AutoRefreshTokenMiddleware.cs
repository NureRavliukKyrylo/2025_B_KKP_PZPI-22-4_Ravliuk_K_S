﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Core.Helpers;
using DAL.Repositories;

namespace ImpactFlow.Server.Middlewares
{
    public class AutoRefreshTokenMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<AutoRefreshTokenMiddleware> _logger;
        private readonly JwtTokenGenerator _tokenGenerator;

        public AutoRefreshTokenMiddleware(
            RequestDelegate next,
            ILogger<AutoRefreshTokenMiddleware> logger,
            JwtTokenGenerator tokenGenerator)
        {
            _next = next;
            _logger = logger;
            _tokenGenerator = tokenGenerator;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var accessToken = context.Request.Cookies["access_token"];
            if (string.IsNullOrEmpty(accessToken))
            {
                await _next(context);
                return;
            }

            try
            {
                var handler = new JwtSecurityTokenHandler();
                var token = handler.ReadJwtToken(accessToken);
                var expires = token.ValidTo;

                if ((expires - DateTime.UtcNow) < TimeSpan.FromMinutes(5))
                {
                    var userId = token.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;

                    if (!string.IsNullOrEmpty(userId))
                    {
                        var unitOfWork = context.RequestServices.GetRequiredService<UnitOfWork>();

                        var user = (await unitOfWork.Users.FindAsync(u => u.Id == userId)).FirstOrDefault();
                        if (user != null)
                        {
                            var newToken = _tokenGenerator.GenerateToken(user, 15);
                            context.Response.Cookies.Append("access_token", newToken, new CookieOptions
                            {
                                HttpOnly = true,
                                Secure = true,
                                SameSite = SameSiteMode.Strict,
                                Expires = DateTime.UtcNow.AddMinutes(15)
                            });

                            _logger.LogInformation("Access token auto-refreshed for user {UserId}", userId);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning("Auto-refresh token skipped: {Message}", ex.Message);
            }

            await _next(context);
        }
    }
}
