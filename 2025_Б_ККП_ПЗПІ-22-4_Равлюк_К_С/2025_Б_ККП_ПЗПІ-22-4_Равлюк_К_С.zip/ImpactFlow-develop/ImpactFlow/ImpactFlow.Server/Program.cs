using System.Text;
using BLL.Interfaces;
using BLL.Services;
using Core.Configurations;
using Core.Helpers;
using Cyrillic.Convert;
using DAL.Context;
using DAL.Repositories;
using ImpactFlow.DAL.Settings;
using ImpactFlow.Server.Middlewares;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

namespace ImpactFlow.Server;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // ===== Controllers + JSON config =====
        builder.Services.AddControllers()
            .AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                options.SerializerSettings.Formatting = Newtonsoft.Json.Formatting.Indented;
            });

        // ===== Swagger =====
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "ImpactFlow API",
                Version = "v1",
                Description = "API for coordinating volunteer initiatives"
            });
        });

        // ===== CORS =====
        builder.Services.AddCors(options =>
        {
            options.AddPolicy("AllowFrontendApp", policy =>
            {
                policy.WithOrigins("http://localhost:5173")
                      .AllowAnyHeader()
                      .AllowAnyMethod()
                      .AllowCredentials();
            });
        });

        // ===== MongoDB Settings =====
        builder.Services.Configure<MongoDbSettings>(
            builder.Configuration.GetSection("MongoDbSettings"));

        // ===== JWT Settings =====
        builder.Services.Configure<JwtSettings>(
            builder.Configuration.GetSection("JwtSettings"));

        builder.Services.AddSingleton(sp =>
            sp.GetRequiredService<IOptions<JwtSettings>>().Value);

        // ===== AzureBlob Settings =====
        builder.Services.Configure<AzureBlobSettings>(
            builder.Configuration.GetSection("AzureBlobSettings"));

        // ===== DI for Repositories & Services =====
        builder.Services.AddScoped(typeof(IRepository<>), typeof(MongoRepository<>));
        builder.Services.AddScoped(typeof(UnitOfWork));
        builder.Services.AddScoped(typeof(Conversion));
        builder.Services.AddScoped<IAzureBlobService, AzureBlobService>();
        builder.Services.AddScoped<IUserService, UserService>();
        builder.Services.AddScoped<ICategoryService, CategoryService>();
        builder.Services.AddScoped<IProjectService, ProjectService>();
        builder.Services.AddScoped<ISkillService, SkillService>();

        builder.Services.Configure<EmailSettings>(builder.Configuration.GetSection("EmailSettings"));
        builder.Services.AddScoped<IEmailSender, SmtpEmailSender>();

        builder.Services.AddSingleton<MongoContext>();
        builder.Services.AddAutoMapper(typeof(Program));
        builder.Services.AddHttpContextAccessor();
        builder.Services.AddSingleton<JwtTokenGenerator>();
        builder.Services.AddAuthentication("Bearer")
        .AddJwtBearer("Bearer", options =>
        {
            var jwtSettings = builder.Configuration.GetSection("JwtSettings").Get<JwtSettings>();

            options.Events = new JwtBearerEvents
            {
                OnMessageReceived = context =>
                {
                    if (context.Request.Cookies.ContainsKey("access_token"))
                    {
                        context.Token = context.Request.Cookies["access_token"];
                    }

                    return Task.CompletedTask;
                }
            };

            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = jwtSettings.Issuer,

                ValidateAudience = true,
                ValidAudience = jwtSettings.Audience,

                ValidateLifetime = true,
                ClockSkew = TimeSpan.Zero,

                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(
                    Encoding.UTF8.GetBytes(jwtSettings.SecretKey))
            };
        });

        builder.Services.Configure<ApiBehaviorOptions>(options =>
        {
            options.InvalidModelStateResponseFactory = context =>
            {
                var errors = context.ModelState
                    .Where(e => e.Value.Errors.Count > 0)
                    .Select(e => e.Value.Errors.First().ErrorMessage)
                    .ToList();

                return new BadRequestObjectResult(new
                {
                    error = string.Join(" ", errors)
                });
            };
        });

        var app = builder.Build();

        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "ImpactFlow API");
                c.RoutePrefix = string.Empty; // відкривати Swagger як root page "/"
            });
        }

        app.UseHttpsRedirection();

        app.UseMiddleware<LogClaimsMiddleware>();
        app.UseMiddleware<AutoRefreshTokenMiddleware>();

        app.UseAuthentication();
        app.UseCors("AllowFrontendApp");
        app.UseAuthorization();

        app.MapControllers();

        app.Run();
    }
}
