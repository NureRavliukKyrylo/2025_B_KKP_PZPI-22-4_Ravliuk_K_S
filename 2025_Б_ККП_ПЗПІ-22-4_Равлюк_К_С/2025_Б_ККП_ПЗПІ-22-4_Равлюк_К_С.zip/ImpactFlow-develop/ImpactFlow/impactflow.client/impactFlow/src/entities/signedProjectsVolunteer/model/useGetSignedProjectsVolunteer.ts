import { useQuery } from "@tanstack/react-query";
import { useFilterStore } from "../../filter/store/filterStore";
import { getSignedProjectsVolunteer } from "../api/getSignedProjectsVolunteer";

export const useGetSignedProjectsVolunteer = () => {
  const { search, endDate, categories } = useFilterStore();

  const formattedEndDate = endDate
    ? `${endDate.getFullYear()}-${(endDate.getMonth() + 1)
        .toString()
        .padStart(2, "0")}-${endDate.getDate().toString().padStart(2, "0")}`
    : undefined;

  return useQuery({
    queryKey: ["signedProjectsVolunteer", search, formattedEndDate, categories],
    queryFn: () =>
      getSignedProjectsVolunteer({
        search,
        endDate: formattedEndDate,
        categories,
      }),
    staleTime: 1000 * 60 * 5,
    retry: false,
  });
};
