import type { UserData } from "../types/userTypes";
import { apiClient } from "../../../../shared/api";

export const getProfile = async (): Promise<UserData> => {
  const response = await apiClient.get<UserData>("Auth/profile");
  return response.data;
};
