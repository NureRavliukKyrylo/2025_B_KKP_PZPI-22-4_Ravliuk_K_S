import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { getMySkills } from "../api/getMySkills";
import type { SkillsVolunteer } from "../types/skillsTypes";

export const useGetMySkills = () => {
  const previousData = useRef<SkillsVolunteer[] | null>(null);

  const query = useQuery<SkillsVolunteer[]>({
    queryKey: ["mySkills"],
    queryFn: async () => {
      const data = await getMySkills();
      previousData.current = data;
      return data;
    },
    staleTime: 1000 * 60 * 5,
    retry: false,
  });

  const { data, isError, error } = query;
  console.log(data);
  useEffect(() => {
    if (isError && error) {
      console.error("Помилка завантаження skills:", error);
    }
  }, [isError, error]);

  return {
    ...query,
    data: query.data ?? previousData.current,
  };
};
