import { apiClient } from "../../../shared/api";
import type { UpdateProjectDto } from "../types/updateProjectTypes";

export const updateInitiative = async (data: UpdateProjectDto) => {
  const response = await apiClient.put<{ message: string }>(
    "Projects/update",
    data
  );
  return response.data;
};
