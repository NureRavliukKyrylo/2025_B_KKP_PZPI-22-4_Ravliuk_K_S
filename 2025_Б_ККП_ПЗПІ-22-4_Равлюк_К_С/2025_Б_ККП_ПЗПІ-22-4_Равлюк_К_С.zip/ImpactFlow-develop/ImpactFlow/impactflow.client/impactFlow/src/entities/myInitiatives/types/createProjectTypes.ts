export interface LocationPoint {
  latitude: number;
  longitude: number;
}

export interface CreateProjectDto {
  title: string;
  description: string;
  endAt: string;               
  location: LocationPoint[];   
  categoryIds: string[];      
}
