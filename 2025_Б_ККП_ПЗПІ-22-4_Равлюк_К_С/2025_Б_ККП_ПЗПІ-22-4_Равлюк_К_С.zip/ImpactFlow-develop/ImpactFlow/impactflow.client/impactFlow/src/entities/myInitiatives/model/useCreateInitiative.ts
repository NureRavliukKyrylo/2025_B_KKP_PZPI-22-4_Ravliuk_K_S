import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import type { CreateProjectDto } from "../types/createProjectTypes";
import { createInitiative } from "../api/createMyInitiativeApi";
import { useErrorStore } from "../../error";
import { useMessageStore } from "../../message/MessageStore";

export const useCreateInitiative = () => {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  return useMutation({
    mutationFn: (data: CreateProjectDto) => createInitiative(data),
    onSuccess: () => {
      clearError();
      setMessage("Initiative created successfully", "success");
      qc.invalidateQueries({ queryKey: ["initiatives", "list"] });
      qc.invalidateQueries({ queryKey: ["myInitiatives"] });
      navigate("/initiator-initiatives");
    },
    onError: (error: unknown) => {
      console.error("Create error:", error);
      setError("Failed to create initiative. Please check the data.");
      setMessage("Error while creating initiative", "error");
    },
  });
};
