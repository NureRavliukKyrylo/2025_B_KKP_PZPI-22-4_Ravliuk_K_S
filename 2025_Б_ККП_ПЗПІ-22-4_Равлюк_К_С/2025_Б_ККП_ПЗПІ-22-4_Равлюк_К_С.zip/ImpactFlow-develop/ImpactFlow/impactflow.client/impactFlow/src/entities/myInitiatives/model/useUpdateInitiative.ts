import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { updateInitiative } from "../api/updateMyInitiativeApi";
import { useErrorStore } from "../../error";
import { useMessageStore } from "../../message/MessageStore";
import type { UpdateProjectDto } from "../types/updateProjectTypes";

export const useUpdateInitiative = () => {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  return useMutation({
    mutationFn: (data: UpdateProjectDto) => updateInitiative(data),
    onSuccess: () => {
      clearError();
      setMessage("Initiative updated successfully", "success");
      qc.invalidateQueries({ queryKey: ["myInitiatives"] });
      qc.invalidateQueries({ queryKey: ["initiatives", "list"] });
      navigate("/initiator-initiatives");
    },
    onError: (error: unknown) => {
      console.error("Update error:", error);
      setError("Failed to update initiative.");
      setMessage("Error while updating initiative", "error");
    },
  });
};
