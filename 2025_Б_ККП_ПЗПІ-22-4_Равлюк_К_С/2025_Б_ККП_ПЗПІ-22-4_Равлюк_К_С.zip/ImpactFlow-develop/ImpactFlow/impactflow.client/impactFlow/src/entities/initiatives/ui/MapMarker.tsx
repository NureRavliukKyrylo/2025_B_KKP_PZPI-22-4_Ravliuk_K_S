import { Marker, Popup } from "react-leaflet";
import type { InitiativeMap } from "../types/InitiativeMapType";
import styles from "./MapMarker.module.scss";
import { Link } from "react-router-dom";
import { ProjectMarkerIcon } from "../../../shared/lib/map/map";

interface MapMarkerProps {
  markerInitiative: InitiativeMap;
}

export const MapMarker: React.FC<MapMarkerProps> = ({ markerInitiative }) => {
  const firstLoc = markerInitiative.location[0]?.location?.coordinates;
  if (!firstLoc) return null;

  return (
    <Marker
      key={markerInitiative.id}
      icon={ProjectMarkerIcon}
      position={[firstLoc.latitude, firstLoc.longitude]}
    >
      <Popup className={styles.customPopup}>
        <div className={styles.blockContentMarker}>
          <div className={styles.blockProjectInfo}>
            <h1 className={styles.mapMarkerTitle}>{markerInitiative.title}</h1>
            <h1 className={styles.mapMarkerDescription}>
              {markerInitiative.description}
            </h1>
          </div>
          <div className={styles.linkProjectBlock}>
            <Link
              to={`/initiatives/${markerInitiative.id}`}
              className={styles.redirectProjectInfo}
            >
              Project info
            </Link>
          </div>
        </div>
      </Popup>
    </Marker>
  );
};
