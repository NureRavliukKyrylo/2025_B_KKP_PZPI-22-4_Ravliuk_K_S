import React from "react";
import styles from "./UserProfile.module.scss";

import { levelMap } from "../../../skills/volunteer/types/skillsTypes";
import type { SkillsProfile } from "../types/userTypes";

interface SkillCardProps {
  skill: SkillsProfile;
}

export const SkillCard: React.FC<SkillCardProps> = ({ skill }) => {
  return (
    <div className={styles.skillItemProfile}>
      <div className={styles.skillItem}>
        <div className={styles.skillName}>
          {skill.name}({levelMap[skill.level]})
        </div>
      </div>
    </div>
  );
};
