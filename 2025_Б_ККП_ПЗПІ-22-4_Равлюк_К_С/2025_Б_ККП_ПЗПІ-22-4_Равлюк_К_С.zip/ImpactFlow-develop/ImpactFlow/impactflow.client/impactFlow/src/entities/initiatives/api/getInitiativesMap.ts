import type { InitiativeMapResponse } from "../types/InitiativeMapType";
import { apiClient } from "../../../shared/api";

interface Filters {
  endDate?: string;
  categories?: string[];
  radius?: string;
}

export const getInititativesMap = async (filters: Filters = {}) => {
  const params = new URLSearchParams();

  if (filters.radius) params.set("radiusKM", filters.radius.trim());
  if (filters.endDate) params.set("endBefore", filters.endDate);
  if (filters.categories && filters.categories.length > 0) {
    filters.categories.forEach((category) => {
      params.append("categoryIds", category);
    });
  }
  const response = await apiClient.get<InitiativeMapResponse>(
    `Projects/list?${params.toString()}`
  );
  return response.data.data;
};
