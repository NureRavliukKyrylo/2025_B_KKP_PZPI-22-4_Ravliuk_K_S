import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { getMyInitiatives } from "../api/myInitiativesApi";
import type { MyInitiative } from "../types/myInitiativesTypes";

export const useGetMyInitiatives = () => {
  const previousData = useRef<MyInitiative[] | null>(null);

  const query = useQuery<MyInitiative[]>({
    queryKey: ["myInitiatives"],
    queryFn: async () => {
      const data = await getMyInitiatives();
      previousData.current = data;
      return data;
    },
    staleTime: 1000 * 60 * 5, 
    retry: false,
  });

  const { data, isError, error } = query;

  useEffect(() => {
    if (isError && error) {
      console.error("Помилка при завантаженні власних ініціатив:", error);
    }
  }, [isError, error]);

  return {
    ...query,
    data: data ?? previousData.current ?? [],
  };
};
