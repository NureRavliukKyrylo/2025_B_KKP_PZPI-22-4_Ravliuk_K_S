export interface SkillsVolunteer {
  skillId: string;
  name: string;
  description: string;
  level: Level;
}

export interface SkillsProfile {
  name: string;
  description: string;
  level: Level;
}

export interface SkillsVolunteerResponse {
  data: SkillsVolunteer[];
}

export interface SkillsVolunteerDto {
  skillId: string;
  level: number;
}

export const levelMap = {
  0: "Beginner",
  1: "Intermediate",
  2: "Advanced",
  3: "Expert",
} as const;

export type Level = keyof typeof levelMap;
