import React from "react";
import type { UserDetails } from "../types/usersDetails";
import styles from "./UserItem.module.scss";
import { RoleMap } from "../../volunteer/types/userTypes";
import DefaultProfile from "../../../../shared/assets/default_profile.png";

interface Props {
  user: UserDetails;
  children?: React.ReactNode;
}

export const UserItem: React.FC<Props> = ({ user, children }) => {
  return (
    <div className={styles.userAdminCard}>
      <div className={styles.userImageBlock}>
        <img
          src={user.avatarUrl || DefaultProfile}
          alt="User Avatar"
          className={styles.userAvatar}
        />
      </div>
      <div className={styles.userInfoBlock}>
        <div className={styles.detailsUser}>
          <h1 className={styles.userFullName}>{user.fullName}</h1>
          <p className={styles.userRole}>{RoleMap[user?.role]}</p>
          <p className={styles.userEmail}>{user.email}</p>
        </div>
        <div className={styles.actionsBlock}>
          {children && (
            <div className={styles.actionsManageUser}>{children}</div>
          )}
        </div>
      </div>
    </div>
  );
};
