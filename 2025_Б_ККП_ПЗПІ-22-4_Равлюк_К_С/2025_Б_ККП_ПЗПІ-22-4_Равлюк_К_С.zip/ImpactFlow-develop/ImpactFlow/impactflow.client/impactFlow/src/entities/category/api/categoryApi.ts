import type { CategoryResponse } from "../types/categoryTypes";
import { apiClient } from "../../../shared/api";

export const getCategories = async () => {
  const response = await apiClient.get<CategoryResponse>("Categories/list");
  return response.data.data;
};
