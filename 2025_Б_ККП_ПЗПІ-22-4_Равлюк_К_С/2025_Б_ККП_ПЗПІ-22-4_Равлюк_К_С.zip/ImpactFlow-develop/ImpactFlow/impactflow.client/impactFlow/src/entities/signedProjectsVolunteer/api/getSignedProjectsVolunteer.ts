import type { ProjectInfo } from "../types/signedProjectsVolunteerTypes";
import { apiClient } from "../../../shared/api";

interface Filters {
  search?: string;
  endDate?: string;
  categories?: string[];
}

export const getSignedProjectsVolunteer = async (
  filters: Filters = {}
): Promise<ProjectInfo[]> => {
  const params = new URLSearchParams();

  if (filters.search) params.set("search", filters.search.trim());
  if (filters.endDate) params.set("endBefore", filters.endDate);
  if (filters.categories && filters.categories.length > 0) {
    filters.categories.forEach((category) => {
      params.append("categories", category);
    });
  }

  const response = await apiClient.get<{ data: any }>(
    `Projects/participations/me?${params.toString()}`
  );

  const rawProjects = response.data.data;
  console.log(rawProjects);
  return rawProjects.map((item: { project: ProjectInfo }) => {
    const coordinates = item.project.location?.[0]?.location?.coordinates;

    return {
      id: item.project.id,
      title: item.project.title,
      description: item.project.description,
      endAt: item.project.endAt,
      categoryIds: item.project.categoryIds,
      latitude: coordinates?.latitude,
      longitude: coordinates?.longitude,
    };
  });
};
