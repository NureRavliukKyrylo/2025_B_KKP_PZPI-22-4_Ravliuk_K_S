export interface InitiativeMap {
  id: string;
  title: string;
  description: string;
  location: Array<{
    location: {
      coordinates: {
        latitude: number;
        longitude: number;
      };
    };
  }>;
}

export interface InitiativeMapResponse {
  data: InitiativeMap[];
}
