import React from "react";
import { CategoryCheckBox } from "./CategoryCheckBox";
import styles from "./CategoryCheckBoxList.module.scss";
import { useFilterStore } from "../../filter/store/filterStore";
import type { Category as CategoryType } from "../types/categoryTypes";

interface CategoryCheckBoxListProps {
  categories: CategoryType[] | null;
}

export const CategoryCheckBoxList: React.FC<CategoryCheckBoxListProps> = ({
  categories,
}) => {
  const selectedCategories = useFilterStore((state) => state.categories);
  const toggleCategory = useFilterStore((state) => state.toggleCategory);

  return (
    <div className={styles.categoryCheckboxList}>
      {categories?.map((category) => (
        <CategoryCheckBox
          key={category.id}
          category={category}
          checked={selectedCategories.includes(category.name)}
          onChange={() => toggleCategory(category.name)}
        />
      ))}
    </div>
  );
};
