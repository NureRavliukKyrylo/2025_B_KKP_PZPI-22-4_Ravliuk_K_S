import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { getCategories } from "../api/categoryApi";
import type { Category } from "../types/categoryTypes";

export const useGetCategories = () => {
  const previousData = useRef<Category[] | null>(null);

  const query = useQuery<Category[]>({
    queryKey: ["categories"],
    queryFn: async () => {
      const data = await getCategories();
      previousData.current = data;
      return data;
    },
    staleTime: 1000 * 60 * 5,
    retry: false,
  });

  const { data, isError, error } = query;

  useEffect(() => {
    if (isError && error) {
      console.error("Помилка завантаження категорій:", error);
    }
  }, [isError, error]);

  return {
    ...query,
    data: query.data ?? previousData.current,
  };
};
