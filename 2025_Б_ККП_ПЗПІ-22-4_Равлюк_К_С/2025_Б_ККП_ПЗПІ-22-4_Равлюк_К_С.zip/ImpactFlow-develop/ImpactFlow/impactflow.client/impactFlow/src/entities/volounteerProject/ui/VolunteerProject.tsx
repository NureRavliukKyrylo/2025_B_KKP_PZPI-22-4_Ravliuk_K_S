import React from "react";
import type { VolunteerSummary } from "../types/volunteerProjectTypes";
import styles from "./VolunteerProject.module.scss";

interface Props {
  volunteer: VolunteerSummary;
  children?: React.ReactNode;
}

export const VolunteerProject: React.FC<Props> = ({ volunteer, children }) => {
  const { fullName } = volunteer;

  return (
    <div className={styles.volunteerProjectCard}>
      <h1>{fullName}</h1>
      {children && (
        <div className={styles.actionsVolunteerProject}>{children}</div>
      )}
    </div>
  );
};
