export interface Initiator {
  id: string;
  fullName: string;
  telegram?: string | null;
}

export interface Volunteer {
  id: string;
}

export interface InitiativeLocation {
  latitude: number;
  longitude: number;
}

export interface Initiative {
  id: string;
  title: string;
  description: string;
  initiator: Initiator;
  categories: string[];
  volunteers: Volunteer[];
  location?: InitiativeLocation;
  endAt: string;
}
