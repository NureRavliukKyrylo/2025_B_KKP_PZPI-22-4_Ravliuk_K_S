import { apiClient } from "../../../shared/api";
import type { Initiative } from "../types/initiativeTypes";

interface RawCategory {
  name: string;
}
interface RawProfile {
  telegram?: string;
}
interface RawOwner {
  id: string;
  fullName: string;
  profile?: RawProfile;
}
interface RawVolunteer {
  user: { id: string; fullName: string };
}
interface RawLocationWrapper {
  location: {
    coordinates: { longitude: number; latitude: number };
  };
}

interface RawInitiative {
  id: string;
  title: string;
  description: string;
  owner: RawOwner;
  categories?: RawCategory[];
  categoryIds?: string[];
  volunteers: RawVolunteer[];
  location: RawLocationWrapper[];
  endAt: string;
}

export const getInitiativeById = async (id: string): Promise<Initiative> => {
  const res = await apiClient.get<{ data: RawInitiative }>(`Projects/${id}`);
  const raw = res.data.data;

  console.log("RAW RESPONSE FROM API:", raw);

  let location: Initiative["location"] = undefined;
  if (raw.location?.length > 0) {
    const coords = raw.location[0].location.coordinates;
    location = {
      latitude: coords.latitude,
      longitude: coords.longitude,
    };
  }

  const rawTelegram = raw.owner.profile?.telegram ?? null;

  let categoryNames: string[] = [];

  if (raw.categoryIds?.length) {
    categoryNames = raw.categoryIds;
  } else if (raw.categories?.length) {
    categoryNames = raw.categories.map((c) => c.name);
  }

  console.log("Mapped categories:", categoryNames);

  return {
    id: raw.id,
    title: raw.title,
    description: raw.description,
    initiator: {
      id: raw.owner.id,
      fullName: raw.owner.fullName,
      telegram: rawTelegram,
    },
    categories: categoryNames,
    volunteers: raw.volunteers.map((v) => ({ id: v.user.id })),
    location,
    endAt: raw.endAt,
  };
};
