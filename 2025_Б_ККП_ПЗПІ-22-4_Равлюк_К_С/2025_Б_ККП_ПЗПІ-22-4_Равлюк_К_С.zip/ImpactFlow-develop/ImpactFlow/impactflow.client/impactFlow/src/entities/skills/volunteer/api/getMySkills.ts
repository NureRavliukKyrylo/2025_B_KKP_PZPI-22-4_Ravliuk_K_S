import type { SkillsVolunteerResponse } from "../types/skillsTypes";
import { apiClient } from "../../../../shared/api";

export const getMySkills = async () => {
  const response = await apiClient.get<SkillsVolunteerResponse>("Skills/my");
  return response.data.data;
};
