import type { Role } from "../../volunteer/types/userTypes";

export interface UserDetails {
  id: string;
  fullName: string;
  email: string;
  role: Role;
  avatarUrl: string;
}

export interface UserResponse {
  data: UserDetails[];
}

export interface ChangeRole {
  userId: string;
  role: number;
}
