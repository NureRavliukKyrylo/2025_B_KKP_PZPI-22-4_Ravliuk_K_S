import type { CreateProjectDto } from "./createProjectTypes";

export interface UpdateProjectDto extends CreateProjectDto {
  id: string;
}
