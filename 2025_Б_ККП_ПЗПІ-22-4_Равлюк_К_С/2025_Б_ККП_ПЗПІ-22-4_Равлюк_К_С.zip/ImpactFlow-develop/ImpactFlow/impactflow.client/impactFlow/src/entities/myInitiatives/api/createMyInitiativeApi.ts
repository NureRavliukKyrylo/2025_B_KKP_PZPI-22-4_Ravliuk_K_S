import { apiClient } from "../../../shared/api";
import type { CreateProjectDto } from "../types/createProjectTypes";

export const createInitiative = async (data: CreateProjectDto) => {
  const response = await apiClient.post<{ id: string }>("Projects/create", data);
  return response.data; 
};
