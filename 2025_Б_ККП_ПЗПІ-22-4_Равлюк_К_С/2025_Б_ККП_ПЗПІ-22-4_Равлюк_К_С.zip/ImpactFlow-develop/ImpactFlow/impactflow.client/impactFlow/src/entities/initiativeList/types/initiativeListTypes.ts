export interface Coordinates {
  latitude: number
  longitude: number
}

export interface LocationWrapper {
  location: {
    coordinates: Coordinates
  }
}

export interface InitiativeDto {
  id: string
  title: string
  description: string
  createdAt: string
  endAt: string
  ownerId: string
  volunteerIds: string[]
  location: LocationWrapper[]
  categoryIds: string[]
}

export type InitiativeListItem = InitiativeDto

export interface InitiativesListResponse {
  data: InitiativeDto[]
}
