import { useQuery } from "@tanstack/react-query";
import { apiClient } from "../../../shared/api";
import type {
  InitiativeDto,
  InitiativesListResponse,
} from "../types/initiativeListTypes";

const QUERY_KEY = ["initiatives", "list"];

export interface ListQueryParams {
  orderBy?: "Default" | "Newest" | "TitleAsc" | "TitleDesc" | "EndingSoon";
  endBefore?: string;
  categoryIds?: string[];
  radiusKm?: number;
  search?: string;
}

export function useGetInitiativesList(params?: ListQueryParams) {
  const prepared = params?.categoryIds?.length
    ? { ...params, categoryIds: params.categoryIds.join(",") }
    : params;

  return useQuery({
    queryKey: [...QUERY_KEY, prepared],
    queryFn: async () => {
      const { data } = await apiClient.get<InitiativesListResponse>(
        "Projects/list",
        { params: prepared }
      );
      return data.data as InitiativeDto[];
    },
  });
}
