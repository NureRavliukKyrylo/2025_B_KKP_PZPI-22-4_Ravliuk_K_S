import { useQuery } from "@tanstack/react-query";
import { getInitiativeById } from "../api/initiativeApi";
import type { Initiative } from "../types/initiativeTypes";

export const useGetInitiativeById = (id: string | undefined) =>
  useQuery<Initiative>({
    queryKey: ["initiative", id],
    enabled: Boolean(id),
    queryFn: () => getInitiativeById(id!),
    staleTime: 1000 * 60 * 5,
    retry: false,
  });
