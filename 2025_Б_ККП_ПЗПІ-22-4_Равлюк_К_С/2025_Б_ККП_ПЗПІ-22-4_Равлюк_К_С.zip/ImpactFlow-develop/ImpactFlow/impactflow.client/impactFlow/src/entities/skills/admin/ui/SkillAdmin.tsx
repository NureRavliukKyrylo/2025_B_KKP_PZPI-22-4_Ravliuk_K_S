import React from "react";
import type { Skills } from "../types/skillsTypes";
import styles from "./SkillAdmin.module.scss";

interface Props {
  skill: Skills;
  children?: React.ReactNode;
}

export const SkillAdmin: React.FC<Props> = ({ skill, children }) => {
  return (
    <div className={styles.skillCard}>
      <div className={styles.skillHeader}>
        <h1 className={styles.skillTitle}>{skill.name}</h1>
        <h1 className={styles.skillDescription}>{skill.description}</h1>
      </div>
      {children && <div className={styles.actionsManageSkill}>{children}</div>}
    </div>
  );
};
