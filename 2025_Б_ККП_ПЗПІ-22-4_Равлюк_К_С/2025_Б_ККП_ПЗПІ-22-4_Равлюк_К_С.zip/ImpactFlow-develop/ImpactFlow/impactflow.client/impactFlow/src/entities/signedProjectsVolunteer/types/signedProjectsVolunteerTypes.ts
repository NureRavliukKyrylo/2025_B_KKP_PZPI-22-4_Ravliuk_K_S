export interface ProjectInfo {
  id: string;
  title: string;
  description: string;
  endAt: string;
  categoryIds: string[];
  location: Array<{
    location: {
      coordinates: {
        latitude: number;
        longitude: number;
        values?: [number, number];
      };
    };
  }>;
  latitude?: number;
  longitude?: number;
}
