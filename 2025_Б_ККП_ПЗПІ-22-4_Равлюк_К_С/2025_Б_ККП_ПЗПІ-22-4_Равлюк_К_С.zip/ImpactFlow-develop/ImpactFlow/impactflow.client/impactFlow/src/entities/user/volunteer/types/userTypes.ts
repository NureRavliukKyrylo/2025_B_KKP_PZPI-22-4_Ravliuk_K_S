import type { Level } from "../../../skills/volunteer/types/skillsTypes";

export interface Profile {
  bio: string;
  phone: string;
  dateOfBirth: string;
  telegram: string;
  coordinates: {
    coordinates: {
      longitude: number;
      latitude: number;
    };
  };
  avatarUrl: string;
}

export interface UserData {
  id: string;
  fullName: string;
  email: string;
  role: Role;
  registeredAt: string;
  profile: Profile | null;
  skills: SkillsProfile[];
}

export interface SkillsProfile {
  name: string;
  level: Level;
}

export const RoleMap = {
  0: "Volunteer",
  1: "Initiator",
  2: "Admin",
} as const;

export type Role = keyof typeof RoleMap;
