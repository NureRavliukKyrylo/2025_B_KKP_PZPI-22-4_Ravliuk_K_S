export interface Coordinates {
  longitude: number;
  latitude: number;
}

export interface Geometry {
  coordinates: Coordinates;
  type: unknown;
  boundingBox: unknown | null;
  coordinateReferenceSystem: unknown | null;
  extraMembers: unknown | null;
}

export interface LocationWrapper {
  location: Geometry;
}

export interface MyInitiative {
  id: string;
  title: string;
  description: string;
  createdAt: string;
  endAt: string;    
  ownerId: string;
  volunteerIds: string[];
  location: LocationWrapper[];
  categoryIds: string[];
}
