import type { ProjectData } from "../types/volunteerProjectTypes";
import { apiClient } from "../../../shared/api";

export const getVolunteerProject = async (id: string): Promise<ProjectData> => {
  const response = await apiClient.get<{ data: any }>(`Projects/${id}`);

  const raw = response.data.data;

  const projectData: ProjectData = {
    id: raw.id,
    title: raw.title,
    volunteers: raw.volunteers.map((v: any) => ({
      id: v.user.id,
      fullName: v.user.fullName,
      roleInProject: v.participation.roleInProject,
    })),
  };

  return projectData;
};
