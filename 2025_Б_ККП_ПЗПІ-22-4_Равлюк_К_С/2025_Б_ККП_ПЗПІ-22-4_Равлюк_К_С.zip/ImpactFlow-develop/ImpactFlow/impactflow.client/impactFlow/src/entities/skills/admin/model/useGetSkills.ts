import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { getSkills } from "../api/skillsApi";
import type { Skills } from "../types/skillsTypes";
import { useFilterStore } from "../../../filter/store/filterStore";

export const useGetSkills = () => {
  const { search } = useFilterStore();
  const previousData = useRef<Skills[] | null>(null);

  const query = useQuery<Skills[]>({
    queryKey: ["skillsAdmin", search],
    queryFn: async () => {
      const data = await getSkills(search);
      previousData.current = data;
      return data;
    },
    staleTime: 1000 * 60 * 5,
    retry: false,
  });

  const { data, isError, error } = query;
  console.log(data);
  useEffect(() => {
    if (isError && error) {
      console.error("Помилка завантаження skills:", error);
    }
  }, [isError, error]);

  return {
    ...query,
    data: query.data ?? previousData.current,
  };
};
