import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { getAllUsers } from "../api/usersAllApi";
import type { UserDetails } from "../types/usersDetails";
import { useFilterStore } from "../../../filter/store/filterStore";

export const useGetAllUsers = () => {
  const previousData = useRef<UserDetails[] | null>(null);
  const { search } = useFilterStore();

  const query = useQuery<UserDetails[]>({
    queryKey: ["usersAdmin", search],
    queryFn: async () => {
      const data = await getAllUsers(search);
      previousData.current = data;
      return data;
    },
    staleTime: 1000 * 60 * 5,
    retry: false,
  });

  const { data, isError, error } = query;

  useEffect(() => {
    if (isError && error) {
      console.error("Помилка завантаження категорій:", error);
    }
  }, [isError, error]);

  return {
    ...query,
    data: query.data ?? previousData.current,
  };
};
