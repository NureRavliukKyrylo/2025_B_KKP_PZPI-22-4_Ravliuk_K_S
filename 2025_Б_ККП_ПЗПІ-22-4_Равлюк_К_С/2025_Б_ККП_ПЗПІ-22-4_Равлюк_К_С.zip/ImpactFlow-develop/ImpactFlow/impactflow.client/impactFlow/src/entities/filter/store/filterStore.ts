import { create } from "zustand"

export type OrderBy =
  | "Default"
  | "Newest"
  | "TitleAsc"
  | "TitleDesc"
  | "EndingSoon"

interface FilterState {
  search: string
  endDate: Date | null
  categories: string[]
  radius: string
  orderBy: OrderBy
  setSearch: (v: string) => void
  setEndDate: (v: Date | null) => void
  setCategories: (v: string[]) => void
  toggleCategory: (id: string) => void
  setRadius: (v: string) => void
  setOrderBy: (v: OrderBy) => void
}

export const useFilterStore = create<FilterState>((set) => ({
  search: "",
  endDate: null,
  categories: [],
  radius: "",
  orderBy: "Default",

  setSearch: (search) => {
    set({ search })
    syncToUrl({ search })
  },

  setEndDate: (endDate) => {
    set({ endDate })
    syncToUrl({ endDate })
  },

  setCategories: (categories) => {
    set({ categories })
    syncToUrl({ categories })
  },

  toggleCategory: (id) =>
    set((state) => {
      const categories = state.categories.includes(id)
        ? state.categories.filter((c) => c !== id)
        : [...state.categories, id]
      syncToUrl({ categories })
      return { categories }
    }),

  setRadius: (radius) => {
    set({ radius })
    syncToUrl({ radius })
  },

  setOrderBy: (orderBy) => {
    set({ orderBy })
    syncToUrl({ orderBy })
  },
}))

export const hydrateFromUrl = () => {
  const p = new URLSearchParams(window.location.search)
  const search = p.get("search") ?? ""
  const radius = p.get("radius") ?? ""
  const orderBy = (p.get("orderBy") ?? "Default") as OrderBy
  const endDateStr = p.get("endDate")
  const categoriesStr = p.get("categories")

  useFilterStore.setState({
    search,
    radius,
    orderBy,
    endDate: endDateStr ? new Date(endDateStr) : null,
    categories: categoriesStr ? categoriesStr.split(",") : [],
  })
}

const syncToUrl = (patch?: Partial<FilterState>) => {
  const { search, endDate, categories, radius, orderBy } = {
    ...useFilterStore.getState(),
    ...patch,
  }

  const p = new URLSearchParams()

  if (search.trim()) p.set("search", search.trim())
  if (endDate) {
    const d = endDate
    p.set(
      "endDate",
      `${d.getFullYear()}-${(d.getMonth() + 1)
        .toString()
        .padStart(2, "0")}-${d.getDate().toString().padStart(2, "0")}`,
    )
  }
  if (categories.length) p.set("categories", categories.join(","))
  if (radius.trim()) p.set("radius", radius.trim())
  if (orderBy !== "Default") p.set("orderBy", orderBy)

  const url = `${window.location.pathname}?${p.toString()}${window.location.hash}`
  window.history.replaceState(null, "", url)
}
