import { apiClient } from "../../../shared/api";

export const deleteInitiative = async (id: string) => {
  const response = await apiClient.delete<{ message: string }>(
    `Projects/delete/${id}`
  );
  return response.data;
};
