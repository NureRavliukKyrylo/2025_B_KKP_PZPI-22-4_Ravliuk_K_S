export interface Skills {
  id: string;
  name: string;
  description: string;
}

export interface SkillsResponse {
  data: Skills[];
}

export interface SkillsDto {
  name: string;
  description: string;
}
