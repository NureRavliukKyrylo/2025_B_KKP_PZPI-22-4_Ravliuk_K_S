import React from "react";
import DefaultProfile from "../../../../shared/assets/default_profile.png";
import styles from "./UserProfile.module.scss";
import TelegramLink from "../../../../shared/assets/telegram.png";
import { Link } from "react-router-dom";
import { BaseButton } from "../../../../shared/buttons/base/BaseButton";
import { SkillCard } from "./SkillCardBlock";
import { RoleMap } from "../types/userTypes";
import type { UserData } from "../types/userTypes";

interface UserProfileProps {
  user: UserData | null;
}
export const UserProfile: React.FC<UserProfileProps> = ({ user }) => {
  const profile = user?.profile;

  return (
    <div className={styles.userProfileInfo}>
      <div className={styles.profileAvatar}>
        <img
          src={profile?.avatarUrl || DefaultProfile}
          alt="User Avatar"
          className={styles.profileAvatarPic}
        />
        <Link to="edit" className={styles.toEdit}>
          <BaseButton label="Edit Profile"></BaseButton>
        </Link>
      </div>
      <div className={styles.dividerProfile}>
        <div className={styles.lineDivider}></div>
      </div>
      <div className={styles.textInfo}>
        <div className={styles.nameContainer}>
          <h1>{user?.fullName}</h1>
        </div>
        <div className={styles.emailContainer}>
          <h1>{user?.email}</h1>
        </div>
        <div className={styles.roleUser}>
          <h1>{user?.role != null ? RoleMap[user.role] : "Unknown Role"}</h1>
        </div>
        <div className={styles.phoneContainer}>
          <h1>{profile?.phone || "Unknown"}</h1>
          <a href={profile?.telegram} target="_blank" rel="noopener noreferrer">
            <img
              src={TelegramLink}
              className={styles.telegramLinkPic}
              alt="Telegram"
            />
          </a>
        </div>
        <div className={styles.bioContainer}>
          <h1>{profile?.bio || "Unknown"}</h1>
        </div>
        <div className={styles.cityContainer}>
          <h1>
            {profile?.coordinates?.coordinates?.latitude?.toFixed(5) ||
              "Unknown"}
            ,
            {profile?.coordinates?.coordinates?.longitude?.toFixed(5) ||
              "Unknown"}
          </h1>
        </div>
        <div className={styles.skillsContainer}>
          <div className={styles.skillsTitle}>Skills</div>
          <div className={styles.skillBlockProfile}>
            {user?.skills.length ? (
              user?.skills.map((skill, index) => (
                <SkillCard key={index} skill={skill} />
              ))
            ) : (
              <h1 className={styles.noSkillsProfile}>No skills added yet</h1>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
