import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import { userMarkerIcon } from "../../../shared/lib/map/map";
import "leaflet/dist/leaflet.css";
import { useEffect, useState } from "react";
import { useProfileStore } from "../../user/volunteer/types/profileAvatarStore";
import type { InitiativeMap } from "../../initiatives/types/InitiativeMapType";
import { MapZoomAnimation } from "../../../shared/lib/map/ZoomAnimation";
import { MapMarker } from "../../initiatives/ui/MapMarker";
import MarkerClusterGroup from "react-leaflet-cluster";
import styles from "./InteractiveMap.module.scss";

type Position = { lat: number; lng: number };
const defaultPosition: Position = { lat: 50.4501, lng: 30.5234 };

interface Props {
  initiatives: InitiativeMap[];
}
export const InteractiveMap: React.FC<Props> = ({ initiatives }) => {
  const { latitude, longitude, setLatitude, setLongitude } = useProfileStore();

  const [position, setPosition] = useState<Position>(defaultPosition);

  useEffect(() => {
    if (latitude !== null && longitude !== null) {
      setPosition({ lat: latitude, lng: longitude });
    } else {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const coords: Position = {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          };
          setPosition(coords);
          setLatitude(pos.coords.latitude);
          setLongitude(pos.coords.longitude);
        },
        () => {
          setPosition(defaultPosition);
        }
      );
    }
  }, [latitude, longitude, setLatitude, setLongitude]);

  return (
    <div className={styles.mapWrapper}>
      <MapContainer
        center={position}
        zoom={5}
        zoomControl={false}
        style={{
          height: "100%",
          border: "1px solid black",
          borderRadius: "20px",
          width: "100%",
        }}
      >
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Marker position={position} icon={userMarkerIcon}>
          <Popup className={styles.customPopup}>
            <div className={styles.blockUserMapLocation}>
              <h1>Your Location</h1>
            </div>
          </Popup>
        </Marker>

        <MarkerClusterGroup>
          {initiatives.map((marker) => (
            <MapMarker key={marker.id} markerInitiative={marker} />
          ))}
        </MarkerClusterGroup>

        <MapZoomAnimation coordinates={position} zoom={8} />
      </MapContainer>
    </div>
  );
};
