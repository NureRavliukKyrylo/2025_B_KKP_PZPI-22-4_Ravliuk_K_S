import type { SkillsResponse } from "../types/skillsTypes";
import { apiClient } from "../../../../shared/api";

export const getSkills = async (search?: string) => {
  const params = new URLSearchParams();

  if (search && search.trim()) {
    params.set("search", search.trim());
  }

  const response = await apiClient.get<SkillsResponse>(
    `Skills/list?${params.toString()}`
  );
  return response.data.data;
};
