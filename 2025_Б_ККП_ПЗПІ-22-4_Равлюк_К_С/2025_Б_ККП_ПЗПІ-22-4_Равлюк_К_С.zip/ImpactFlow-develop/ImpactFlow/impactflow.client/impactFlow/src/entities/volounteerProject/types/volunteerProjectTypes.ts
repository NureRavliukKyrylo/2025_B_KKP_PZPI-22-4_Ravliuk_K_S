export interface VolunteerSummary {
  id: string;
  fullName: string;
  roleInProject: string | null;
}

export interface ProjectData {
  id: string;
  title: string;
  volunteers: VolunteerSummary[];
}
