import { create } from "zustand";

type MessageType = "success" | "error" | "info";

interface MessageState {
  message: string | null;
  messageType: MessageType | null;
  setMessage: (message: string, type: MessageType) => void;
  clearMessage: () => void;
}

export const useMessageStore = create<MessageState>((set) => ({
  message: null,
  messageType: null,
  setMessage: (message, type) => set({ message, messageType: type }),
  clearMessage: () => set({ message: null, messageType: null }),
}));
