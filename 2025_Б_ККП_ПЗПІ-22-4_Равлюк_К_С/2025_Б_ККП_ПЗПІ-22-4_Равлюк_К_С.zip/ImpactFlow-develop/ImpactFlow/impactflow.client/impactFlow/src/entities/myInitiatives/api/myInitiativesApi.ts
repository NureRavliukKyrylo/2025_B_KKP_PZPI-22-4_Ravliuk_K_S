import { apiClient } from "../../../shared/api";
import type { MyInitiative, MyInitiativesResponse } from "../types/myInitiativesTypes";

export const getMyInitiatives = async (): Promise<MyInitiative[]> => {
  const response = await apiClient.get<MyInitiativesResponse>("Projects/my/list");
  return response.data.data;
};
