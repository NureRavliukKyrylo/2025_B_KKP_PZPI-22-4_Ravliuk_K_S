import { useMutation, useQueryClient } from "@tanstack/react-query";
import { deleteInitiative } from "../api/deleteMyInitiativeApi";
import { useErrorStore } from "../../error";
import { useMessageStore } from "../../message/MessageStore";

export const useDeleteInitiative = () => {
  const qc = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  return useMutation({
    mutationFn: (id: string) => deleteInitiative(id),
    onSuccess: () => {
      clearError();
      setMessage("Initiative deleted successfully", "success");
      qc.invalidateQueries({ queryKey: ["myInitiatives"] });
      qc.invalidateQueries({ queryKey: ["initiatives", "list"] });
    },
    onError: (err: unknown) => {
      console.error("Delete error:", err);
      setError("Failed to delete initiative.");
      setMessage("Error while deleting initiative", "error");
    },
  });
};
