export interface Category {
  id: string;
  name: string;
  description: string;
}

export interface CategoryResponse {
  data: Category[];
}

export interface CategoryDto {
  name: string;
  description: string;
}
