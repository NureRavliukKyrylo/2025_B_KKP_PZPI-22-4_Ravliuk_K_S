import React from "react";
import type { SkillsVolunteer } from "../types/skillsTypes";
import styles from "./VolunteerSkills.module.scss";

interface Props {
  skill: SkillsVolunteer;
  children?: React.ReactNode;
}

export const VolunteerSkills: React.FC<Props> = ({ skill, children }) => {
  return (
    <div className={styles.volunteerSkillCard}>
      <div className={styles.volunteerSkillHeader}>
        <h1 className={styles.volunteerSkillTitle}>{skill.name}</h1>
        <h1 className={styles.volunteerSkillDescription}>
          {skill.description ? skill.description : "No description"}
        </h1>
      </div>
      {children && (
        <div className={styles.actionsManageVolunteerSkill}>{children}</div>
      )}
    </div>
  );
};
