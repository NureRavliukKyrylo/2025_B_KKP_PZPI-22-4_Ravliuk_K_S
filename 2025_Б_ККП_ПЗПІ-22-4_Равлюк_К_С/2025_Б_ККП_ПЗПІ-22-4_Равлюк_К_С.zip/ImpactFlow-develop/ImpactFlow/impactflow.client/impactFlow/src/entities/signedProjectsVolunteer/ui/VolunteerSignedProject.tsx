import React from "react";
import type { ProjectInfo } from "../types/signedProjectsVolunteerTypes";
import styles from "./VolunteerSignedProject.module.scss";

interface Props {
  project: ProjectInfo;
  children?: React.ReactNode;
}

export const VolunteerSignedProject: React.FC<Props> = ({
  project,
  children,
}) => {
  const {
    id,
    title,
    description,
    endAt,
    categoryIds,
    location,
    latitude,
    longitude,
  } = project;
  const coordinates = location?.[0]?.location?.coordinates;

  return (
    <div className={styles.volunteerSignedProjectCard}>
      <h1 className={styles.titleVolunteerSignedProjectCard}>{title}</h1>
      <h1 className={styles.descriptionVolunteerSignedProjectCard}>
        {description}
      </h1>
      <div className={styles.blockDetailsVolunteerSignedProjectCard}>
        <div className={styles.detailsNotCategoryVolunteerSignedProjectCard}>
          <h1 className={styles.deadLineVolunteerSignedProjectCard}>
            {new Date(endAt).toLocaleDateString()}
          </h1>
        </div>
        <div className={styles.detailsNotCategoryVolunteerSignedProjectCard}>
          <h1 className={styles.deadLineVolunteerSignedProjectCard}>
            {new Date(endAt).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </h1>
        </div>
        <div className={styles.detailsNotCategoryVolunteerSignedProjectCard}>
          <h1 className={styles.deadLineVolunteerSignedProjectCard}>
            {longitude?.toFixed(5)}, {latitude?.toFixed(5)}
          </h1>
        </div>
        {categoryIds.map((name) => (
          <div
            key={name}
            className={styles.detailsNotCategoryVolunteerSignedProjectCard}
          >
            {name}
          </div>
        ))}
      </div>

      {children && (
        <div className={styles.actionsVolunteerProject}>{children}</div>
      )}
    </div>
  );
};
