import type { ErrorStore } from "./types";
import { create } from "zustand";

export const useErrorStore = create<ErrorStore>((set) => ({
  error: "",
  setError: (message: string) => set({ error: message }),
  clearError: () => set({ error: "" }),
}));
