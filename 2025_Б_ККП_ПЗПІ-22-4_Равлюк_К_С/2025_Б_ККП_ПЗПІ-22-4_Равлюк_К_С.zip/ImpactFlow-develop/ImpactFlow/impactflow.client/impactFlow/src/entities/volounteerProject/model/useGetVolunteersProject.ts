import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { getVolunteerProject } from "../api/getVolunteersProject";
import type { ProjectData } from "../types/volunteerProjectTypes";

export const useGetVolunteersProject = (id: string) => {
  const previousData = useRef<ProjectData | null>(null);

  const query = useQuery<ProjectData>({
    queryKey: ["volunteersProject", id],
    queryFn: async () => {
      const data = await getVolunteerProject(id);
      previousData.current = data;
      return data;
    },
    enabled: !!id,
    staleTime: 1000 * 60 * 5,
    retry: false,
  });

  const { data, isError, error } = query;

  useEffect(() => {
    if (isError && error) {
      console.error("Помилка завантаження проєкту:", error);
    }
  }, [isError, error]);

  return {
    ...query,
    data: query.data ?? previousData.current,
  };
};
