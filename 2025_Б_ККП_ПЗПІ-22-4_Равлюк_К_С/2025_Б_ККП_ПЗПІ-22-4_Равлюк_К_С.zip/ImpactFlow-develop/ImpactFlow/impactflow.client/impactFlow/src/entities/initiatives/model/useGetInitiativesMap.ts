import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { getInititativesMap } from "../api/getInitiativesMap";
import type { InitiativeMap } from "../types/InitiativeMapType";
import { useFilterStore } from "../../filter/store/filterStore";
import { useErrorStore } from "../../error";

export const usegetInititativesMap = () => {
  const previousData = useRef<InitiativeMap[] | null>(null);

  const { radius, endDate, categories } = useFilterStore();
  const { setError } = useErrorStore();

  const formattedEndDate = endDate
    ? `${endDate.getFullYear()}-${(endDate.getMonth() + 1)
        .toString()
        .padStart(2, "0")}-${endDate.getDate().toString().padStart(2, "0")}`
    : undefined;

  const query = useQuery<InitiativeMap[]>({
    queryKey: ["initiativesMap", radius, formattedEndDate, categories],
    queryFn: async () => {
      const data = await getInititativesMap({
        endDate: formattedEndDate,
        categories,
        radius,
      });
      previousData.current = data;
      return data;
    },
    staleTime: 1000 * 60 * 5,
    retry: false,
  });

  const { data, isError, error } = query;
  console.log(data);
  const isError400 =
    isError &&
    typeof error === "object" &&
    error &&
    "response" in error &&
    (error as any).response?.status === 400;

  useEffect(() => {
    if (isError && error) {
      const typedError = error as any;
      console.error("Failed to load initiatives", typedError);

      let errorMessage = "Failed to load initiatives. Try again.";

      if (isError400) {
        errorMessage =
          typedError?.response?.data?.error || "Invalid request (400)";
      }

      setError(errorMessage);
    }
  }, [isError, error]);

  return {
    ...query,
    isError400: isError400,
    data: query.data ?? previousData.current,
  };
};
