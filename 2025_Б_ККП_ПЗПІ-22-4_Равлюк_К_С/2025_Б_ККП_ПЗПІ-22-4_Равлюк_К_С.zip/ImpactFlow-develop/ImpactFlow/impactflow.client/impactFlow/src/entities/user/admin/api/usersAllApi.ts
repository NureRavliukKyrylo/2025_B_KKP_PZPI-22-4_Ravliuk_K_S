import type { UserResponse } from "../types/usersDetails";
import { apiClient } from "../../../../shared/api";

export const getAllUsers = async (search?: string) => {
  const params = new URLSearchParams();

  if (search && search.trim()) {
    params.set("search", search.trim());
  }
  const response = await apiClient.get<UserResponse>(
    `User/all?${params.toString()}`
  );
  return response.data.data;
};
