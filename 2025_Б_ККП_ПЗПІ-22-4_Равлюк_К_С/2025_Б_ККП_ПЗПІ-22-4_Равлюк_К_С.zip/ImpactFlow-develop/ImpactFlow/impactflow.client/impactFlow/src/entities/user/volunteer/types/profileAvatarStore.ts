import { create } from "zustand";
import { persist } from "zustand/middleware";

interface ProfileState {
  avatarUrl: string | null;
  fullName: string | null;
  role: string | null;
  latitude: number | null;
  longitude: number | null;
  emailRecover: string | null;
  setAvatarUrl: (url: string | null) => void;
  setFullName: (name: string | null) => void;
  setRole: (role: string | null) => void;
  setLatitude: (latitude: number | null) => void;
  setLongitude: (longitude: number | null) => void;
  setEmailRecover: (emailRecover: string | null) => void;
}

export const useProfileStore = create<ProfileState>()(
  persist(
    (set) => ({
      avatarUrl: null,
      fullName: null,
      role: null,
      latitude: null,
      longitude: null,
      emailRecover: null,
      setAvatarUrl: (url) => set({ avatarUrl: url }),
      setFullName: (name) => set({ fullName: name }),
      setRole: (role) => set({ role }),
      setLatitude: (latitude) => set({ latitude }),
      setLongitude: (longitude) => set({ longitude }),
      setEmailRecover: (emailRecover) => set({ emailRecover }),
    }),
    {
      name: "profile",
    }
  )
);
