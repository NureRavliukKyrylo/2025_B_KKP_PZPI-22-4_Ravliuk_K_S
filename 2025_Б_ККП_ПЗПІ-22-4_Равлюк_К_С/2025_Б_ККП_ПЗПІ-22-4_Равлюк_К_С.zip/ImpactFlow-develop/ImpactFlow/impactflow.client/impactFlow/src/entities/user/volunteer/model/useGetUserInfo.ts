import { useQuery } from "@tanstack/react-query";
import { getProfile } from "../api/userInfoApi";
import { useUserStore } from "../types/userStore";
import type { UserData } from "../types/userTypes";
import { useEffect, useRef } from "react";
import { useUserLocationStore } from "../types/locationStore";

export const useGetUserInfo = () => {
  const previousData = useRef<UserData | null>(null);
  const setCoordinates = useUserLocationStore((state) => state.setCoordinates);

  const query = useQuery<UserData>({
    queryKey: ["userProfile"],
    queryFn: async () => {
      const data = await getProfile();
      previousData.current = data;
      return data;
    },
    staleTime: 1000 * 60 * 5,
    retry: false,
  });

  const { data, isError, error } = query;

  useEffect(() => {
    if (isError && error) {
      console.error("Помилка запиту профілю:", error);
    }

    const userData = data ?? previousData.current;
    if (userData) {
      console.log(userData);
      useUserStore.getState().setUser(userData);
      if (userData.profile?.coordinates) {
        setCoordinates({
          lat: userData.profile.coordinates.coordinates.latitude,
          lng: userData.profile.coordinates.coordinates.longitude,
        });
      }
      if (userData.profile?.avatarUrl) {
        localStorage.setItem("avatarUrl", userData.profile.avatarUrl);
      }
    }
  }, [data, isError, error]);

  return {
    ...query,
    data: query.data ?? previousData.current,
  };
};
