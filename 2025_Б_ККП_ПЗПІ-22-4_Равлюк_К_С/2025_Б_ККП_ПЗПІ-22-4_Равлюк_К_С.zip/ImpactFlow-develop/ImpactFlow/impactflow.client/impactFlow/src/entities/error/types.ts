export interface ErrorStore {
  error: string;
  setError: (message: string) => void;
  clearError: () => void;
}
