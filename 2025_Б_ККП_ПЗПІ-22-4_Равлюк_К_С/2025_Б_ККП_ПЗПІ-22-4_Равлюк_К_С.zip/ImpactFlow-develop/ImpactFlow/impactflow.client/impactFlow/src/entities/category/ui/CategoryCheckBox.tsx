import React from "react";
import type { Category as CategoryType } from "../types/categoryTypes";
import styles from "./CategoryCheckBox.module.scss";
import { Checkbox } from "../../../shared/checkBoxes/checkBox";

interface Props {
  category: CategoryType;
  checked: boolean;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const CategoryCheckBox: React.FC<Props> = ({
  category,
  checked,
  onChange,
}) => {
  return (
    <div className={styles.categoryCheckboxCard}>
      <Checkbox
        name={category.name}
        checked={checked}
        onChange={onChange}
        style={{ width: "20px", height: "20px" }}
      />
      <span className={styles.categoryChackboxName}>{category.name}</span>
    </div>
  );
};
