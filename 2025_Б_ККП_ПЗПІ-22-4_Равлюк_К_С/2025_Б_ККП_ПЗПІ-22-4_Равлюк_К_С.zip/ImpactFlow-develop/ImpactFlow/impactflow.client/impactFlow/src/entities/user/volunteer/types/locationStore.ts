import { create } from "zustand";

interface LocationState {
  coordinates: { lat: number; lng: number } | null;
  isGeoInitialized: boolean;
  setCoordinates: (coords: { lat: number; lng: number }) => void;
  initializeCoordinates: () => void;
  setGeoInitialized: (value: boolean) => void;
}

export const useUserLocationStore = create<LocationState>((set) => ({
  coordinates: null,
  isGeoInitialized: false,

  setCoordinates: (coords) => set({ coordinates: coords }),

  setGeoInitialized: (value) => set({ isGeoInitialized: value }),

  initializeCoordinates: () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const coords = {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          };
          console.log(coords);
          set({ coordinates: coords });
          set({ isGeoInitialized: true });
        },
        (err) => {
          console.warn("Geolocation error:", err.message);
          set({ isGeoInitialized: true });
        }
      );
    } else {
      console.warn("Geolocation is not supported.");
      set({ isGeoInitialized: true });
    }
  },
}));
