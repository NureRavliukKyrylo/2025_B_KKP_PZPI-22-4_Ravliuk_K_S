import React from "react";
import type { Category as CategoryType } from "../types/categoryTypes";
import styles from "./Category.module.scss";

interface Props {
  category: CategoryType;
  children?: React.ReactNode;
}

export const Category: React.FC<Props> = ({ category, children }) => {
  return (
    <div className={styles.categoryCard}>
      <div className={styles.header}>
        <h1 className={styles.categoryTitle}>{category.name}</h1>
        <p className={styles.categoryDescription}>{category.description}</p>
      </div>
      {children && (
        <div className={styles.actionsManageCategory}>{children}</div>
      )}
    </div>
  );
};
