import React from "react";
import { useNavigate } from "react-router-dom";
import styles          from "./InitiativeCard.module.scss";
import type { InitiativeDto } from "../types/initiativeListTypes";

interface Props {
  initiative: InitiativeDto;
  categoryNames?: string[];
}

export const InitiativeCard: React.FC<Props> = ({
  initiative,
  categoryNames = [],
}) => {
  const navigate = useNavigate();

  const title = initiative.title;

  const end = new Date(initiative.endAt);
  const dateStr = end.toLocaleDateString("en-GB", {
    day:   "2-digit",
    month: "2-digit",
    year:  "numeric",
  });
  const timeStr = end.toLocaleTimeString("en-GB", {
    hour:   "2-digit",
    minute: "2-digit",
  });

  const coords = initiative.location?.[0]?.location?.coordinates;
  const coordsStr = coords
    ? `${coords.latitude.toFixed(6)}, ${coords.longitude.toFixed(6)}`
    : "--";

  const shown = categoryNames.slice(0, 2);
  const extra = categoryNames.length - shown.length;

  return (
    <div className={styles.card}>
      <h2 className={styles.title}>{title}</h2>

      <p className={styles.description}>{initiative.description}</p>

      <div className={styles.infoRow}>
        <span className={styles.tag}>{dateStr}</span>
        <span className={styles.tag}>{timeStr}</span>
        <span className={styles.tag}>{coordsStr}</span>
      </div>

      {!!shown.length && (
        <div className={styles.categories}>
          {shown.map(c => (
            <span key={c} className={styles.tag}>{c}</span>
          ))}
          {extra > 0 && <span className={styles.tag}>+{extra}</span>}
        </div>
      )}

      <div className={styles.footer}>
        <button
          className={styles.learnMoreBtn}
          onClick={() => navigate(`/initiatives/${initiative.id}`)}
        >
          Learn more
        </button>
      </div>
    </div>
  );
};
