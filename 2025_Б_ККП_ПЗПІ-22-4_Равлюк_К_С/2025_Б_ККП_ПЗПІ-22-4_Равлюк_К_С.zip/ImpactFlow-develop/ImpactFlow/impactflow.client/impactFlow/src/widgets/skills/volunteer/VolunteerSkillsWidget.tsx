import React from "react";
import { VolunteerSkills } from "../../../entities/skills/volunteer/ui/VolunteerSkills";
import styles from "./VolunteerSkillsWidget.module.scss";
import type { SkillsVolunteer } from "../../../entities/skills/volunteer/types/skillsTypes";
import { RemoveSkillButton } from "../../../features/skills/volunteer/deleteSkill/ui/RemoveVolunteerSkillButton";
import { SkillLevelSelect } from "../../../features/skills/volunteer/updateLevel/ui/SkillLevelSelect";
import { AddSkillButton } from "../../../features/skills/volunteer/addSkill/ui/AddSkillButton";

interface SkillsListProps {
  skills: SkillsVolunteer[];
}

export const VolunteerSkillsWidget: React.FC<SkillsListProps> = ({
  skills,
}) => {
  return (
    <div className={styles.SkillVolunteerList}>
      {skills.map((skill) => (
        <VolunteerSkills key={skill.skillId} skill={skill}>
          <SkillLevelSelect
            skillId={skill.skillId}
            initialLevel={skill.level}
          />
          <RemoveSkillButton skillId={skill.skillId} skillName={skill.name} />
        </VolunteerSkills>
      ))}
      <AddSkillButton />
    </div>
  );
};
