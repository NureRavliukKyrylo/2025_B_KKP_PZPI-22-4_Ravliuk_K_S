import React from "react";
import type { Skills } from "../../../entities/skills/admin/types/skillsTypes";
import { SkillAdmin } from "../../../entities/skills/admin/ui/SkillAdmin";
import styles from "./SkillsListWidget.module.scss";
import { CreateSkillButton } from "../../../features/skills/admin/createSkill/ui/CreateSkillButton";
import { DeleteSkillButton } from "../../../features/skills/admin/deleteSkill/ui/DeleteSkillButton";
import { UpdateSkillButton } from "../../../features/skills/admin/updateSkill/ui/UpdateSkillButton";

interface SkillsListProps {
  skills: Skills[];
}

export const SkillsListWidget: React.FC<SkillsListProps> = ({ skills }) => {
  return (
    <div className={styles.wrapperSkillsAdminList}>
      <div className={styles.SkillAdminList}>
        {skills.map((skill) => (
          <SkillAdmin key={skill.id} skill={skill}>
            <DeleteSkillButton skillId={skill.id} skillName={skill.name} />
            <UpdateSkillButton skill={skill} />
          </SkillAdmin>
        ))}
        <CreateSkillButton />
      </div>
    </div>
  );
};
