import React from "react";
import type { VolunteerSummary } from "../../entities/volounteerProject/types/volunteerProjectTypes";
import { VolunteerProject } from "../../entities/volounteerProject/ui/VolunteerProject";
import styles from "./ListVolunteersProjectWidget.module.scss";
import { DeleteVolunteerProject } from "../../features/volunteerProject/deleteVolunteerProject/ui/DeleteVolunteerProjectButton";
import { AssignRoleForm } from "../../features/volunteerProject/updateRoleVolunteerProject/ui/AssignRoleForm";
import BackIcon from "../../shared/assets/back_page_icon.png";
import { useNavigate } from "react-router-dom";

interface VolunteersListProps {
  projectId: string;
  projectTitle: string;
  volunteers: VolunteerSummary[];
}

export const VolunteersListWidget: React.FC<VolunteersListProps> = ({
  projectId,
  projectTitle,
  volunteers,
}) => {
  const navigate = useNavigate();
  return (
    <>
      <div className={styles.wrapperVolunteerProject}>
        <div className={styles.titlePreviousPageBlock}>
          <div className={styles.backPreviousPageVolunteerProject}>
            <img
              src={BackIcon}
              alt="back previous"
              onClick={() => navigate(-1)}
            />
          </div>
          <div className={styles.projectTitleVolunteer}>
            <h1>{projectTitle}</h1>
            <p>People who joined your initiative</p>
          </div>
        </div>
        <div className={styles.volunteersList}>
          {volunteers.length === 0 ? (
            <div className={styles.noVolunteerProjectCard}>
              No volunteers found in your project
            </div>
          ) : (
            volunteers.map((volunteer) => (
              <VolunteerProject key={volunteer.id} volunteer={volunteer}>
                <AssignRoleForm
                  projectId={projectId}
                  userId={volunteer.id}
                  initialRole={volunteer.roleInProject}
                />
                <DeleteVolunteerProject
                  projectId={projectId}
                  userId={volunteer.id}
                  username={volunteer.fullName}
                />
              </VolunteerProject>
            ))
          )}
        </div>
      </div>
    </>
  );
};
