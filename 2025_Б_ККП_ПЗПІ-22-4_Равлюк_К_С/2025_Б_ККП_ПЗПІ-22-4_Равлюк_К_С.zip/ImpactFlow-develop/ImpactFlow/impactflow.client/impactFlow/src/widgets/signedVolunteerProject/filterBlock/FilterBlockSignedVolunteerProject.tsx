import { CategoryCheckBoxList } from "../../../entities/category/ui/CategoryChecboxList";
import EndDateFilterPicker from "../../../shared/dateTime/EndDateFilterPicker";
import styles from "./FilterBlockSignedVolunteerProject.module.scss";
import FilterIcon from "../../../shared/assets/filter_icon.png";
import type { Category as CategoryType } from "../../../entities/category/types/categoryTypes";

interface CategoryListCheckboxProps {
  categories: CategoryType[] | null;
}

export const FilterBlockSignedVolunteerProject: React.FC<
  CategoryListCheckboxProps
> = ({ categories }) => {
  return (
    <div className={styles.filterBlockSignedVolunteerProject}>
      <div className={styles.filterTitleSignedVolunteerProject}>
        <h1>Filter</h1>
        <img src={FilterIcon} className={styles.filterIconPic} alt="Telegram" />
      </div>
      <div className={styles.filterCategoriesSignedVolunteerProject}>
        <h1>CATEGORIES</h1>
        <CategoryCheckBoxList categories={categories} />
      </div>
      <div className={styles.dividerCategoriesFilter}>
        <div className={styles.lineDividerFilter}></div>
      </div>

      <div className={styles.filterDeadLineSignedVolunteerProject}>
        <h1>END DATE</h1>
        <EndDateFilterPicker />
      </div>
    </div>
  );
};
