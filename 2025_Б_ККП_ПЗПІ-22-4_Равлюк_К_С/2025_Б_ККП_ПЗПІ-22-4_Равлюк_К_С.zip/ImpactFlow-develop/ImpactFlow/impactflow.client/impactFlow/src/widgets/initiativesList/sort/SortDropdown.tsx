import React, { useState, useRef, useEffect } from "react";
import styles from "./SortDropdown.module.scss";
import SortIcon from "../../../shared/assets/sort.png";
import { useFilterStore } from "../../../entities/filter/store/filterStore";
import type { OrderBy } from "../../../entities/filter/store/filterStore";

const OPTIONS: { label: string; value: OrderBy }[] = [
  { label: "Newest", value: "Newest" },
  { label: "Title A → Z", value: "TitleAsc" },
  { label: "Title Z → A", value: "TitleDesc" },
  { label: "Ending Soon", value: "EndingSoon" },
];

export const SortDropdown: React.FC = () => {
  const ref = useRef<HTMLDivElement>(null);
  const orderBy = useFilterStore((s) => s.orderBy);
  const setOrderBy = useFilterStore((s) => s.setOrderBy);

  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const currentLabel = OPTIONS.find((o) => o.value === orderBy)?.label ?? "Newest";

  return (
    <div className={styles.dropdown} ref={ref}>
      <button
        type="button"
        className={`${styles.button} ${open ? styles.open : ""}`}
        onClick={() => setOpen((o) => !o)}
      >
        {currentLabel}
        <img src={SortIcon} alt="Sort" className={styles.icon} />
      </button>

      {open && (
        <div className={styles.menu}>
          {OPTIONS.map((opt) => (
            <div
              key={opt.value}
              className={styles.menuItem}
              onClick={() => {
                setOrderBy(opt.value);
                setOpen(false);
              }}
            >
              {opt.label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
