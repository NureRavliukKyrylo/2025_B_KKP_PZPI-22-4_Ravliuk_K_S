import { VolunteerSignedProject } from "../../entities/signedProjectsVolunteer/ui/VolunteerSignedProject";
import styles from "./SignedVolunteerProjectList.module.scss";
import { LeaveProjectButton } from "../../features/volunteerProject/leaveProject/ui/LeaveProjectButton";
import { CircularProgress, Box } from "@mui/material";
import type { ProjectInfo } from "../../entities/signedProjectsVolunteer/types/signedProjectsVolunteerTypes";
import { LearnMoreButton } from "../../features/volunteerProject/projectLearn/ui/LearnMoreButton";

interface SignedVolunteerListProps {
  projectSigned: ProjectInfo[] | undefined;
  isLoading: boolean;
  isError: boolean;
}

export const SignedVolunteerListWidget: React.FC<SignedVolunteerListProps> = ({
  projectSigned,
  isLoading,
  isError,
}) => {
  if (isLoading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="200px"
      >
        <CircularProgress />
      </Box>
    );
  }

  if (isError) {
    return (
      <div className={styles.errorSignedVolunteerProjectBlock}>
        <h1 className="errorPage">Failed to load projects. Try again.</h1>
      </div>
    );
  }
  if (!projectSigned || projectSigned.length === 0) {
    return (
      <div className={styles.emptySignedVolunteerProjectBlock}>
        No active projects found.
      </div>
    );
  }

  return (
    <div className={styles.wrapperSignedVolunteerListProject}>
      {projectSigned.map((proj) => (
        <VolunteerSignedProject key={proj.id} project={proj}>
          <LeaveProjectButton projectId={proj.id} />
          <LearnMoreButton projectId={proj.id} />
        </VolunteerSignedProject>
      ))}
    </div>
  );
};
