import { CategoryCheckBoxList } from "../../../entities/category/ui/CategoryChecboxList";
import EndDateFilterPicker from "../../../shared/dateTime/EndDateFilterPicker";
import styles from "./FilterBlockInteractiveMap.module.scss";
import FilterIcon from "../../../shared/assets/filter_icon.png";
import { RadiusInput } from "../../../features/filters/ui/RadiusInput";
import type { Category as CategoryType } from "../../../entities/category/types/categoryTypes";

interface CategoryListCheckboxProps {
  categories: CategoryType[] | null;
}

export const FilterBlockInteractiveMap: React.FC<CategoryListCheckboxProps> = ({
  categories,
}) => {
  return (
    <div className={styles.filterBlockInteractiveMap}>
      <div className={styles.filterTitleInteractiveMap}>
        <h1>Filter</h1>
        <img
          src={FilterIcon}
          className={styles.filterIconPicInteractiveMap}
          alt="Telegram"
        />
      </div>
      <div className={styles.filterCategoriesInteractiveMap}>
        <h1>CATEGORIES</h1>
        <CategoryCheckBoxList categories={categories} />
      </div>
      <div className={styles.dividerInteractiveMapFilter}>
        <div className={styles.lineDividerFilterInteractiveMap}></div>
      </div>

      <div className={styles.filterDeadLineInteractiveMap}>
        <h1>END DATE</h1>
        <EndDateFilterPicker />
      </div>

      <div className={styles.dividerInteractiveMapFilter}>
        <div className={styles.lineDividerFilterInteractiveMap}></div>
      </div>

      <div className={styles.filterRadiusInteractiveMap}>
        <h1>DISTANCE</h1>
        <RadiusInput />
      </div>
    </div>
  );
};
