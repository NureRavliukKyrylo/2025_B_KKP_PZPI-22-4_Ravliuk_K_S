import React from "react";
import styles from "./VolunteerSkillsWidget.module.scss";
import { SkillAdmin } from "../../../entities/skills/admin/ui/SkillAdmin";
import type { Skills } from "../../../entities/skills/admin/types/skillsTypes";
import { SkillAssignSelector } from "../../../features/skills/volunteer/assignSkill/ui/SkillAsignSelector";
import { Box, CircularProgress } from "@mui/material";

interface SkillsListProps {
  skills: Skills[];
  isLoading: boolean | null;
}

export const VolunteerSkillsAddingWidget: React.FC<SkillsListProps> = ({
  skills,
  isLoading,
}) => {
  if (isLoading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="200px"
      >
        <CircularProgress />
      </Box>
    );
  }

  if (!skills || skills.length === 0) {
    return <div className={styles.emptySkillsBlock}>No skills found.</div>;
  }
  return (
    <div className={styles.SkillVolunteerList}>
      {skills.map((skill) => (
        <SkillAdmin key={skill.id} skill={skill}>
          <SkillAssignSelector skillId={skill.id} />
        </SkillAdmin>
      ))}
    </div>
  );
};
