import { ProfileContainer } from "../../shared/containers/profile/ProfileContainer";
import { UserProfile } from "../../entities/user/volunteer/ui/UserProfile";
import { LogoutButton } from "../../features/auth/logout/ui/LogoutButton";
import styles from "./UserProfileWidget.module.scss";
import type { UserData } from "../../entities/user/volunteer/types/userTypes";

interface UserProfileWidgetProps {
  user: UserData | null;
}

export const UserProfileWidget: React.FC<UserProfileWidgetProps> = ({
  user,
}) => {
  return (
    <ProfileContainer>
      <UserProfile user={user}></UserProfile>
      <div className={styles.containerProfileContent}>
        <LogoutButton></LogoutButton>
      </div>
    </ProfileContainer>
  );
};
