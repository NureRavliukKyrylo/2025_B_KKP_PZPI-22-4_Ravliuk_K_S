import React from "react";
import { useNavigate } from "react-router-dom";
import type { MyInitiative } from "../../entities/myInitiatives/types/myInitiativesTypes";
import { useGetCategories } from "../../entities/category/model/useGetCategories";
import { DeleteInitiativeButton } from "../../features/myInitiatives/deleteInitiative/ui/DeleteInitiativeButton";
import PlusIcon from "../../shared/assets/plus_icon.png";
import PencilIcon from "../../shared/assets/pencil.png";
import GroupsIcon from "../../shared/assets/groups.png";
import styles from "./MyInitiativeListWidget.module.scss";

interface MyInitiativeListWidgetProps {
  initiatives: MyInitiative[];
}

export const MyInitiativeListWidget: React.FC<MyInitiativeListWidgetProps> = ({
  initiatives,
}) => {
  const navigate = useNavigate();
  const { data: allCategories } = useGetCategories();

  const AddCard = (
    <div
      className={styles.addCard}
      onClick={() => navigate("/initiator-initiatives/create")}
    >
      <div className={styles.plusIcon}>
        <img src={PlusIcon} alt="Add new initiative" />
      </div>
      <h3 className={styles.addLabel}>Add new initiative</h3>
    </div>
  );

  if (!initiatives || initiatives.length === 0) {
    return <div className={styles.listContainer}>{AddCard}</div>;
  }

  return (
    <div className={styles.listContainer}>
      {initiatives.map((item) => {
        let categoryNames: string[] = [];
        if (Array.isArray(item.categoryIds) && allCategories) {
          const looksLikeId = (s: string) => /^[0-9a-fA-F]{24}$/.test(s);
          if (item.categoryIds.every(looksLikeId)) {
            categoryNames = item.categoryIds
              .map((id) => allCategories.find((c) => c.id === id)?.name)
              .filter((n): n is string => Boolean(n));
          } else {
            categoryNames = [...item.categoryIds];
          }
        }

        return (
          <div key={item.id} className={styles.card}>
            <h2 className={styles.title}>{item.title}</h2>
            <p className={styles.description}>{item.description}</p>

            <div className={styles.infoRow}>
              <div className={styles.infoTag}>
                {new Date(item.endAt).toLocaleTimeString("uk-UA", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </div>
              <div className={styles.infoTag}>
                {new Date(item.endAt).toLocaleDateString("uk-UA")}
              </div>
              {item.location?.[0] && (
                <div className={styles.infoTag}>
                  {item.location[0].location.coordinates.latitude.toFixed(
                    5
                  )},{" "}
                  {item.location[0].location.coordinates.longitude.toFixed(
                    5
                  )}
                </div>
              )}
            </div>

            {categoryNames.length > 0 && (
              <div className={styles.categories}>
                {categoryNames.map((name) => (
                  <span key={name} className={styles.categoryBadge}>
                    {name}
                  </span>
                ))}
              </div>
            )}

            <div className={styles.actions}>
              <button
                className={`${styles.actionBtn} ${styles.groupBtn}`}
                onClick={() =>
                  navigate(`/initiator-initiatives/volunteers/${item.id}`)
                }
              >
                <img
                  src={GroupsIcon}
                  alt="View volunteers"
                  className={styles.actionIcon}
                />
              </button>

              <button
                className={styles.actionBtn}
                onClick={() =>
                  navigate(`/initiator-initiatives/edit/${item.id}`)
                }
              >
                <img
                  src={PencilIcon}
                  alt="Edit initiative"
                  className={styles.actionIcon}
                />
              </button>

              <DeleteInitiativeButton
                initiativeId={item.id}
                className={styles.actionBtn}
                iconClassName={styles.actionIcon}
              />
            </div>
          </div>
        );
      })}

      {AddCard}
    </div>
  );
};
