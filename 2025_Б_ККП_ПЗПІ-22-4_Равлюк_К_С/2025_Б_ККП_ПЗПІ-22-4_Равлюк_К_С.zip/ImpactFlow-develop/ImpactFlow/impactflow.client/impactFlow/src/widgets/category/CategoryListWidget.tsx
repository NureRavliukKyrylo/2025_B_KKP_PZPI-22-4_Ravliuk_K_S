import React from "react";
import type { Category as CategoryType } from "../../entities/category/types/categoryTypes";
import { Category } from "../../entities/category/ui/Category";
import styles from "./CategoryListWidget.module.scss";
import { DeleteCategoryButton } from "../../features/category/deleteCategory/ui/DeleteCategoryButton";
import { UpdateCategoryButton } from "../../features/category/updateCategory/ui/UpdateCategoryButton";
import { CreateCategoryButton } from "../../features/category/createCategory/ui/CreateCategoryButton";

interface CategoryListProps {
  categories: CategoryType[];
}

export const CategoryListWidget: React.FC<CategoryListProps> = ({
  categories,
}) => {
  return (
    <div className={styles.categoryList}>
      {categories.map((category) => (
        <Category key={category.id} category={category}>
          <UpdateCategoryButton category={category} />
          <DeleteCategoryButton
            categoryId={category.id}
            categoryName={category.name}
          />
        </Category>
      ))}
      <CreateCategoryButton />
    </div>
  );
};
