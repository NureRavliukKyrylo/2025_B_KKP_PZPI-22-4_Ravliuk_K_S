// src/widgets/header/HeaderWidget.tsx
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ProfileAvatar } from "../../shared/avatar/ProfileAvatar";
import { NavigationLink } from "../../shared/navLinks/NavigationLink";
import LogoFlow from "../../shared/assets/logo_impact_flow.png";
import BurgerIcon from "../../shared/assets/burger_menu.png";
import { useProfileStore } from "../../entities/user/volunteer/types/profileAvatarStore";
import styles from "./HeaderWidget.module.scss";

const NAV_BY_ROLE: Record<string, { to: string; label: string }[]> = {
  Volunteer: [
    { to: "/initiatives", label: "INITIATIVES" },
    { to: "/map", label: "MAP" },
    { to: "/volunteer-initiatives", label: "ACTIVE INITIATIVES" },
    { to: "/contacts", label: "CONTACTS" },
  ],
  Initiator: [
    { to: "/initiatives", label: "INITIATIVES" },
    { to: "/map", label: "MAP" },
    { to: "/initiator-initiatives", label: "MY INITIATIVES" },
    { to: "/contacts", label: "CONTACTS" },
  ],
  Admin: [
    { to: "/admin/categories", label: "CATEGORIES" },
    { to: "/admin/users", label: "USERS" },
    { to: "/admin/skills", label: "SKILLS" },
  ],
};

export const HeaderWidget: React.FC = () => {
  const role = useProfileStore((s) => s.role) ?? "Volunteer";
  const links = NAV_BY_ROLE[role];

  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);

  return (
    <>
      <header className={styles.header}>
        <button
          type="button"
          className={styles.burgerBtn}
          onClick={() => setMenuOpen((o) => !o)}
          aria-label="Open navigation"
        >
          <img src={BurgerIcon} alt="" />
        </button>

        <div className={styles.sideBlock} />

        <div className={styles.centerBlock}>
          <nav className={styles.navPill}>
            <Link to="/home" onClick={closeMenu}>
              <img
                src={LogoFlow}
                alt="Impact Flow logo"
                className={styles.logoImpactFlow}
              />
            </Link>

            <div className={styles.links}>
              {links.map(({ to, label }) => (
                <NavigationLink key={to} to={to} label={label} />
              ))}
            </div>
          </nav>
        </div>

        <div className={styles.sideBlock}>
          <ProfileAvatar />
        </div>
      </header>

      <div
        className={`${styles.mobileMenu} ${menuOpen ? styles.open : ""}`}
        onClick={closeMenu}
      >
        <button
          type="button"
          className={styles.closeBtn}
          aria-label="Close navigation"
          onClick={closeMenu}
        >
          ✕
        </button>

        <div
          className={styles.mobileInner}
          onClick={(e) => e.stopPropagation()}
        >
          <div className={styles.linksMobile}>
            {links.map(({ to, label }) => (
              <NavigationLink
                key={to}
                to={to}
                label={label}
                onClick={closeMenu}
              />
            ))}
          </div>
        </div>
      </div>
    </>
  );
};
