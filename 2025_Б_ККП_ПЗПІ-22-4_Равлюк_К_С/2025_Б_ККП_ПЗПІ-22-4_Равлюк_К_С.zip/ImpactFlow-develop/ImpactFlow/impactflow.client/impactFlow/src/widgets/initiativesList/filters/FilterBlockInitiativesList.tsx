import React from "react";
import { useFilterStore } from "../../../entities/filter/store/filterStore";
import { useGetCategories } from "../../../entities/category/model/useGetCategories";
import EndDateFilterPicker from "../../../shared/dateTime/EndDateFilterPicker";
import { RadiusInput } from "../../../features/filters/ui/RadiusInput";
import styles from "./FilterBlockInitiativesList.module.scss";
import FilterIcon from "../../../shared/assets/filter_icon.png";

export const FilterBlockInitiativesList: React.FC = () => {
  const selectedCategories = useFilterStore((s) => s.categories);
  const toggleCategory     = useFilterStore((s) => s.toggleCategory);

  const { data: allCategories, isLoading, isError } = useGetCategories();

  return (
    <div className={styles.filterBlockInitiativesList}>
      <div className={styles.filterHeader}>
        <h1>Filter</h1>
        <img src={FilterIcon} alt="Filter icon" />
      </div>

      <div className={styles.filterSection}>
        <h2>CATEGORIES</h2>
        {isLoading && <p className={styles.loading}>Loading…</p>}
        {isError   && <p className={styles.error}>Failed to load categories</p>}
        {!isLoading && !isError && allCategories && (
          <div className={styles.checkboxList}>
            {allCategories.map((cat) => (
              <label key={cat.id} className={styles.checkboxLabel}>
                <input
                  type="checkbox"
                  checked={selectedCategories.includes(cat.name)}
                  onChange={() => toggleCategory(cat.name)}
                />
                <span>{cat.name}</span>
              </label>
            ))}
          </div>
        )}
      </div>

      <div className={styles.divider} />

      <div className={styles.filterSection}>
        <h2>END DATE</h2>
        <EndDateFilterPicker />
      </div>

      <div className={styles.divider} />

      <div className={styles.filterSection}>
        <h2>DISTANCE</h2>
        <RadiusInput />
      </div>
    </div>
  );
};
