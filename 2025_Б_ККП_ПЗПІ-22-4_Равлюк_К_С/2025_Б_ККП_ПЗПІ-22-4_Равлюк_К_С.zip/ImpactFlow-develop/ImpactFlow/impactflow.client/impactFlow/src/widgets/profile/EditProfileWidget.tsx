import { ProfileContainer } from "../../shared/containers/profile/ProfileContainer";
import styles from "./EditProfileWidget.module.scss";
import { EditProfileAvatar } from "../../features/profile/ui/EditProfileAvatar";
import { EditProfile } from "../../features/profile/ui/EditProfile";
import type { UserData } from "../../entities/user/volunteer/types/userTypes";

interface EditProfileWidgetProps {
  user: UserData | null;
}
export const EditProfileWidget: React.FC<EditProfileWidgetProps> = (user) => {
  return (
    <ProfileContainer>
      <div className={styles.userEditProfileInfo}>
        <EditProfileAvatar user={user} />
        <EditProfile />
      </div>
    </ProfileContainer>
  );
};
