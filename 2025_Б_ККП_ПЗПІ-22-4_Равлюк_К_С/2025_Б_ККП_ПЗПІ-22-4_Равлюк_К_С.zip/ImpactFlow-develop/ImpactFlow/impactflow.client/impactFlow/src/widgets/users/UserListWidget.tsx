import React from "react";
import type { UserDetails } from "../../entities/user/admin/types/usersDetails";
import { UserItem } from "../../entities/user/admin/ui/UserItem";
import styles from "./UserListWidget.module.scss";
import { DeleteuserButton } from "../../features/users/deleteUser/ui/DeleteUserButton";
import { ChangeRoleButton } from "../../features/users/changeRole/ui/ChangeRoleButton";
import { Box, CircularProgress } from "@mui/material";

interface UserListProps {
  users: UserDetails[];
  isEmpty: boolean | null;
  isLoading: boolean | null;
}

export const UserListWidget: React.FC<UserListProps> = ({
  users,
  isEmpty,
  isLoading,
}) => {
  if (isLoading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="200px"
      >
        <CircularProgress />
      </Box>
    );
  }

  return (
    <>
      <div className={styles.userAdminDetailsList}>
        {users.map((user) => (
          <UserItem key={user.id} user={user}>
            <DeleteuserButton userId={user.id} userName={user.fullName} />
            <ChangeRoleButton user={user} />
          </UserItem>
        ))}
      </div>
      {isEmpty && <h1 className="infoPageText">Users not found</h1>}
    </>
  );
};
