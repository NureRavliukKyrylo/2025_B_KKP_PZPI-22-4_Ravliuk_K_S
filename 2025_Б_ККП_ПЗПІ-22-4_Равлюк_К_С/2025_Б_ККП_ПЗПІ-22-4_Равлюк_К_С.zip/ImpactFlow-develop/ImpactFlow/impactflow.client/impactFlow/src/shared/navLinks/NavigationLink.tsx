import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./NavigationLink.module.scss";

export interface NavigationLinkProps {
  to: string;
  label: string;
  onClick?: () => void;
}

export const NavigationLink: React.FC<NavigationLinkProps> = ({
  to,
  label,
  onClick,
}) => (
  <NavLink
    to={to}
    end
    onClick={onClick}
    className={({ isActive }) =>
      isActive ? `${styles.link} ${styles.active}` : styles.link
    }
  >
    {label}
  </NavLink>
);
