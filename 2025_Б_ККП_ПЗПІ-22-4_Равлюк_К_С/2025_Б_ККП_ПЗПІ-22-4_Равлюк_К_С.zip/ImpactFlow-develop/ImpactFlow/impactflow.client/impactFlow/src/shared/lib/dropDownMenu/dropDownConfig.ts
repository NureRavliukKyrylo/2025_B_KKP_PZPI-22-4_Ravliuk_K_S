import Skills from "../../assets/skills.png";

export const menuItemsByRole: Record<
  string,
  { label: string; icon: string; to: string }[]
> = {
  Admin: [],
  Volunteer: [{ label: "Skills", icon: Skills, to: "/skills" }],
  Organizer: [],
};
