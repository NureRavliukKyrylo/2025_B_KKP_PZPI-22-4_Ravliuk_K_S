import React from "react";
import styles from "./NavbarContainer.module.scss";

interface NavbarContainerProps {
  children?: React.ReactNode;
}

export const NavbarContainer: React.FC<NavbarContainerProps> = ({
  children,
}) => {
  return (
    <div className={styles.navbarContainer}>
      <div className={styles.navbarForm}>{children}</div>
    </div>
  );
};
