import { useMemo } from "react";
import { DropdownMenu, type MenuItem } from "../dropDown/DropDownMenu";
import { useProfileStore } from "../../entities/user/volunteer/types/profileAvatarStore";
import DefaultProfile from "../assets/default_profile.png";
import SkillsIcon from "../assets/skills.png";

export const ProfileAvatar = () => {
  const avatarUrl = useProfileStore((s) => s.avatarUrl);
  const fullName = useProfileStore((s) => s.fullName);
  const role = useProfileStore((s) => s.role) ?? "Volunteer";

  const menuItems: MenuItem[] = useMemo(() => {
    switch (role) {
      case "Volunteer":
        return [
          { label: "Skills", icon: SkillsIcon, to: "/my-skills" },
        ];
      case "Organizer":
      case "Admin":
      default:
        return [];              
    }
  }, [role]);

  return (
    <DropdownMenu
      avatarUrl={avatarUrl || DefaultProfile}
      name={fullName || "Unknown User"}
      role={role}
      menuItems={menuItems}      
    />
  );
};
