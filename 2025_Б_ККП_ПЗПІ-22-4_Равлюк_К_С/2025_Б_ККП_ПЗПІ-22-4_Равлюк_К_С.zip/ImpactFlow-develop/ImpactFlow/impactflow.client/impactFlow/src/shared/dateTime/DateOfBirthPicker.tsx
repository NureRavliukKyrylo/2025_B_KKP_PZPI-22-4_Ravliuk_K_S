import React, { useState } from "react";
import { styled } from "@mui/material/styles";
import { LocalizationProvider, DatePicker } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { IconButton, InputAdornment, TextField } from "@mui/material";
import CalendarImg from "../assets/calendar.png";

const StyledTextField = styled(TextField)(({ theme }) => ({
  width: "100%",
  "& .MuiOutlinedInput-root": {
    height: 50,
    borderRadius: 10,
    paddingRight: 0,
    background: "#fff",
    boxShadow: "0 4px 8px rgba(0,0,0,.25)",
    "& fieldset": {
      borderRadius: 10,
      borderWidth: 1,
    },
    [theme.breakpoints.down("sm")]: {
      height: 40,
    },
  },
  "& input": {
    fontFamily: '"Source Serif Pro", serif',
    fontWeight: 400,
    fontSize: 22,
    padding: "12px 20px",
    cursor: "pointer",
    [theme.breakpoints.down("md")]: {
      fontSize: 20,
      padding: "10px 14px",
    },
    [theme.breakpoints.down("sm")]: {
      fontSize: 17,
      padding: "8px 12px",
    },
    [theme.breakpoints.down("xs")]: {
      fontSize: 17,
      padding: "6px 10px",
    },
  },
}));

interface DateOfBirthPickerProps {
  formik: any;
  error: any;
}

const DateOfBirthPicker: React.FC<DateOfBirthPickerProps> = ({
  formik,
  error,
}) => {
  const [open, setOpen] = useState(false);
  return (
    <>
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        <DatePicker
          open={open}
          onOpen={() => setOpen(true)}
          onClose={() => setOpen(false)}
          label="Date of birthday"
          value={formik.values.dateOfBirth}
          onChange={(value: Date | null) =>
            formik.setFieldValue("dateOfBirth", value)
          }
          format="dd.MM.yyyy"
          enableAccessibleFieldDOMStructure={false}
          slots={{
            textField: (params) => (
              <StyledTextField
                {...params}
                variant="outlined"
                InputProps={{
                  ...params.InputProps,
                  readOnly: true,
                  endAdornment: (
                    <InputAdornment position="end" sx={{ pr: 2 }}>
                      <IconButton
                        edge="end"
                        size="small"
                        sx={{ p: 0 }}
                        onClick={() => setOpen(true)}
                      >
                        <img
                          src={CalendarImg}
                          alt="calendar"
                          width={26}
                          height={26}
                        />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            ),
          }}
        />
      </LocalizationProvider>
      {error && <div className="errorMessage">{error}</div>}
    </>
  );
};

export default DateOfBirthPicker;
