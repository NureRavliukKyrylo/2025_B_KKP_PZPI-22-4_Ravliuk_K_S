import React, { useEffect } from "react";
import styles from "./ProfileLayout.module.scss";
import { useMessageStore } from "../../../entities/message/MessageStore";
import { Alert } from "@mui/material";

interface ProfileLayoutProps {
  children: React.ReactNode;
}

export const ProfileLayout: React.FC<ProfileLayoutProps> = ({ children }) => {
  const { message, messageType, clearMessage } = useMessageStore();

  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => {
        clearMessage();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [message, clearMessage]);
  return (
    <div className={styles.profileWrapper}>
      {children}{" "}
      {message && (
        <Alert className={styles.alertMessage} severity={messageType || "info"}>
          {message}
        </Alert>
      )}
    </div>
  );
};
