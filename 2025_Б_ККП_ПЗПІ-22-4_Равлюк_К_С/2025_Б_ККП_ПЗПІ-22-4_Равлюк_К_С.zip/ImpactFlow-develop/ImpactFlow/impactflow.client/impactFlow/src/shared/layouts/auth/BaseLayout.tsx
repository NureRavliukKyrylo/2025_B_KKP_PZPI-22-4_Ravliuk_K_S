import React, { useEffect } from "react";
import styles from "./BaseLayout.module.scss";
import { Alert } from "@mui/material";
import { useMessageStore } from "../../../entities/message/MessageStore";

interface BaseLayoutProps {
  children: React.ReactNode;
}

export const BaseLayout: React.FC<BaseLayoutProps> = ({ children }) => {
  const { message, messageType, clearMessage } = useMessageStore();

  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => {
        clearMessage();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [message, clearMessage]);

  return (
    <div className={styles.wrapper}>
      {children}{" "}
      {message && (
        <Alert className={styles.alertMessage} severity={messageType || "info"}>
          {message}
        </Alert>
      )}
    </div>
  );
};
