export type NavItem = {
  to: string;
  label: string;
};

export const navItemsByRole: Record<
  string,
  { left: NavItem[]; right: NavItem[] }
> = {
  Admin: {
    left: [
      { to: "/initiatives", label: "CATEGORIES" },
      { to: "/map", label: "USERS" },
    ],
    right: [
      { to: "/users", label: "HISTORY" },
      { to: "/admin/skills", label: "SKILLS" },
    ],
  },
  Volunteer: {
    left: [
      { to: "/initiatives", label: "INITIATIVES" },
      { to: "/map", label: "MAP" },
    ],
    right: [
      { to: "/calendar", label: "ACTIVE INITIATIVES" },
      { to: "/contacts", label: "CONTACTS" },
    ],
  },
  Organizer: {
    left: [
      { to: "/initiatives", label: "INITIATIVES" },
      { to: "/map", label: "MAP" },
    ],
    right: [
      { to: "/calendar", label: "MY INITIATIVES" },
      { to: "/contacts", label: "CONTACTS" },
    ],
  },
};
