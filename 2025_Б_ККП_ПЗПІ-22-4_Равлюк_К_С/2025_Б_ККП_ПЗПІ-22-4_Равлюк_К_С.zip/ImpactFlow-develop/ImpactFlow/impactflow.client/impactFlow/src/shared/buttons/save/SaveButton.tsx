import React from "react";
import styles from "./SaveButton.module.scss";

interface SaveButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  loading?: boolean;
  label?: string;
}

export const SaveButton: React.FC<SaveButtonProps> = ({
  loading = false,
  label = "Save Changes",
  ...props
}) => {
  return (
    <button
      type="submit"
      disabled={loading || props.disabled}
      className={styles.submitSaveBtn}
      {...props}
    >
      {loading ? "Saving..." : label}
    </button>
  );
};
