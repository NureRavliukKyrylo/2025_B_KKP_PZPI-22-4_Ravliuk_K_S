import React from "react";
import styles from "./TextArea.module.scss";

interface TextAreaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
}

export const TextArea: React.FC<TextAreaProps> = ({
  label,
  error,
  ...props
}) => {
  return (
    <div className={styles.textAreaWrapper}>
      <textarea
        className={`${styles.textArea} ${error ? styles.error : ""}`}
        {...props}
      />
      {error && <div className="errorMessage">{error}</div>}
    </div>
  );
};
