import React from "react";
import styles from "./PageContainer.module.scss";

interface PageContainerProps {
  label: string;
  maxWidth?: string;
}

export const PageContainer: React.FC<PageContainerProps> = ({
  label,
  maxWidth,
}) => {
  return (
    <div className={styles.pageContainer} style={{ maxWidth }}>
      <h1>{label}</h1>
    </div>
  );
};
