import React from "react";
import styles from "./ProfileContainer.module.scss";

interface ProfileContainerProps {
  children?: React.ReactNode;
}

export const ProfileContainer: React.FC<ProfileContainerProps> = ({
  children,
}) => {
  return <div className={styles.profileContainer}>{children}</div>;
};
