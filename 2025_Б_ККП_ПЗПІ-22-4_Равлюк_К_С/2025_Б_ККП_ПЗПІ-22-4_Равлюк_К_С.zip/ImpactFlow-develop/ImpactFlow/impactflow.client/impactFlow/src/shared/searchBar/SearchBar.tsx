import React, { useEffect, useState } from "react";
import styles from "./SearchBar.module.scss";
import SearchIcon from "../assets/search_icon.png";
import { useFilterStore } from "../../entities/filter/store/filterStore";

interface SearchBarProps {
  debounceDelay?: number;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  debounceDelay = 500,
}) => {
  const globalSearch = useFilterStore((state) => state.search);
  const setSearch = useFilterStore((state) => state.setSearch);

  const [inputValue, setInputValue] = useState(globalSearch);

  useEffect(() => {
    const handler = setTimeout(() => {
      setSearch(inputValue);
    }, debounceDelay);

    return () => clearTimeout(handler);
  }, [inputValue, debounceDelay, setSearch]);

  useEffect(() => {
    setInputValue(globalSearch);
  }, [globalSearch]);

  return (
    <div className={styles.searchWrapper}>
      <input
        className={styles.baseSearchBar}
        type="text"
        placeholder="Search"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
      />
      <img src={SearchIcon} alt="Search" className={styles.searchIcon} />
    </div>
  );
};
