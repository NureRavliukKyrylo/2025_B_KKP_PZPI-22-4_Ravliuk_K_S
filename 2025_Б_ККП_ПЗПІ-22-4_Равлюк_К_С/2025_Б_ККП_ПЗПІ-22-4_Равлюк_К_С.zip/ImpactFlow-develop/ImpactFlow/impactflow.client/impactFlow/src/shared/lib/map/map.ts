import L from "leaflet";
import UserLocationIcon from "./../../assets/user_location.png";
import ProjectIcon from "./../../assets/project_icon.png";
export const defaultMapConfig = {
  center: [50.4501, 30.5234] as [number, number],
  zoom: 13,
};

export const userMarkerIcon = new L.Icon({
  iconUrl: UserLocationIcon,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

export const ProjectMarkerIcon = new L.Icon({
  iconUrl: ProjectIcon,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});
