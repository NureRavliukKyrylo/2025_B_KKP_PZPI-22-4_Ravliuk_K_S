import React from "react";
import { useNavigate } from "react-router-dom";
import styles from "./CancelButton.module.scss";

interface CancelButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  label?: string;
}

export const CancelButton: React.FC<CancelButtonProps> = ({
  label = "Cancel",
  ...props
}) => {
  const navigate = useNavigate();

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    props.onClick?.(e);

    if (!e.defaultPrevented) {
      navigate(-1);
    }
  };

  return (
    <button
      type="button"
      className={styles.submitCancelBtn}
      onClick={handleClick}
      {...props}
    >
      {label}
    </button>
  );
};
