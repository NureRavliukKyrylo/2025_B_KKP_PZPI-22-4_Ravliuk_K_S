import { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import DefaultProfile from "../assets/default_profile.png";
import Arrow from "../assets/arrow_dropDown.png";
import LogoutIcon from "../assets/logout.png";
import { useLogout } from "../../features/auth/logout/model/useLogout";
import { BaseModal } from "../modals/confirmModal/BaseModal";
import styles from "./DropdownMenu.module.scss";

export interface MenuItem {
  label: string;
  icon?: string;
  to: string;
}

interface DropdownMenuProps {
  avatarUrl?: string;
  name?: string;
  role?: string;
  menuItems: MenuItem[];
}

export const DropdownMenu = ({
  avatarUrl,
  name,
  role,
  menuItems,
}: DropdownMenuProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isModalOpen, setModalOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const { handleLogout, isLoading } = useLogout();

  const navigate = useNavigate();

  const handleClick = () => {
    navigate("/profile");
  };

  const confirmLogout = () => {
    handleLogout();
    setModalOpen(false);
    setIsOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <>
      <img
        src={avatarUrl || DefaultProfile}
        alt="Profile avatar"
        className={styles.avatarHeader}
        onClick={() => setIsOpen(!isOpen)}
      />
      {isOpen && (
        <div className={styles.dropdownMenu}>
          {(name || role) && (
            <div className={styles.userInfo}>
              <div className={styles.avatarUserInfoDropDown}>
                <img
                  src={avatarUrl || DefaultProfile}
                  alt="Profile avatar"
                  className={styles.avatarDropDown}
                  onClick={handleClick}
                  style={{ cursor: "pointer" }}
                />
                <div className={styles.userInfoDropDown}>
                  {name && <h1 className={styles.nameDropDown}>{name}</h1>}
                  <div className={styles.roleInfoDropDown}>
                    {role && <h1 className={styles.roleDropDown}>{role}</h1>}
                    <img
                      src={Arrow}
                      alt="arrow"
                      className={styles.arrowDropDown}
                      onClick={handleClick}
                      style={{ cursor: "pointer" }}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {menuItems.map((item, idx) => (
            <Link
              key={idx}
              to={item.to}
              className={styles.menuItem}
              onClick={() => setIsOpen(false)}
            >
              {item.icon && (
                <img
                  src={item.icon}
                  alt={item.label}
                  className={styles.iconDropDown}
                />
              )}
              <p>{item.label}</p>
            </Link>
          ))}

          <div
            className={`${styles.menuItem} ${styles.logout}`}
            onClick={() => setModalOpen(true)}
          >
            <img
              src={LogoutIcon}
              alt={"logoutIcon"}
              className={styles.iconDropDown}
            />
            {isLoading ? "Logging out..." : "Log out"}
          </div>

          <BaseModal
            isOpen={isModalOpen}
            title="Log out"
            text="Are you sure you want to log out of your account? You will need to sign in again to access your dashboard and personal data."
            onConfirm={confirmLogout}
            onCancel={() => setModalOpen(false)}
          />
        </div>
      )}
    </>
  );
};
