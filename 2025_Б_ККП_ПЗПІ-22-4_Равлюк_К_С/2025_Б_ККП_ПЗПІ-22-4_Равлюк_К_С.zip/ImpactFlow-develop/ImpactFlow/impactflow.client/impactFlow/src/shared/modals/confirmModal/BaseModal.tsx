import React from "react";
import styles from "./BaseModal.module.scss";

type ConfirmModalProps = {
  isOpen: boolean;
  title: string;
  text: string;
  onConfirm: () => void;
  onCancel: () => void;
  confirmText?: string;
  cancelText?: string;
};

export const BaseModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  text,
  onConfirm,
  onCancel,
  confirmText = "Yes",
  cancelText = "No",
}) => {
  if (!isOpen) return null;

  return (
    <div className={styles.overlay} onClick={onCancel}>
      <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
        <div className={styles.modalTitle}>
          <h2 className={styles.title}>{title}</h2>
        </div>
        <div className={styles.modalText}>
          <p className={styles.textModal}>{text}</p>
        </div>
        <div className={styles.actionsModal}>
          <button className={styles.confirmBtnModal} onClick={onConfirm}>
            {confirmText}
          </button>
          <button className={styles.cancelBtnModal} onClick={onCancel}>
            {cancelText}
          </button>
        </div>
      </div>
    </div>
  );
};
