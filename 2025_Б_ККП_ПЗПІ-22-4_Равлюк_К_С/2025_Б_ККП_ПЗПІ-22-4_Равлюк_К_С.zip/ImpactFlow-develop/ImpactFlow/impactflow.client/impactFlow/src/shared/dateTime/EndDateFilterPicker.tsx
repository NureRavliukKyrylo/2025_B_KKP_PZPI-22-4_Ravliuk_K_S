import React, { useState } from "react";
import { LocalizationProvider, DatePicker } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { styled } from "@mui/material/styles";
import TextField from "@mui/material/TextField";
import IconButton from "@mui/material/IconButton";
import InputAdornment from "@mui/material/InputAdornment";
import CalendarImg from "../assets/calendar.png";
import { useFilterStore } from "../../entities/filter/store/filterStore";

const StyledTextField = styled(TextField)(({ theme }) => ({
  width: "100%",
  "& .MuiOutlinedInput-root": {
    height: 50,
    borderRadius: 10,
    paddingRight: 0,
    background: "#fff",
    boxShadow: "0 4px 8px rgba(0,0,0,.25)",
    "& fieldset": {
      borderRadius: 10,
      borderWidth: 1,
    },
    [theme.breakpoints.down("sm")]: {
      height: 40,
    },
  },
  "& input": {
    fontFamily: '"Source Serif Pro", serif',
    fontWeight: 400,
    fontSize: 22,
    padding: "12px 20px",
    cursor: "pointer",
    [theme.breakpoints.down("md")]: {
      fontSize: 20,
      padding: "10px 14px",
    },
    [theme.breakpoints.down("sm")]: {
      fontSize: 17,
      padding: "8px 12px",
    },
    [theme.breakpoints.down("xs")]: {
      fontSize: 17,
      padding: "6px 10px",
    },
  },
}));

const EndDateFilterPicker: React.FC = () => {
  const endDate = useFilterStore((s) => s.endDate);
  const setEndDate = useFilterStore((s) => s.setEndDate);
  const [open, setOpen] = useState(false);

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <DatePicker
        open={open}
        onOpen={() => setOpen(true)}
        onClose={() => setOpen(false)}
        value={endDate}
        onChange={(v) => setEndDate(v)}
        format="dd MMMM yyyy"
        enableAccessibleFieldDOMStructure={false}
        slots={{
          textField: (params) => (
            <StyledTextField
              {...params}
              variant="outlined"
              InputProps={{
                ...params.InputProps,
                readOnly: true,
                endAdornment: (
                  <InputAdornment position="end" sx={{ pr: 2 }}>
                    <IconButton
                      edge="end"
                      size="small"
                      sx={{ p: 0 }}
                      onClick={() => setOpen(true)}
                    >
                      <img
                        src={CalendarImg}
                        alt="calendar"
                        width={26}
                        height={26}
                      />
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          ),
        }}
      />
    </LocalizationProvider>
  );
};

export default EndDateFilterPicker;
