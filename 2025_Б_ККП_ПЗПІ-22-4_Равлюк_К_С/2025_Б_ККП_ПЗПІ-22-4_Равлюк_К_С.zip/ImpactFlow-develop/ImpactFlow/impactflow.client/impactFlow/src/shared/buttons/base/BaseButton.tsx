import React from "react";
import styles from "./BaseButton.module.scss";

interface BaseButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  label?: string;
}

export const BaseButton: React.FC<BaseButtonProps> = ({
  label = "Edit profile",
  ...props
}) => {
  return (
    <button type="submit" className={styles.submitBaseBtn} {...props}>
      {label}
    </button>
  );
};
