import type { ReactNode } from "react";
import type { FormikProps } from "formik";
import styles from "./CreateModal.module.scss";
import { useErrorStore } from "../../../entities/error";

interface Props<T> {
  formik: FormikProps<T>;
  title: string;
  description: string;
  children: ReactNode;
  onClose: () => void;
  submitText?: string;
}

export const CreateModal = <T,>({
  formik,
  title,
  description,
  children,
  onClose,
  submitText = "Add",
}: Props<T>) => {
  const { error: errorMessage, clearError } = useErrorStore();
  const handleClose = () => {
    clearError();
    onClose();
  };
  return (
    <div className={styles.overlayCreate} onClick={onClose}>
      <div className={styles.modalCreate} onClick={(e) => e.stopPropagation()}>
        <form onSubmit={formik.handleSubmit}>
          <div className={styles.modalCreateTitle}>
            <h1 className={styles.title}>{title}</h1>
          </div>

          <div className={styles.modalCreateText}>
            <p className={styles.textCreateModal}>{description}</p>
          </div>

          <div className={styles.modalCreateContent}>{children}</div>
          <div className={styles.actionsCreateModal}>
            <button
              type="submit"
              className={styles.manageBtnModal}
              disabled={formik.isSubmitting}
            >
              {formik.isSubmitting ? "Loading..." : submitText}
            </button>
            <button
              type="button"
              className={styles.cancelCreateBtnModal}
              onClick={handleClose}
            >
              Cancel
            </button>
          </div>
        </form>
        {errorMessage && <div className="errorBtn">{errorMessage}</div>}
      </div>
    </div>
  );
};
