import { NavbarContainer } from "../../shared/containers/navbar/NavbarContainer";
import { NavigationLink } from "../../shared/navLinks/NavigationLink";
import LogoFlow from "../../shared/assets/logo_impact_flow.png";
import styles from "../../widgets/header/HeaderWidget.module.scss";
import { navItemsByRole } from "../lib/navbar/navbarConfig";
import { useProfileStore } from "../../entities/user/volunteer/types/profileAvatarStore";

export const NavigationMenu = () => {
  const role = useProfileStore((state) => state.role) || "guest";
  const nav = navItemsByRole[role] || navItemsByRole["guest"];

  return (
    <NavbarContainer>
      <div className={styles.leftLinks}>
        {nav.left.map((item) => (
          <NavigationLink key={item.to} to={item.to} label={item.label} />
        ))}
      </div>

      <div className={styles.centerLogo}>
        <img src={LogoFlow} alt="Logo Flow" className={styles.logoImpactFlow} />
      </div>

      <div className={styles.rightLinks}>
        {nav.right.map((item) => (
          <NavigationLink key={item.to} to={item.to} label={item.label} />
        ))}
      </div>
    </NavbarContainer>
  );
};
