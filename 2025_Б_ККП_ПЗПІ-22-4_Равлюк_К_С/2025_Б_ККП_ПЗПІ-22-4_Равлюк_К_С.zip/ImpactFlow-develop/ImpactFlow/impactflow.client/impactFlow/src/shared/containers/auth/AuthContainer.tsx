import React from "react";
import styles from "./AuthContainer.module.scss";
import "./../../../features/auth/login/ui/LoginForm.module.scss";
import LogoFlow from "../../assets/logoFlow.png";

interface AuthContainerProps {
  children: React.ReactNode;
  variant?: "login" | "register";
}

export const AuthContainer: React.FC<AuthContainerProps> = ({
  children,
  variant,
}) => {
  return (
    <div className={styles.authContainer}>
      <img className={styles.logo} src={LogoFlow} alt="Logo" />
      <div
        className={`${styles.authForm} ${
          variant === "register" ? styles.register : styles.login
        }`}
      >
        {children}
      </div>
    </div>
  );
};
