import { useQuery } from "@tanstack/react-query";
import { useProfileStore } from "../../../../entities/user/volunteer/types/profileAvatarStore";
import { getUserRole } from "../api/getUserRole";
import { useEffect, useRef } from "react";

export const useGetRole = () => {
  const previousData = useRef<{ role: string } | null>(null);
  const { role, setRole } = useProfileStore();

  const query = useQuery<{ role: string }>({
    queryKey: ["userRoute"],
    queryFn: async () => {
      console.log("🔄 Виконується API-запит до getUserRole");
      const role = await getUserRole();
      const result = { role };
      previousData.current = result;
      return result;
    },
    staleTime: 1000 * 60 * 5,
    retry: false,
    refetchInterval: 1000 * 60 * 1,
    refetchOnWindowFocus: false,
    initialData: role ? { role: role } : undefined,
  });

  const { data, isSuccess } = query;
  console.log(data);

  useEffect(() => {
    if (isSuccess && data) {
      setRole(data.role);
    }
  }, [data, isSuccess, setRole]);

  return {
    ...query,
    data: data ?? previousData.current,
  };
};
