import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { LoginPage } from "../../pages";
import { RegistrationPage } from "../../pages/auth/RegistrationPage";
import { ProfilePage } from "../../pages/profile/ProfilePage";
import { EditProfilePage } from "../../pages/profile/EditProfilePage";
import { CategoryPage } from "../../pages/categories/CategoryPage";
import { VolunteersProjectPage } from "../../pages/volunteerProject/VolunteerProjectPage";
import { SignedVolunteerProjectPage } from "../../pages/signedVolunteerProjectPage/SignedVolunteerProjectPage";
import { SkillsAdminPage } from "../../pages/skills/SkillsAdminPage";
import { SkillsVolunteerPage } from "../../pages/skills/SkillsVolunteerPage";
import { SkillsVolunteerAddingPage } from "../../pages/skills/SkillsVolunteerAddingPage";
import { InitiativeDetailPage } from "../../pages/initiative/InitiativeDetailPage";
import { UsersAdminPage } from "../../pages/users/UsersAdminPage";
import { MyInitiativesPage } from "../../pages/myInitiatives/MyInitiativesPage";
import { CreateInitiativePage } from "../../pages/myInitiatives/CreateInitiativePage";
import { EditInitiativePage } from "../../pages/myInitiatives/EditInitiativePage";
import { InteractiveMapPage } from "../../pages/interactiveMap/InteractiveMapPage";
import { ForbiddenPage } from "../../pages/additional/forbidden/ForbiddenPage";
import ProtectedRoute from "../providers/routeGuards/ui/ProtectedRoute";
import { InitiativesListPage } from "../../pages/initiative/InitiativesListPage";
import { HomePage } from "../../pages/home/HomePage";
import { ContactsPage } from "../../pages/contacts/ContactsPage";
import { NotFoundPage } from "../../pages/notFound/NotFoundPage";
import { ForgotPasswordPage } from "../../pages/auth/ForgotPasswordPage";
import { ResetPasswordPage } from "../../pages/auth/ResetPasswordPage";
import { CheckEmailPage } from "../../pages/auth/CheckEmailPage";

const router = createBrowserRouter([
  {
    path: "/",
    element: <HomePage />,
  },
  {
    path: "/login",
    element: <LoginPage />,
  },
  {
    path: "/register",
    element: <RegistrationPage />,
  },
  {
    path: "/profile",
    element: (
      <ProtectedRoute allowedRoles={["Admin", "Initiator", "Volunteer"]}>
        <ProfilePage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/profile/edit",
    element: (
      <ProtectedRoute allowedRoles={["Admin", "Initiator", "Volunteer"]}>
        <EditProfilePage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/admin/categories",
    element: (
      <ProtectedRoute allowedRoles={["Admin"]}>
        <CategoryPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/initiator-initiatives/volunteers/:projectId",
    element: (
      <ProtectedRoute allowedRoles={["Initiator", "Admin"]}>
        <VolunteersProjectPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/volunteer-initiatives",
    element: (
      <ProtectedRoute allowedRoles={["Volunteer", "Initiator"]}>
        <SignedVolunteerProjectPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "admin/skills",
    element: (
      <ProtectedRoute allowedRoles={["Admin"]}>
        <SkillsAdminPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/my-skills",
    element: (
      <ProtectedRoute allowedRoles={["Volunteer"]}>
        <SkillsVolunteerPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/my-skills/adding",
    element: (
      <ProtectedRoute allowedRoles={["Volunteer"]}>
        <SkillsVolunteerAddingPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "admin/users",
    element: (
      <ProtectedRoute allowedRoles={["Admin"]}>
        <UsersAdminPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "map",
    element: (
      <ProtectedRoute allowedRoles={["Admin", "Initiator", "Volunteer"]}>
        <InteractiveMapPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/initiatives/:id",
    element: (
      <ProtectedRoute allowedRoles={["Admin", "Initiator", "Volunteer"]}>
        <InitiativeDetailPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/initiator-initiatives",
    element: (
      <ProtectedRoute allowedRoles={["Initiator", "Admin"]}>
        <MyInitiativesPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/initiator-initiatives/create",
    element: (
      <ProtectedRoute allowedRoles={["Initiator", "Admin"]}>
        <CreateInitiativePage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/initiator-initiatives/edit/:id",
    element: (
      <ProtectedRoute allowedRoles={["Initiator", "Admin"]}>
        <EditInitiativePage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/initiatives",
    element: (
      <ProtectedRoute allowedRoles={["Admin", "Initiator", "Volunteer"]}>
        <InitiativesListPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/home",
    element: (
      <ProtectedRoute allowedRoles={["Admin", "Initiator", "Volunteer"]}>
        <HomePage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/contacts",
    element: (
      <ProtectedRoute allowedRoles={["Admin", "Initiator", "Volunteer"]}>
        <ContactsPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/*",
    element: <NotFoundPage />,
  },
  { path: "forbidden", element: <ForbiddenPage /> },
  { path: "forgot-password", element: <ForgotPasswordPage /> },
  { path: "reset-password", element: <ResetPasswordPage /> },
  { path: "check-email", element: <CheckEmailPage /> },
]);

export const AppRouter = () => <RouterProvider router={router} />;
