import { Navigate } from "react-router-dom";
import { useGetRole } from "../model/useGetUserRole";
import { useProfileStore } from "../../../../entities/user/volunteer/types/profileAvatarStore";

const ProtectedRoute = ({
  allowedRoles,
  children,
}: {
  allowedRoles: string[];
  children: React.ReactNode;
}) => {
  useGetRole();

  const role = useProfileStore((state) => state.role);

  if (!role) {
    return <Navigate to="/login" replace />;
  }

  if (!allowedRoles.includes(role)) {
    return <Navigate to="/forbidden" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
