import { apiClient } from "../../../../shared/api";

export const getUserRole = async () => {
  const response = await apiClient.get<{ role: string }>("Auth/role");

  return response.data.role;
};
