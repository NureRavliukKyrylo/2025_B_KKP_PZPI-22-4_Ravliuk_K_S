import { apiClient } from "../../../../shared/api";
import type { CategoryDto } from "../../../../entities/category/types/categoryTypes";
import type { Category } from "../../../../entities/category/types/categoryTypes";

export const createCategory = async (data: CategoryDto): Promise<Category> => {
  const response = await apiClient.post<Category>("Categories/create", data);
  return response.data;
};
