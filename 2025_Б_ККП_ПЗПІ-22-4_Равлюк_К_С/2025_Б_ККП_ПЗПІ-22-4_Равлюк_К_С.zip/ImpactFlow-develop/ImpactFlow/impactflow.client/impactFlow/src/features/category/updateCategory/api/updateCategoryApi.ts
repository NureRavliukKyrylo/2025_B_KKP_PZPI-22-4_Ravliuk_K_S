import { apiClient } from "../../../../shared/api";
import type { Category } from "../../../../entities/category/types/categoryTypes";
import type { CategoryDto } from "../../../../entities/category/types/categoryTypes";

export const updateCategory = async (
  id: string,
  data: CategoryDto
): Promise<Category> => {
  const response = await apiClient.put<Category>(
    `/Categories/update/${id}`,
    data
  );
  return response.data;
};
