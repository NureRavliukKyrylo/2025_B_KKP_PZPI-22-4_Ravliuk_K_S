import { apiClient } from "../../../../shared/api";

export const forgotPass = async (email: string) => {
  const response = await apiClient.post("Auth/forgot-password", { email });
  return response.data;
};
