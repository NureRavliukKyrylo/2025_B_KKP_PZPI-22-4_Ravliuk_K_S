import React, { useState } from "react";
import { BaseModal } from "../../../../shared/modals/confirmModal/BaseModal";
import { useDeleteInitiative } from "../../../../entities/myInitiatives/model/useDeleteInitiative";
import TrashIcon from "../../../../shared/assets/trash.png";

export interface DeleteInitiativeButtonProps {
  initiativeId: string;
  className?: string;
  iconClassName?: string;
}

export const DeleteInitiativeButton: React.FC<DeleteInitiativeButtonProps> = ({
  initiativeId,
  className,
  iconClassName,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const { mutate, isPending } = useDeleteInitiative();

  const onConfirm = () => {
    mutate(initiativeId, {
      onSettled: () => setIsOpen(false),
    });
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className={className}
        disabled={isPending}
      >
        <img
          src={TrashIcon}
          alt="Delete initiative"
          className={iconClassName}
        />
      </button>

      <BaseModal
        isOpen={isOpen}
        title="Delete initiative"
        text="Are you sure you want to delete this initiative? Once you delete an initiative, you can't take it back. Think before you decide."
        confirmText="Yes"
        cancelText="No"
        onConfirm={onConfirm}
        onCancel={() => setIsOpen(false)}
      />
    </>
  );
};
