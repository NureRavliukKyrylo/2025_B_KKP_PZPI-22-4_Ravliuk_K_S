import { useMutation, useQueryClient } from "@tanstack/react-query";
import { updateLevelSkill } from "../api/updateLevelSkill";
import type { SkillsVolunteerDto } from "../../../../../entities/skills/volunteer/types/skillsTypes";
import { useErrorStore } from "../../../../../entities/error";
import { useMessageStore } from "../../../../../entities/message/MessageStore";

export const useUpdateSkillLevel = () => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  const mutation = useMutation({
    mutationFn: (data: SkillsVolunteerDto) => updateLevelSkill(data),
    onSuccess: () => {
      clearError();
      setMessage("Skill level updated successfully", "success");
      queryClient.invalidateQueries({ queryKey: ["mySkills"] });
    },
    onError: (error) => {
      console.error("ERROR:", error);
      setError("ERROR.");
      setMessage("Failed to update skill level", "error");
    },
  });

  return {
    updateLevel: mutation.mutate,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
