import { useUserStore } from "../../../entities/user/volunteer/types/userStore";
import { useFormik } from "formik";
import { useUpdateUser } from "./useUpdateUser";
import { useProfileStore } from "../../../entities/user/volunteer/types/profileAvatarStore";
import { useUserLocationStore } from "../../../entities/user/volunteer/types/locationStore";
import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { parseISO, format } from "date-fns";
import { editProfileSchema } from "../libs/editProfileSchema";

const normalizeUTCDate = (isoString: string): Date => {
  const [year, month, day] = isoString.split("T")[0].split("-");
  const date = new Date(Number(year), Number(month) - 1, Number(day));
  date.setHours(0, 0, 0, 0);
  return date;
};

export const useEditProfileForm = () => {
  const user = useUserStore((state) => state.user);
  const mutation = useUpdateUser();
  const setFullName = useProfileStore((state) => state.setFullName);
  const coordinates = useUserLocationStore((state) => state.coordinates);
  const initializeCoordinates = useUserLocationStore(
    (s) => s.initializeCoordinates
  );

  const [hasCheckedProfile, setHasCheckedProfile] = useState(false);
  const queryClient = useQueryClient();

  const formik = useFormik({
    initialValues: {
      fullName: user?.fullName || "",
      email: user?.email || "",
      bio: user?.profile?.bio || "",
      phone: user?.profile?.phone || "",
      telegram: user?.profile?.telegram || "",
      dateOfBirth: user?.profile?.dateOfBirth
        ? normalizeUTCDate(user.profile.dateOfBirth)
        : null,
      coordinates: coordinates ?? null,
    },
    validationSchema: editProfileSchema,
    enableReinitialize: true,
    onSubmit: (values) => {
      if (!user) return;

      const cleanedProfile = {
        ...(values.bio && { bio: values.bio }),
        ...(values.phone && { phone: values.phone }),
        ...(values.telegram && { telegram: values.telegram }),
        ...(values.dateOfBirth && {
          dateOfBirth: format(values.dateOfBirth, "yyyy-MM-dd"),
        }),
        ...(values.coordinates &&
          typeof values.coordinates.lat === "number" &&
          typeof values.coordinates.lng === "number" && {
            coordinates: {
              longitude: values.coordinates.lng,
              latitude: values.coordinates.lat,
            },
          }),
      };

      const payload = {
        fullName: values.fullName,
        email: values.email,
        profile: cleanedProfile,
      };

      mutation.mutate(payload, {
        onSuccess: () => {
          setFullName(values.fullName);
          if (values.coordinates) {
            useProfileStore.getState().setLongitude(values.coordinates.lng);
            useProfileStore.getState().setLatitude(values.coordinates.lat);
          }
        },
      });
    },
  });

  useEffect(() => {
    const userData = queryClient.getQueryData(["userProfile"]);
    if (userData || user === null) {
      setHasCheckedProfile(true);
    }
  }, [queryClient, user]);

  useEffect(() => {
    if (hasCheckedProfile && coordinates === null) {
      initializeCoordinates();
    }
  }, [hasCheckedProfile, coordinates, initializeCoordinates]);

  return {
    formik,
    isSubmitting: mutation.isPending,
  };
};
