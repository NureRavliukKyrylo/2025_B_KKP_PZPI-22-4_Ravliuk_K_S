import { useForgotPass } from "../model/useForgotPass";
import { useErrorStore } from "../../../../entities/error";
import styles from "./ForgotPasswordForm.module.scss";
import { Input } from "../../../../shared/inputs/Input";
import { AuthButton } from "../../../../shared/buttons/auth/AuthButton";

export const ForgotPasswordForm = () => {
  const { formik, isLoading } = useForgotPass();
  const { error: errorMessage } = useErrorStore();

  return (
    <div className={styles.forgotPassContainer}>
      <div className={styles.headerForgotPass}>
        <h2>Forgot password </h2>
        <h3>Forgot your password? Enter your email to reset your password</h3>
      </div>

      <form onSubmit={formik.handleSubmit} className={styles.forgotPassForm}>
        <div className={styles.inputForgotPass}>
          <Input
            id="email"
            name="email"
            type="email"
            label="Email Address or username"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.email}
            error={formik.submitCount > 0 ? formik.errors.email : ""}
          />
        </div>

        <AuthButton loading={isLoading} label="Recover Password" />
      </form>
      {errorMessage && <div className="errorBtn">{errorMessage}</div>}
    </div>
  );
};
