import * as Yup from "yup";

export const registerSchema = Yup.object({
  agreeToTerms: Yup.boolean().oneOf([true], "You must agree to the terms"),

  fullName: Yup.string()
    .matches(
      /^[A-Za-zА-Яа-яЁёІіЇїЄєҐґ\s'-]+$/,
      "Please enter a valid full name"
    )
    .min(2, "Name is too short")
    .max(50, "Name is too long")
    .required("Full name is required"),
  email: Yup.string()
    .email("Please enter a valid email address")
    .required("Email is required"),
  password: Yup.string()
    .min(6, "Password must be at least 6 characters")
    .required("Password is required"),
});
