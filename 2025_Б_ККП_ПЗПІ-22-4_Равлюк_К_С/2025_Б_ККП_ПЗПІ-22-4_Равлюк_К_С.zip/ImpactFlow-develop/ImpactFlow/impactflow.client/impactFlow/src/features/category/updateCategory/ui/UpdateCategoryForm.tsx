import React from "react";
import { Input } from "../../../../shared/inputs/Input";
import { TextArea } from "../../../../shared/textAreas/TextArea";
import type { FormikProps } from "formik";
import type { CategoryDto } from "../../../../entities/category/types/categoryTypes";

interface Props {
  formik: FormikProps<CategoryDto>;
}

export const UpdateCategoryForm: React.FC<Props> = ({ formik }) => {
  return (
    <>
      <Input
        name="name"
        label="Title"
        value={formik.values.name}
        onChange={formik.handleChange}
        error={formik.submitCount > 0 ? formik.errors.name : ""}
      />

      <TextArea
        name="description"
        placeholder="Description"
        value={formik.values.description}
        onChange={formik.handleChange}
        error={formik.submitCount > 0 ? formik.errors.description : ""}
      />
    </>
  );
};
