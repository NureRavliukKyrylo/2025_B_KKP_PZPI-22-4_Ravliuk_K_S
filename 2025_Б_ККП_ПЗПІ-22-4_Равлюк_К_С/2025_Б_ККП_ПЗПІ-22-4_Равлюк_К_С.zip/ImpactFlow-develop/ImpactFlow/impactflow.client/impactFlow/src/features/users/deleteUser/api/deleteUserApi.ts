import { apiClient } from "../../../../shared/api";

export const deleteUser = async (userId: string): Promise<void> => {
  await apiClient.delete("User/admin-delete/", {
    params: {
      userId: userId,
    },
  });
};
