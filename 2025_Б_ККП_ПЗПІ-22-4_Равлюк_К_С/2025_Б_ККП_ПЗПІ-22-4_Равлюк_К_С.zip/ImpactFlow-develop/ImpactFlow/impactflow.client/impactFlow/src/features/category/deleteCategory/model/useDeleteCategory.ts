import { useMutation, useQueryClient } from "@tanstack/react-query";
import { deleteCategory } from "../api/deleteCategoryApi";
import { useErrorStore } from "../../../../entities/error";
import { useMessageStore } from "../../../../entities/message/MessageStore";

export const useDeleteCategory = () => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  return useMutation({
    mutationFn: (id: string) => deleteCategory(id),
    onSuccess: () => {
      clearError();
      setMessage("Category deleted successfully", "success");
      queryClient.invalidateQueries({ queryKey: ["categories"] });
    },
    onError: (error) => {
      console.error("ERROR:", error);
      setError("ERROR.");
      setMessage("Failed to delete category", "error");
    },
  });
};
