import React, { useState } from "react";
import { BaseModal } from "../../../../../shared/modals/confirmModal/BaseModal";
import { useDeleteSkill } from "../model/useDeleteSkill";
import styles from "./DeleteSkillButton.module.scss";
import DeleteIcon from "../../../../../shared/assets/delete_icon.png";

interface Props {
  skillId: string;
  skillName: string;
}

export const DeleteSkillButton: React.FC<Props> = ({ skillId, skillName }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { mutate: deleteSkill, isPending } = useDeleteSkill();

  const handleConfirm = () => {
    deleteSkill(skillId, {
      onSuccess: () => {
        setIsOpen(false);
      },
    });
  };

  return (
    <>
      <img
        src={DeleteIcon}
        onClick={() => setIsOpen(true)}
        className={styles.buttonImageDeleteSkill}
        alt="Delete skill"
      />

      <BaseModal
        isOpen={isOpen}
        title="Delete skill"
        text={`Are you sure you want to delete this skill "${skillName}"? Think before you decide`}
        onConfirm={handleConfirm}
        onCancel={() => setIsOpen(false)}
        confirmText={isPending ? "Deleting..." : "Yes"}
        cancelText="No"
      />
    </>
  );
};
