import React, { useState } from "react";
import { BaseModal } from "../../../../shared/modals/confirmModal/BaseModal";
import styles from "./LeaveProjectButton.module.scss";
import { useLeaveProject } from "../model/useLeaveProject";

interface Props {
  projectId: string;
}

export const LeaveProjectButton: React.FC<Props> = ({ projectId }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { mutate: leaveProject, isPending } = useLeaveProject();

  const handleConfirm = () => {
    leaveProject(projectId, {
      onSuccess: () => {
        setIsOpen(false);
      },
    });
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className={styles.buttonLeaveProject}
      >
        Leave Project
      </button>

      <BaseModal
        isOpen={isOpen}
        title="Leave Project"
        text={`Are you sure you want to leave this project? This action cannot be undone.`}
        onConfirm={handleConfirm}
        onCancel={() => setIsOpen(false)}
        confirmText={isPending ? "Leaving..." : "Yes"}
        cancelText="No"
      />
    </>
  );
};
