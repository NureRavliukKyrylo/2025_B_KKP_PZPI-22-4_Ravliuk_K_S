import React, { useState } from "react";
import { BaseModal } from "../../../../../shared/modals/confirmModal/BaseModal";
import { useRemoveVolunteerSkill } from "../model/useRemoveVolunteerSkill";
import styles from "./RemoveSkillButton.module.scss";
import DeleteIcon from "../../../../../shared/assets/delete_icon.png";

interface Props {
  skillId: string;
  skillName: string;
}

export const RemoveSkillButton: React.FC<Props> = ({ skillId, skillName }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { mutate: deleteSkill, isPending } = useRemoveVolunteerSkill();

  const handleConfirm = () => {
    deleteSkill(skillId, {
      onSuccess: () => {
        setIsOpen(false);
      },
    });
  };

  return (
    <>
      <img
        src={DeleteIcon}
        onClick={() => setIsOpen(true)}
        className={styles.buttonImageRemoveSkill}
        alt="Remove skill"
      />

      <BaseModal
        isOpen={isOpen}
        title="Remove skill"
        text={`Are you sure you want to remove this skill "${skillName}"? Think before you decide`}
        onConfirm={handleConfirm}
        onCancel={() => setIsOpen(false)}
        confirmText={isPending ? "Deleting..." : "Yes"}
        cancelText="No"
      />
    </>
  );
};
