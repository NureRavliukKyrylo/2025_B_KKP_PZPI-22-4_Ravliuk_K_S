import React, { useState } from "react";
import { useAssignSkill } from "../model/useAssignSkill";
import type { Level } from "../../../../../entities/skills/volunteer/types/skillsTypes";
import { levelMap } from "../../../../../entities/skills/volunteer/types/skillsTypes";
import { CustomSelect } from "../../../../../shared/select/CustomSelect";
import AssignIcon from "../../../../../shared/assets/assign_icon.png";
import styles from "./SkillAsignSelector.module.scss";

interface SkillLevelSelectorProps {
  skillId: string;
  initialLevel?: Level;
}

export const SkillAssignSelector: React.FC<SkillLevelSelectorProps> = ({
  skillId,
  initialLevel = 0,
}) => {
  const [selectedLevel, setSelectedLevel] = useState<Level>(initialLevel);
  const { updateLevel, isLoading } = useAssignSkill();

  const handleAssign = () => {
    updateLevel({
      skillId,
      level: selectedLevel,
    });
  };

  const options = Object.entries(levelMap).map(([key, label]) => ({
    value: Number(key) as Level,
    label,
  }));

  return (
    <div className={styles.assignSkillSelectBlock}>
      <CustomSelect
        value={selectedLevel}
        onChange={setSelectedLevel}
        options={options}
        disabled={isLoading}
      />
      <button
        onClick={handleAssign}
        disabled={isLoading}
        className={styles.buttonAssignSkill}
      >
        <h1>Add</h1>
        <img
          src={AssignIcon}
          className={styles.buttonImageAssignSkill}
          alt="Assign skill"
        />
      </button>
    </div>
  );
};
