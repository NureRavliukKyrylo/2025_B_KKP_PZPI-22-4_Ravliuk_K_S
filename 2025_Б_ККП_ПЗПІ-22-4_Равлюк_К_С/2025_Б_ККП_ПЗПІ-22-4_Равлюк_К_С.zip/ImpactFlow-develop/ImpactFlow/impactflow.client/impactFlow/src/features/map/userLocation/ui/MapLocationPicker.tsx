import {
  MapContainer,
  TileLayer,
  Marker,
  useMapEvents,
  Popup,
} from "react-leaflet";
import { userMarkerIcon } from "../../../../shared/lib/map/map";
import type { FormikProps } from "formik";
import type { LatLng } from "leaflet";
import "leaflet/dist/leaflet.css";
import { MapZoomAnimation } from "../../../../shared/lib/map/ZoomAnimation";
import styles from "./MapLocationPicker.module.scss";
interface Props {
  formik: FormikProps<any>;
}

const SyncMapEvents = ({ formik }: Props) => {
  useMapEvents({
    contextmenu(e) {
      const latlng: LatLng = e.latlng;
      formik.setFieldValue("coordinates", {
        lat: latlng.lat,
        lng: latlng.lng,
      });
    },
  });

  return null;
};

export const MapLocationPicker: React.FC<Props> = ({ formik }) => {
  const { coordinates } = formik.values;
  const defaultPosition: [number, number] = [50.4501, 30.5234];

  const position: [number, number] =
    coordinates?.lat != null && coordinates?.lng != null
      ? [coordinates.lat, coordinates.lng]
      : defaultPosition;

  return (
    <MapContainer
      center={position}
      zoom={13}
      zoomControl={false}
      style={{ height: "300px", border: "1px solid black" }}
    >
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {coordinates?.lat != null && coordinates?.lng != null && (
        <Marker
          position={[coordinates.lat, coordinates.lng]}
          icon={userMarkerIcon}
        >
          <Popup className={styles.customPopup}>
            <div className={styles.blockUserLocation}>
              <h1>Your Location</h1>
            </div>
          </Popup>
        </Marker>
      )}
      <SyncMapEvents formik={formik} />
      <MapZoomAnimation coordinates={coordinates} />
    </MapContainer>
  );
};
