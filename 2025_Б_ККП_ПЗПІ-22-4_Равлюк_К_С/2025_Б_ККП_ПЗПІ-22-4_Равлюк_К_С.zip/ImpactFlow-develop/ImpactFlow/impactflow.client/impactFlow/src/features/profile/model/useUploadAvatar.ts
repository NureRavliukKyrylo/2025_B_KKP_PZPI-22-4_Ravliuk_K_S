import { useMutation, useQueryClient } from "@tanstack/react-query";
import { uploadAvatar } from "../api/editProfileApi";
import { useErrorStore } from "../../../entities/error";
import { useMessageStore } from "../../../entities/message/MessageStore";

export const useUploadAvatar = () => {
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: uploadAvatar,
    onSuccess: () => {
      clearError();
      setMessage("Profile picture updated successfully", "success");
      console.log("Avatar uploaded successfully");

      queryClient.invalidateQueries({ queryKey: ["userProfile"] });
    },
    onError: (error: any) => {
      console.error("Avatar upload error:", error);
      const errorMessage =
        error?.response?.data?.error || "Failed to change avatar. Try again.";
      setError(errorMessage);
      setMessage("Failed to update profile picture", "error");
    },
  });
};
