// impactFlow/src/features/volunteerProject/joinProject/ui/JoinProjectButton.tsx
import React, { useState } from "react";
import { BaseModal } from "../../../../shared/modals/confirmModal/BaseModal";
import styles from "./JoinProjectButton.module.scss";
import { useJoinProject } from "../model/useJoinProject";

interface Props {
  projectId: string;
}

export const JoinProjectButton: React.FC<Props> = ({ projectId }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { mutate: joinProject, status } = useJoinProject();
  const isJoining = status === "pending";

  const handleConfirm = () => {
    joinProject(projectId, {
      onSuccess: () => {
        setIsOpen(false);
      },
    });
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className={styles.buttonJoinProject}
        disabled={isJoining}
      >
        {isJoining ? "Joining..." : "Join Project"}
      </button>

      <BaseModal
        isOpen={isOpen}
        title="Join Initiative"
        text="Are you sure you want to join this project?"
        onConfirm={handleConfirm}
        onCancel={() => setIsOpen(false)}
        confirmText={isJoining ? "Joining..." : "Yes"}
        cancelText="No"
      />
    </>
  );
};
