import { useFormik } from "formik";
import { useMutation } from "@tanstack/react-query";
import { registerSchema } from "../libs/registerSchema";
import { useErrorStore } from "../../../../entities/error";
import { useNavigate } from "react-router-dom";
import { register, type RegisterDto } from "../api/registerApi";
import { useProfileStore } from "../../../../entities/user/volunteer/types/profileAvatarStore";

export const useRegister = () => {
  const { setError, clearError } = useErrorStore();
  const navigate = useNavigate();

  const mutation = useMutation({
    mutationFn: (data: RegisterDto) => register(data),
    onSuccess: (data) => {
      const { avatarUrl, fullName, role, latitude, longitude } = data;
      useProfileStore.getState().setAvatarUrl(avatarUrl);
      useProfileStore.getState().setFullName(fullName);
      useProfileStore.getState().setRole(role);
      useProfileStore.getState().setLatitude(latitude);
      useProfileStore.getState().setLongitude(longitude);
      console.log("Registration success:", data);
      clearError();
      navigate("/home");
    },
    onError: (error: any) => {
      console.error("Registration error:", error);
      const errorMessage =
        error?.response?.data?.error || "Failed to register. Please try again.";

      setError(errorMessage);
    },
  });

  const formik = useFormik({
    initialValues: {
      fullName: "",
      email: "",
      password: "",
      agreeToTerms: false,
    },
    validationSchema: registerSchema,
    onSubmit: (values) => {
      mutation.mutate(values);
    },
  });

  return {
    formik,
    handleSubmit: formik.handleSubmit,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
