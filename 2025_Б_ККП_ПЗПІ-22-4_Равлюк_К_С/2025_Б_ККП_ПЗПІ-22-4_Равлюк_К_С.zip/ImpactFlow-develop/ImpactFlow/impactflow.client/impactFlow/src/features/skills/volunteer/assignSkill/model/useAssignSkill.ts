import { useMutation, useQueryClient } from "@tanstack/react-query";
import { assignSkill } from "../api/assignSkillApi";
import type { SkillsVolunteerDto } from "../../../../../entities/skills/volunteer/types/skillsTypes";
import { useErrorStore } from "../../../../../entities/error";
import { useMessageStore } from "../../../../../entities/message/MessageStore";

export const useAssignSkill = () => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  const mutation = useMutation({
    mutationFn: (data: SkillsVolunteerDto) => assignSkill(data),
    onSuccess: () => {
      clearError();
      setMessage("Skill level asigned successfully", "success");
      queryClient.invalidateQueries({ queryKey: ["mySkills"] });
    },
    onError: (error) => {
      console.error("ERROR:", error);
      setError("ERROR.");
      setMessage("Failed to asign skill", "error");
    },
  });

  return {
    updateLevel: mutation.mutate,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
