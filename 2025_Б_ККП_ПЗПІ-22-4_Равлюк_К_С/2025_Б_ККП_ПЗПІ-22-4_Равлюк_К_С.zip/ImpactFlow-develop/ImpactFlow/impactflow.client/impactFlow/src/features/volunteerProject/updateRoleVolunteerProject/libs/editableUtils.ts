export const placeCursorAtEnd = (element: HTMLElement) => {
  const range = document.createRange();
  const selection = window.getSelection();
  range.selectNodeContents(element);
  range.collapse(false);
  selection?.removeAllRanges();
  selection?.addRange(range);
};

export const handleKeyDownEditable = (
  e: React.KeyboardEvent,
  onSubmit: (e: React.FormEvent) => void,
  onCancel: () => void
) => {
  if (e.key === "Escape") {
    e.preventDefault();
    onCancel();
  } else if (e.key === "Enter") {
    e.preventDefault();
    onSubmit(e as unknown as React.FormEvent);
  }
};
