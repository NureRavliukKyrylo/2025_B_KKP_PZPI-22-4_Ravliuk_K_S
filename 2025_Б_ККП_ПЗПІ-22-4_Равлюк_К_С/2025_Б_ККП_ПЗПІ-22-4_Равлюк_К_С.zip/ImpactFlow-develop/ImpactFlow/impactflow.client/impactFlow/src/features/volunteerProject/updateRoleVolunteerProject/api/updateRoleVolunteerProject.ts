import { apiClient } from "../../../../shared/api";

type AssignRoleDto = {
  projectId: string;
  volunteerId: string;
  roleInProject: string;
};

export const assignUserRole = async (data: AssignRoleDto): Promise<void> => {
  await apiClient.put("/Projects/participation/assign-role", data);
};
