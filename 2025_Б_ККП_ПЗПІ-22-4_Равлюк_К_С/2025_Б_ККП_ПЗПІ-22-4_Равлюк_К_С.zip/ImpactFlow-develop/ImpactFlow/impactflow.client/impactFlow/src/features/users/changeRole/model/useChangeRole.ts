import { useMutation, useQueryClient } from "@tanstack/react-query";
import { changeRole } from "../api/changeRoleApi";
import type { ChangeRole } from "../../../../entities/user/admin/types/usersDetails";
import { useFormik } from "formik";
import { useErrorStore } from "../../../../entities/error";
import { useMessageStore } from "../../../../entities/message/MessageStore";

export const useChangeRole = (
  initialValues: ChangeRole,
  onSuccess?: () => void
) => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  const formik = useFormik({
    initialValues,
    enableReinitialize: true,
    onSubmit: (values, { setSubmitting }) => {
      console.log("Submitting values:", values);
      mutation.mutate(
        { data: values },
        {
          onSettled: () => {
            setSubmitting(false);
          },
        }
      );
    },
  });

  const mutation = useMutation({
    mutationFn: ({ data }: { data: ChangeRole }) => changeRole(data),
    onSuccess: () => {
      clearError();
      formik.resetForm();
      onSuccess?.();
      setMessage("Role updated successfully", "success");
      console.log(formik);
      queryClient.invalidateQueries({ queryKey: ["usersAdmin"] });
    },
    onError: (error: any) => {
      console.error(error);
      const errorMessage =
        error?.response?.data?.error || "Failed to change role. Try again.";

      setError(errorMessage);
      setMessage("Failed to change role", "error");
    },
  });

  return {
    formik,
    handleSubmit: formik.handleSubmit,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
