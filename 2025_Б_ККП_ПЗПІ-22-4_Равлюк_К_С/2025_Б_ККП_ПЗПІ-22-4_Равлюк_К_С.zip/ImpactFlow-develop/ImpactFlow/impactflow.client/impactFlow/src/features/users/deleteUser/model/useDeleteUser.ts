import { useMutation, useQueryClient } from "@tanstack/react-query";
import { deleteUser } from "../api/deleteUserApi";
import { useErrorStore } from "../../../../entities/error";
import { useMessageStore } from "../../../../entities/message/MessageStore";

export const useDeleteUser = () => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  return useMutation({
    mutationFn: (userId: string) => deleteUser(userId),
    onSuccess: () => {
      clearError();
      setMessage("User deleted successfully", "success");
      queryClient.invalidateQueries({ queryKey: ["usersAdmin"] });
    },
    onError: (error) => {
      console.error("ERROR:", error);
      setError("ERROR.");
      setMessage("Failed to delete user", "error");
    },
  });
};
