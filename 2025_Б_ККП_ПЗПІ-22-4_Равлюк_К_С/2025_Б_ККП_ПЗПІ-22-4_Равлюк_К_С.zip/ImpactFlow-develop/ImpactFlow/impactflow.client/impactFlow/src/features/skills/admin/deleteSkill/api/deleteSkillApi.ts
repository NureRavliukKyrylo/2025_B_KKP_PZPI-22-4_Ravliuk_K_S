import { apiClient } from "../../../../../shared/api";

export const deleteSkill = async (id: string): Promise<void> => {
  await apiClient.delete(`Skills/delete/${id}`);
};
