import React, { useState } from "react";
import { useUpdateSkill } from "../model/useUpdateSkill";
import { UpdateSkillForm } from "./UpdateSkillForm";
import { CreateModal } from "../../../../../shared/modals/createModal/CreateModal";
import styles from "./UpdateSkillButton.module.scss";
import UpdateIcon from "../../../../../shared/assets/update_icon.png";
import type { Skills } from "../../../../../entities/skills/admin/types/skillsTypes";

interface Props {
  skill: Skills;
}

export const UpdateSkillButton: React.FC<Props> = ({ skill }) => {
  const [isOpen, setIsOpen] = useState(false);

  const { formik } = useUpdateSkill(
    skill.id,
    {
      name: skill.name,
      description: skill.description,
    },
    () => setIsOpen(false)
  );

  return (
    <>
      <img
        src={UpdateIcon}
        onClick={() => {
          formik.resetForm({
            values: {
              name: skill.name,
              description: skill.description,
            },
          });
          setIsOpen(true);
        }}
        className={styles.buttonImageUpdateSkill}
        alt="Update category"
      />

      {isOpen && (
        <CreateModal
          title="Edit skill"
          description="Please edit the information below to ensure everything is accurate and up to date."
          formik={formik}
          onClose={() => setIsOpen(false)}
          submitText="Edit"
        >
          <UpdateSkillForm formik={formik} />
        </CreateModal>
      )}
    </>
  );
};
