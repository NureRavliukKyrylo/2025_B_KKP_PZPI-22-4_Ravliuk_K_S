import { apiClient } from "../../../../../shared/api";
import type { SkillsDto } from "../../../../../entities/skills/admin/types/skillsTypes";
import type { Skills } from "../../../../../entities/skills/admin/types/skillsTypes";

export const createSkill = async (data: SkillsDto): Promise<Skills> => {
  const response = await apiClient.post<Skills>("Skills/create", data);
  return response.data;
};
