import { useLogin } from "../model/useLogin";
import { useErrorStore } from "../../../../entities/error";
import styles from "./LoginForm.module.scss";
import { Input } from "../../../../shared/inputs/Input";
import { AuthButton } from "../../../../shared/buttons/auth/AuthButton";
import { Link } from "react-router-dom";

export const LoginForm = () => {
  const { formik, isLoading } = useLogin();
  const { error: errorMessage } = useErrorStore();

  return (
    <div className={styles.loginContainer}>
      <div className={styles.headerLogin}>
        <h2>Sign in</h2>
        <h3>Please enter your email address detail to sign in</h3>
      </div>

      <form onSubmit={formik.handleSubmit} className={styles.loginForm}>
        <Input
          id="email"
          name="email"
          type="email"
          label="Email Address or username"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.email}
          error={formik.submitCount > 0 ? formik.errors.email : ""}
        />
        <Input
          id="password"
          name="password"
          type="password"
          label="Password"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.password}
          error={formik.submitCount > 0 ? formik.errors.password : ""}
        />
        <div className={styles.forgotPass}>
          <div className={styles.haveAcc}>
            <p>Dont have an account? </p>
            <Link to="/register" className={styles.toRegisterLink}>
              Registration
            </Link>
          </div>
          <div className={styles.forgot}>
            <Link to="/forgot-password" className={styles.toRegisterLink}>
              <p>Forgot password?</p>
            </Link>
          </div>
        </div>
        <AuthButton loading={isLoading} />
      </form>

      {errorMessage && <div className="errorBtn">{errorMessage}</div>}
    </div>
  );
};
