import { apiClient } from "../../../../shared/api";

export const deleteCategory = async (id: string): Promise<void> => {
  await apiClient.delete(`Categories/delete/${id}`);
};
