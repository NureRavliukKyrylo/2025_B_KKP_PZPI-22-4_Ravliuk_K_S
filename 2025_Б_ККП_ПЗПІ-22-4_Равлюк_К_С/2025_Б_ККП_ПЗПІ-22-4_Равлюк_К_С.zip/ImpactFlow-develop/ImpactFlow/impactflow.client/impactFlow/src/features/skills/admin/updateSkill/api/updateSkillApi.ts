import { apiClient } from "../../../../../shared/api";
import type { Skills } from "../../../../../entities/skills/admin/types/skillsTypes";
import type { SkillsDto } from "../../../../../entities/skills/admin/types/skillsTypes";

export const updateSkill = async (
  id: string,
  data: SkillsDto
): Promise<Skills> => {
  const response = await apiClient.put<Skills>(`/Skills/update/${id}`, data);
  return response.data;
};
