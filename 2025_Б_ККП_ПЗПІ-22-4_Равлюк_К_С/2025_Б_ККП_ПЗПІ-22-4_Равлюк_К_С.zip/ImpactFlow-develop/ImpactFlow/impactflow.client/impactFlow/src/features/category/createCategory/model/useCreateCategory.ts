import { useFormik } from "formik";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createCategory } from "../api/createCategoryApi";
import { createCategorySchema } from "../libs/createCategorySchema";
import { useErrorStore } from "../../../../entities/error";
import type { CategoryDto } from "../../../../entities/category/types/categoryTypes";
import { useMessageStore } from "../../../../entities/message/MessageStore";

interface UseCreateCategoryProps {
  onSuccess?: () => void;
}

export const useCreateCategory = ({
  onSuccess,
}: UseCreateCategoryProps = {}) => {
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();
  const queryClient = useQueryClient();

  const formik = useFormik<CategoryDto>({
    initialValues: {
      name: "",
      description: "",
    },
    validationSchema: createCategorySchema,
    onSubmit: (values, { setSubmitting }) => {
      mutation.mutate(values, {
        onSettled: () => {
          setSubmitting(false);
        },
      });
    },
  });

  const mutation = useMutation({
    mutationFn: (data: CategoryDto) => createCategory(data),
    onSuccess: () => {
      clearError();
      formik.resetForm();
      onSuccess?.();

      setMessage("Category added successfully", "success");
      queryClient.invalidateQueries({ queryKey: ["categories"] });
    },
    onError: (error: any) => {
      console.error("ERROR:", error);
      const errorMessage =
        error?.response?.data?.error || "Failed to create category. Try again.";

      setError(errorMessage);
      setMessage("Failed to add new category", "error");
    },
  });

  return {
    formik,
    handleSubmit: formik.handleSubmit,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
