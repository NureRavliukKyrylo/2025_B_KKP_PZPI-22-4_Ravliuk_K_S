import React, { useState } from "react";
import { BaseModal } from "../../../../shared/modals/confirmModal/BaseModal";
import styles from "./DeleteVolunteerProjectButton.module.scss";
import DeleteIcon from "../../../../shared/assets/delete_icon.png";
import { useDeleteVolunteer } from "../model/useDeleteVolunteer";

interface Props {
  projectId: string;
  userId: string;
  username: string;
}

export const DeleteVolunteerProject: React.FC<Props> = ({
  projectId,
  userId,
  username,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const { mutate: deleteVolunteer, isPending } = useDeleteVolunteer();

  const handleConfirm = () => {
    deleteVolunteer(
      { projectId, userId },
      {
        onSuccess: () => {
          setIsOpen(false);
        },
      }
    );
  };

  return (
    <>
      <img
        src={DeleteIcon}
        onClick={() => setIsOpen(true)}
        className={styles.buttonImageDeleteVolunteer}
        alt="Delete category"
      />

      <BaseModal
        isOpen={isOpen}
        title="Delete category"
        text={`Are you sure you want to delete this volunteer - "${username}"? Think before you decide`}
        onConfirm={handleConfirm}
        onCancel={() => setIsOpen(false)}
        confirmText={isPending ? "Deleting..." : "Yes"}
        cancelText="No"
      />
    </>
  );
};
