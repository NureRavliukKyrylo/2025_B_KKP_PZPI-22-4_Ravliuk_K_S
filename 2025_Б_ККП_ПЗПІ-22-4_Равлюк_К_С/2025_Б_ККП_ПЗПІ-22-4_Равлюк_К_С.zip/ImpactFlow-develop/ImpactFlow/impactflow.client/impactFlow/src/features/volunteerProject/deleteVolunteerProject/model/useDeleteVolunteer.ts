import { useMutation, useQueryClient } from "@tanstack/react-query";
import { deleteVolunteerProject } from "../api/deleteVolunteerProject";
import { useErrorStore } from "../../../../entities/error";
import { useMessageStore } from "../../../../entities/message/MessageStore";

export const useDeleteVolunteer = () => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  return useMutation({
    mutationFn: ({
      projectId,
      userId,
    }: {
      projectId: string;
      userId: string;
    }) => deleteVolunteerProject(projectId, userId),
    onSuccess: () => {
      clearError();
      setMessage("Volunteer was deleted successfully from project", "success");
      queryClient.invalidateQueries({ queryKey: ["volunteersProject"] });
    },
    onError: (error) => {
      console.error("ERROR:", error);
      setError("ERROR.");
      setMessage("Failed to delete volunteer from project", "error");
    },
  });
};
