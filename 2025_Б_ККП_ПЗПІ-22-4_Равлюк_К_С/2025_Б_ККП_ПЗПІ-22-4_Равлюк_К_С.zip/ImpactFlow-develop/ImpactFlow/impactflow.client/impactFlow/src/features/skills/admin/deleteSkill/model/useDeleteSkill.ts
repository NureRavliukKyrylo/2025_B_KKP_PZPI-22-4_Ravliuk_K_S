import { useMutation, useQueryClient } from "@tanstack/react-query";
import { deleteSkill } from "../api/deleteSkillApi";
import { useErrorStore } from "../../../../../entities/error";
import { useMessageStore } from "../../../../../entities/message/MessageStore";

export const useDeleteSkill = () => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  return useMutation({
    mutationFn: (id: string) => deleteSkill(id),
    onSuccess: () => {
      clearError();
      setMessage("Skill deleted successfully", "success");
      queryClient.invalidateQueries({ queryKey: ["skillsAdmin"] });
    },
    onError: (error) => {
      console.error("ERROR:", error);
      setError("ERROR.");
      setMessage("Failed to delete skill", "error");
    },
  });
};
