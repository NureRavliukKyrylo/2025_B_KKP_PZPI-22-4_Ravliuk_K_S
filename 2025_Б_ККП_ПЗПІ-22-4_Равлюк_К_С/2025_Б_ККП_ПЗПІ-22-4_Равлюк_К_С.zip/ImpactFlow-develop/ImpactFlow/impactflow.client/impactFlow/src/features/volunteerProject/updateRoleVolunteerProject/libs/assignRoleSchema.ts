import * as Yup from "yup";

export const assignRoleSchema = Yup.object({
  projectId: Yup.string().required("Project ID is required"),
  volunteerId: Yup.string().required("Volunteer ID is required"),
  roleInProject: Yup.string()
    .required("Role is required")
    .min(2, "Role must be at least 2 characters")
    .max(30, "Role must be at most 30 characters"),
});
