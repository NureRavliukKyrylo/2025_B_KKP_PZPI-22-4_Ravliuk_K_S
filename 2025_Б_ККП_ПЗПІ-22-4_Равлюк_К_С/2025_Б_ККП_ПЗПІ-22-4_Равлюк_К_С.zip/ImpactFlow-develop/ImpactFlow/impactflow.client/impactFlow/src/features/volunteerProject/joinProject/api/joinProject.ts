import { apiClient } from "../../../../shared/api";

export const joinProject = async (projectId: string): Promise<void> => {
  await apiClient.post(`Projects/${projectId}/signup`);
};
