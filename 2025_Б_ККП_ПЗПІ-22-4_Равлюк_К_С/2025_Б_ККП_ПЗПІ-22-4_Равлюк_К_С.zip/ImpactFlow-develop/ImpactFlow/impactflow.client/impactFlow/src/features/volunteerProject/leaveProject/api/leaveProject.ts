import { apiClient } from "../../../../shared/api";

export const leaveProject = async (projectId: string): Promise<void> => {
  await apiClient.put(`Projects/${projectId}/leave`);
};
