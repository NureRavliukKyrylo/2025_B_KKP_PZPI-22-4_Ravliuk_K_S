import React, { useState } from "react";
import { useChangeRole } from "../model/useChangeRole";
import { ChangeRoleForm } from "./ChangeRoleForm";
import { CreateModal } from "../../../../shared/modals/createModal/CreateModal";
import styles from "./ChangeRoleButton.module.scss";
import type { UserDetails } from "../../../../entities/user/admin/types/usersDetails";

interface Props {
  user: UserDetails;
}

export const ChangeRoleButton: React.FC<Props> = ({ user }) => {
  const [isOpen, setIsOpen] = useState(false);

  const { formik } = useChangeRole(
    {
      userId: user.id,
      role: user.role,
    },
    () => setIsOpen(false)
  );

  return (
    <>
      <button
        onClick={() => {
          formik.resetForm({
            values: {
              userId: user.id,
              role: user.role,
            },
          });
          setIsOpen(true);
        }}
        className={styles.buttonChangeRole}
      >
        Change Role
      </button>

      {isOpen && (
        <CreateModal
          title="Edit skill"
          description="Please edit the information below to ensure everything is accurate and up to date."
          formik={formik}
          onClose={() => setIsOpen(false)}
          submitText="Edit"
        >
          <ChangeRoleForm formik={formik} />
        </CreateModal>
      )}
    </>
  );
};
