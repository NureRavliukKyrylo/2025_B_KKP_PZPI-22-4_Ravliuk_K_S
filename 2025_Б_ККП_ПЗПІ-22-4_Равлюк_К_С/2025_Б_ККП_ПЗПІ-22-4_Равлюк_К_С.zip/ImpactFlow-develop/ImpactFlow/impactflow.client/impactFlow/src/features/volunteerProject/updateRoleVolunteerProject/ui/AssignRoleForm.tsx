import { useRef, useEffect, useState } from "react";
import { useAssignUserRole } from "../model/useUpdateRoleVolunteerProject";
import styles from "./AssignRoleForm.module.scss";
import { handleKeyDownEditable, placeCursorAtEnd } from "../libs/editableUtils";

type Props = {
  projectId: string;
  userId: string;
  initialRole: string | null;
};

export const AssignRoleForm = ({ projectId, userId, initialRole }: Props) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempValue, setTempValue] = useState(initialRole ?? "Role");

  const { formik, isLoading } = useAssignUserRole(
    {
      projectId,
      volunteerId: userId,
      roleInProject: initialRole ?? "Role",
    },
    () => setIsEditing(false)
  );

  const editableRef = useRef<HTMLDivElement>(null);
  const wrapperRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        wrapperRef.current &&
        !wrapperRef.current.contains(event.target as Node)
      ) {
        setIsEditing(false);
        if (editableRef.current) {
          editableRef.current.innerText = formik.values.roleInProject;
        }
      }
    };

    if (isEditing) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isEditing, formik.values.roleInProject]);

  const onEditClick = () => {
    if (!isEditing) {
      setIsEditing(true);
      setTempValue(formik.values.roleInProject);

      setTimeout(() => {
        editableRef.current?.focus();
        placeCursorAtEnd(editableRef.current!);
      }, 0);
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    if (editableRef.current) {
      editableRef.current.innerText = formik.values.roleInProject;
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newValue = editableRef.current?.innerText.trim() ?? "";

    await formik.setFieldValue("roleInProject", newValue);
    formik.setTouched({ roleInProject: true }, true);

    console.log("formik values before submit:", formik.values);

    formik.validateForm().then((errors) => {
      console.log("Validation errors:", errors);
    });

    formik.submitForm().then(() => {
      if (formik.isValid) {
        setIsEditing(false);
      }
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    handleKeyDownEditable(e, handleFormSubmit, handleCancelEdit);
  };

  console.log("errors:", formik.errors);
  console.log("submitCount:", formik.submitCount);

  return (
    <>
      <div className={styles.formBlockAssignForm}>
        <form
          ref={wrapperRef}
          className={styles.roleVolunteerWrapper}
          onSubmit={handleFormSubmit}
        >
          <div
            ref={editableRef}
            className={`${styles.roleEditableBlock} ${
              isEditing ? styles.editing : ""
            }`}
            contentEditable={isEditing}
            suppressContentEditableWarning={true}
            onClick={onEditClick}
            onKeyDown={handleKeyDown}
          >
            {tempValue}
          </div>
          <button
            type="submit"
            className={`${styles.saveButton} ${isEditing ? styles.active : ""}`}
            disabled={isLoading}
          >
            <svg
              viewBox="0 0 30 30"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className={styles.saveIcon}
            >
              <path
                d="M12.9 17.7L9.6375 14.4375C9.3625 14.1625 9.019 14.0315 8.607 14.0445C8.194 14.0565 7.85 14.2 7.575 14.475C7.3 14.75 7.1625 15.1 7.1625 15.525C7.1625 15.95 7.3 16.3 7.575 16.575L11.85 20.85C12.125 21.125 12.475 21.2625 12.9 21.2625C13.325 21.2625 13.675 21.125 13.95 20.85L22.4625 12.3375C22.7375 12.0625 22.869 11.7185 22.857 11.3055C22.844 10.8935 22.7 10.55 22.425 10.275C22.15 10 21.8 9.8625 21.375 9.8625C20.95 9.8625 20.6 10 20.325 10.275L12.9 17.7ZM15 30C12.925 30 10.975 29.606 9.15 28.818C7.325 28.031 5.7375 26.9625 4.3875 25.6125C3.0375 24.2625 1.969 22.675 1.182 20.85C0.394 19.025 0 17.075 0 15C0 12.925 0.394 10.975 1.182 9.15C1.969 7.325 3.0375 5.7375 4.3875 4.3875C5.7375 3.0375 7.325 1.9685 9.15 1.1805C10.975 0.3935 12.925 0 15 0C17.075 0 19.025 0.3935 20.85 1.1805C22.675 1.9685 24.2625 3.0375 25.6125 4.3875C26.9625 5.7375 28.031 7.325 28.818 9.15C29.606 10.975 30 12.925 30 15C30 17.075 29.606 19.025 28.818 20.85C28.031 22.675 26.9625 24.2625 25.6125 25.6125C24.2625 26.9625 22.675 28.031 20.85 28.818C19.025 29.606 17.075 30 15 30ZM15 27C18.325 27 21.1565 25.8315 23.4945 23.4945C25.8315 21.1565 27 18.325 27 15C27 11.675 25.8315 8.8435 23.4945 6.5055C21.1565 4.1685 18.325 3 15 3C11.675 3 8.844 4.1685 6.507 6.5055C4.169 8.8435 3 11.675 3 15C3 18.325 4.169 21.1565 6.507 23.4945C8.844 25.8315 11.675 27 15 27Z"
                fill={isEditing ? "green" : "black"}
                fillOpacity="0.6"
              />
            </svg>
          </button>
        </form>
        {formik.touched.roleInProject && formik.errors.roleInProject && (
          <div className="errorMessage">{formik.errors.roleInProject}</div>
        )}
      </div>
    </>
  );
};
