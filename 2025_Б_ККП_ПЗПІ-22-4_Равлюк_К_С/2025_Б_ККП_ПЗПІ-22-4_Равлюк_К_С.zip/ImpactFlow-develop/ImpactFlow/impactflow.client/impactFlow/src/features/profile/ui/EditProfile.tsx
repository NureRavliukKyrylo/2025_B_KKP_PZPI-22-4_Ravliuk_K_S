import styles from "./EditProfile.module.scss";
import { Input } from "../../../shared/inputs/Input";
import { useEditProfileForm } from "../model/useEditProfileForm";
import { TextArea } from "../../../shared/textAreas/TextArea";
import { MapLocationPicker } from "../../map/userLocation/ui/MapLocationPicker";
import { SaveButton } from "../../../shared/buttons/save/SaveButton";
import { CancelButton } from "../../../shared/buttons/cancel/CancelButton";
import DateOfBirthPicker from "../../../shared/dateTime/DateOfBirthPicker";
import { useErrorStore } from "../../../entities/error";

export const EditProfile: React.FC = () => {
  const { formik, isSubmitting } = useEditProfileForm();
  const { error: errorMessage } = useErrorStore();

  return (
    <form onSubmit={formik?.handleSubmit} className={styles.inputEditInfo}>
      <div className={styles.nameContainer}>
        <Input
          name="fullName"
          label="Full Name"
          value={formik?.values.fullName}
          onChange={formik?.handleChange}
          style={{ color: "rgba(9, 9, 9, 0.6)" }}
          error={formik.submitCount > 0 ? formik.errors.fullName : ""}
        />
      </div>
      <div className={styles.emailContainer}>
        <Input
          name="email"
          label="Email"
          value={formik?.values.email}
          onChange={formik?.handleChange}
          style={{ color: "rgba(9, 9, 9, 0.6)" }}
          error={formik.submitCount > 0 ? formik.errors.email : ""}
        />
      </div>
      <div className={styles.phoneDateContainer}>
        <div className={styles.phoneContainer}>
          <Input
            name="phone"
            label="Phone"
            value={formik?.values.phone}
            onChange={formik?.handleChange}
            style={{
              color: "rgba(9, 9, 9, 0.6)",
            }}
            error={formik.submitCount > 0 ? formik.errors.phone : ""}
          />
        </div>
        <div className={styles.birthdayPickerBlock}>
          <DateOfBirthPicker
            formik={formik}
            error={formik.submitCount > 0 ? formik.errors.dateOfBirth : ""}
          ></DateOfBirthPicker>
        </div>
      </div>
      <div className={styles.telegramEditContainer}>
        <Input
          name="telegram"
          label="Telegram"
          value={formik?.values.telegram}
          onChange={formik?.handleChange}
          style={{
            color: "rgba(9, 9, 9, 0.6)",
          }}
          error={formik.submitCount > 0 ? formik.errors.telegram : ""}
        />
      </div>
      <div className={styles.bioContainer}>
        <TextArea
          name="bio"
          placeholder="Biography"
          value={formik?.values.bio}
          onChange={formik?.handleChange}
          error={formik.submitCount > 0 ? formik.errors.bio : ""}
        />
      </div>

      <div className={styles.mapContainer}>
        <MapLocationPicker formik={formik} />
      </div>
      <div className={styles.actionsEditProfile}>
        <SaveButton
          label={isSubmitting ? "Saving..." : "Save Changes"}
          type="submit"
        />
        <CancelButton />
      </div>
      {errorMessage && <div className="errorBtn">{errorMessage}</div>}
    </form>
  );
};
