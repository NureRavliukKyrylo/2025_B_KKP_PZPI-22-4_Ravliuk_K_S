import { useMutation, useQueryClient } from "@tanstack/react-query";
import { assignUserRole } from "../api/updateRoleVolunteerProject";
import { useFormik } from "formik";
import { useErrorStore } from "../../../../entities/error";
import { useMessageStore } from "../../../../entities/message/MessageStore";
import { assignRoleSchema } from "../libs/assignRoleSchema";

type AssignRoleDto = {
  projectId: string;
  volunteerId: string;
  roleInProject: string;
};

export const useAssignUserRole = (
  initialValues: AssignRoleDto,
  onSuccess?: () => void
) => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  const mutation = useMutation({
    mutationFn: (data: AssignRoleDto) => assignUserRole(data),
    onSuccess: () => {
      clearError();
      formik.resetForm();
      onSuccess?.();
      setMessage("Role assigned successfully", "success");
      queryClient.invalidateQueries({ queryKey: ["volunteersProject"] });
    },
    onError: (error) => {
      console.error("Error:", error);
      setError("Failed to assign role.");
      setMessage("Failed to assign role", "error");
    },
  });

  const formik = useFormik({
    initialValues,
    validationSchema: assignRoleSchema,
    enableReinitialize: true,
    onSubmit: (values, { setSubmitting }) => {
      mutation.mutate(values, {
        onSettled: () => {
          setSubmitting(false);
        },
      });
    },
  });

  return {
    formik,
    handleSubmit: formik.handleSubmit,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
