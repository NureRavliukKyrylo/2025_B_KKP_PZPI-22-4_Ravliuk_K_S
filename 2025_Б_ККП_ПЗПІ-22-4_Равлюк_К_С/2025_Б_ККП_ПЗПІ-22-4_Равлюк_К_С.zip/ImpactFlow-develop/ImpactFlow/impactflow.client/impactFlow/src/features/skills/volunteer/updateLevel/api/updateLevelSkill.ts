import type { SkillsVolunteerDto } from "../../../../../entities/skills/volunteer/types/skillsTypes";
import { apiClient } from "../../../../../shared/api";

export const updateLevelSkill = async (
  data: SkillsVolunteerDto
): Promise<void> => {
  await apiClient.put(`Skills/update-level`, data);
};
