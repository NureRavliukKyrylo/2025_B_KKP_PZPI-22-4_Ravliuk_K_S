import { useFormik } from "formik";
import { useMutation } from "@tanstack/react-query";
import { resetPassword, type ResetPaswordDto } from "../api/resetPasswordApi";
import { resetPasswordSchema } from "../libs/resetPasswordSchema";
import { useErrorStore } from "../../../../entities/error";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useEffect } from "react";
import { useMessageStore } from "../../../../entities/message/MessageStore";

export const useResetPassword = () => {
  const { setError, clearError } = useErrorStore();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");
  const { setMessage } = useMessageStore();

  const mutation = useMutation({
    mutationFn: (data: ResetPaswordDto) => resetPassword(data),
    onSuccess: () => {
      clearError();
      setMessage("Password was changed successfully", "success");
      navigate("/login");
    },
    onError: (error: any) => {
      console.error(error);
      const errorMessage =
        error?.response?.data?.error || "Reset failed. Try again.";

      setError(errorMessage);
    },
  });

  const formik = useFormik({
    initialValues: {
      token: "",
      newPassword: "",
      repeatPassword: "",
    },
    validationSchema: resetPasswordSchema,
    onSubmit: (values) => {
      mutation.mutate({ token: values.token, newPassword: values.newPassword });
    },
  });

  useEffect(() => {
    if (token) {
      formik.setFieldValue("token", token);
    }
  }, [token]);

  return {
    formik,
    handleSubmit: formik.handleSubmit,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
