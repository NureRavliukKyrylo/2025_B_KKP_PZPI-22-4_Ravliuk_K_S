import { apiClient } from "../../../../shared/api";

export const deleteVolunteerProject = async (
  projectId: string,
  id: string
): Promise<void> => {
  await apiClient.delete(`Projects/${projectId}/volunteers/${id}`);
};
