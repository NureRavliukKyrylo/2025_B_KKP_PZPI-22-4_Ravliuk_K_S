import { useMutation, useQueryClient } from "@tanstack/react-query";
import { joinProject } from "../api/joinProject";
import { useErrorStore } from "../../../../entities/error";
import { useMessageStore } from "../../../../entities/message/MessageStore";

export const useJoinProject = () => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  return useMutation({
    mutationFn: (projectId: string) => joinProject(projectId),
    onSuccess: (_data, projectId) => {
      clearError();
      setMessage("You have successfully joined the project", "success");
      queryClient.invalidateQueries({ queryKey: ["signedProjectsVolunteer"] });
      queryClient.invalidateQueries({ queryKey: ["initiative", projectId] });
    },
    onError: (error: unknown) => {
      console.error("Join error:", error);
      setError("Failed to join the project");
      setMessage("Could not join the project", "error");
    },
  });
};

