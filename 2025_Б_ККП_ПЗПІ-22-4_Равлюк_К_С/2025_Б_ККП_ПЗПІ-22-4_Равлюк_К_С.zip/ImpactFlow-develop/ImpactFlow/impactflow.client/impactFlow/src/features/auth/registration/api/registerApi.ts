import { apiClient } from "../../../../shared/api";

export type RegisterDto = {
  fullName: string;
  email: string;
  password: string;
};

export const register = async (data: RegisterDto) => {
  const response = await apiClient.post("Auth/register", data);
  return response.data;
};
