import { useFormik } from "formik";
import { useMutation } from "@tanstack/react-query";
import { forgotPass } from "../api/forgotPassApi";
import { forgotPassSchema } from "../libs/forgotPassSchema";
import { useErrorStore } from "../../../../entities/error";
import { useNavigate } from "react-router-dom";
import { useMessageStore } from "../../../../entities/message/MessageStore";
import { useProfileStore } from "../../../../entities/user/volunteer/types/profileAvatarStore";

export const useForgotPass = () => {
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();
  const navigate = useNavigate();
  const setEmailRecover = useProfileStore((state) => state.setEmailRecover);

  const mutation = useMutation({
    mutationFn: (email: string) => forgotPass(email),
    onSuccess: (data) => {
      console.log("Sending email success:", data);
      clearError();
      setMessage("Email send successfully", "success");
      setEmailRecover(data.email);
      navigate("/check-email");
    },
    onError: (error: any) => {
      console.error("Login error:", error);
      const errorMessage =
        error?.response?.data?.error || "Sending email failed. Try again.";

      setError(errorMessage);
    },
  });

  const formik = useFormik({
    initialValues: { email: "" },
    validationSchema: forgotPassSchema,
    onSubmit: (values) => {
      mutation.mutate(values.email);
    },
  });

  return {
    formik,
    handleSubmit: formik.handleSubmit,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
