import { useFormik } from "formik";
import { useMutation } from "@tanstack/react-query";
import { login, type LoginDto } from "../api/loginApi";
import { loginSchema } from "../libs/loginSchema";
import { useErrorStore } from "../../../../entities/error";
import { useNavigate } from "react-router-dom";
import { useProfileStore } from "../../../../entities/user/volunteer/types/profileAvatarStore";

export const useLogin = () => {
  const { setError, clearError } = useErrorStore();
  const navigate = useNavigate();

  const mutation = useMutation({
    mutationFn: (data: LoginDto) => login(data),
    onSuccess: (data) => {
      const { avatarUrl, fullName, role, latitude, longitude } = data;
      useProfileStore.getState().setAvatarUrl(avatarUrl);
      useProfileStore.getState().setFullName(fullName);
      useProfileStore.getState().setRole(role);
      useProfileStore.getState().setLatitude(latitude);
      useProfileStore.getState().setLongitude(longitude);
      console.log("Login success:", data);
      clearError();
      navigate("/home");
    },
    onError: (error: any) => {
      console.error("Login error:", error);
      const errorMessage =
        error?.response?.data?.error ||
        "Invalid login credentials. Please try again.";

      setError(errorMessage);
    },
  });

  const formik = useFormik({
    initialValues: { email: "", password: "" },
    validationSchema: loginSchema,
    onSubmit: (values) => {
      mutation.mutate(values);
    },
  });

  return {
    formik,
    handleSubmit: formik.handleSubmit,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
