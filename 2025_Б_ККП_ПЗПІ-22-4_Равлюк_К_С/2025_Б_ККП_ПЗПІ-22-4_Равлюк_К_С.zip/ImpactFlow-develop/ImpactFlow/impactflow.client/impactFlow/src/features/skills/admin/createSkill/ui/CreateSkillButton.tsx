import React, { useState } from "react";
import { useCreateSkill } from "../model/useCreateSkill";
import { CreateSkillForm } from "./CreateSkillForm";
import { CreateModal } from "../../../../../shared/modals/createModal/CreateModal";
import CreateIcon from "../../../../../shared/assets/add_modal.png";
import styles from "./CreateSkillButton.module.scss";

export const CreateSkillButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const { formik } = useCreateSkill({
    onSuccess: () => {
      setIsOpen(false);
    },
  });

  return (
    <>
      <div className={styles.cardAddSkill}>
        <img
          src={CreateIcon}
          onClick={() => setIsOpen(true)}
          className={styles.buttonImageCreateSkill}
          alt="Create skill"
        />
        <h1>Create new Skill</h1>
      </div>

      {isOpen && (
        <CreateModal
          title="Create new skill"
          description="Please provide the necessary details below to register a new category on the platform."
          formik={formik}
          onClose={() => {
            formik.resetForm();
            setIsOpen(false);
          }}
        >
          <CreateSkillForm formik={formik} />
        </CreateModal>
      )}
    </>
  );
};
