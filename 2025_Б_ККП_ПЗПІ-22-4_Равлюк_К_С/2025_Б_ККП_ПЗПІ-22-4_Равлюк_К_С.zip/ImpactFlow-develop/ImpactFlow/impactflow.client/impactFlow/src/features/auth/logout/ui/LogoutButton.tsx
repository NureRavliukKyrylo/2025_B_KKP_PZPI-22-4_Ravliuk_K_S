import { useLogout } from "../model/useLogout";
import { useUserStore } from "../../../../entities/user/volunteer/types/userStore";
import styles from "./LogoutButton.module.scss";
import { useState } from "react";
import { BaseModal } from "../../../../shared/modals/confirmModal/BaseModal";

export const LogoutButton = () => {
  const { handleLogout, isLoading } = useLogout();
  const user = useUserStore((state) => state.user);
  const [isModalOpen, setModalOpen] = useState(false);

  const confirmLogout = () => {
    handleLogout();
    setModalOpen(false);
  };

  return (
    <div className={styles.userBottom}>
      {user && (
        <h1 className={styles.regDate}>
          Registration date:{" "}
          {new Date(user.registeredAt).toLocaleDateString("uk-UA")}
        </h1>
      )}
      <button
        className={styles.logoutButton}
        onClick={() => setModalOpen(true)}
        disabled={isLoading}
      >
        {isLoading ? "LOG OUT..." : "LOG OUT"}
      </button>
      <BaseModal
        isOpen={isModalOpen}
        title="Log out"
        text="Are you sure you want to log out of your account? You will need to sign in again to access your dashboard and personal data."
        onConfirm={confirmLogout}
        onCancel={() => setModalOpen(false)}
      />
    </div>
  );
};
