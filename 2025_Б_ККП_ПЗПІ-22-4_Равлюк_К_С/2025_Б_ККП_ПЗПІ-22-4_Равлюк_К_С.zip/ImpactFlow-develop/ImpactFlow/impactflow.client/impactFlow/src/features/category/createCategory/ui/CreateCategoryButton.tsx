import React, { useState } from "react";
import { useCreateCategory } from "../model/useCreateCategory";
import { CreateCategoryForm } from "./CreateCategoryForm";
import { CreateModal } from "../../../../shared/modals/createModal/CreateModal";
import CreateIcon from "../../../../shared/assets/add_modal.png";
import styles from "./CreateCategoryButton.module.scss";

export const CreateCategoryButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const { formik } = useCreateCategory({
    onSuccess: () => {
      setIsOpen(false);
    },
  });

  return (
    <>
      <div className={styles.cardAddCategory}>
        <img
          src={CreateIcon}
          onClick={() => setIsOpen(true)}
          className={styles.buttonImageCreateCategory}
          alt="Create category"
        />
        <h1>Add new categories</h1>
      </div>

      {isOpen && (
        <CreateModal
          title="Create new category"
          description="Please provide the necessary details below to register a new category on the platform."
          formik={formik}
          onClose={() => {
            formik.resetForm();
            setIsOpen(false);
          }}
        >
          <CreateCategoryForm formik={formik} />
        </CreateModal>
      )}
    </>
  );
};
