import React, { useState } from "react";
import { BaseModal } from "../../../../shared/modals/confirmModal/BaseModal";
import { useDeleteUser } from "../model/useDeleteUser";
import styles from "./DeleteUserButton.module.scss";
import DeleteIcon from "../../../../shared/assets/delete_icon.png";

interface Props {
  userId: string;
  userName: string;
}

export const DeleteuserButton: React.FC<Props> = ({ userId, userName }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { mutate: deleteUser, isPending } = useDeleteUser();

  const handleConfirm = () => {
    deleteUser(userId, {
      onSuccess: () => {
        setIsOpen(false);
      },
    });
  };

  return (
    <>
      <img
        src={DeleteIcon}
        onClick={() => setIsOpen(true)}
        className={styles.buttonImageDeleteUser}
        alt="Delete user"
      />

      <BaseModal
        isOpen={isOpen}
        title="Delete user"
        text={`Are you sure you want to delete this user "${userName}"? Think before you decide`}
        onConfirm={handleConfirm}
        onCancel={() => setIsOpen(false)}
        confirmText={isPending ? "Deleting..." : "Yes"}
        cancelText="No"
      />
    </>
  );
};
