import { apiClient } from "../../../../../shared/api";
import type { Skills } from "../../../../../entities/skills/admin/types/skillsTypes";
import type { SkillsVolunteerDto } from "../../../../../entities/skills/volunteer/types/skillsTypes";

export const assignSkill = async (
  data: SkillsVolunteerDto
): Promise<Skills> => {
  const response = await apiClient.post<Skills>(`/Skills/assign/`, null, {
    params: {
      skillId: data.skillId,
      level: data.level,
    },
  });
  return response.data;
};
