import React, { useState } from "react";
import { useUpdateSkillLevel } from "../model/useUpdateSkillLevel";
import type { Level } from "../../../../../entities/skills/volunteer/types/skillsTypes";
import { levelMap } from "../../../../../entities/skills/volunteer/types/skillsTypes";
import { CustomSelect } from "../../../../../shared/select/CustomSelect";

interface SkillLevelSelectProps {
  skillId: string;
  initialLevel: Level;
}

export const SkillLevelSelect: React.FC<SkillLevelSelectProps> = ({
  skillId,
  initialLevel,
}) => {
  const [level, setLevel] = useState<Level>(initialLevel);
  const { updateLevel, isLoading } = useUpdateSkillLevel();

  const handleLevelChange = (newLevel: Level) => {
    setLevel(newLevel);
    updateLevel({ skillId, level: newLevel });
  };

  const options = Object.entries(levelMap).map(([key, label]) => ({
    value: Number(key) as Level,
    label,
  }));

  return (
    <CustomSelect
      value={level}
      onChange={handleLevelChange}
      options={options}
      disabled={isLoading}
    />
  );
};
