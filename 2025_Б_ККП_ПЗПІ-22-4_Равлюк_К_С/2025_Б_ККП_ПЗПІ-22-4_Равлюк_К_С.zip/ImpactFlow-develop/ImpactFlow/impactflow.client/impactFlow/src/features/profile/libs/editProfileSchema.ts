import * as Yup from "yup";
import { differenceInYears } from "date-fns";

const isValidCoordinates = (value: any) => {
  if (!value) return true;
  const { lat, lng } = value;
  const isLatValid = typeof lat === "number" && lat >= -90 && lat <= 90;
  const isLngValid = typeof lng === "number" && lng >= -180 && lng <= 180;
  return isLatValid && isLngValid;
};

export const editProfileSchema = Yup.object({
  fullName: Yup.string()
    .required("Enter name this field is required")
    .matches(
      /^[A-Za-zА-Яа-яЁёІіЇїЄєҐґ\s'-]+$/,
      "Name must contain only letters"
    )
    .min(2, "Name must be at least 2 characters")
    .max(100, "Name is too long"),

  email: Yup.string()
    .required("Enter email")
    .email("Enter a valid email address this field is required"),

  phone: Yup.string()
    .matches(
      /^\+?[0-9\s\-()]{7,20}$/,
      "Enter a valid phone number, +380992871332"
    )
    .nullable(),

  telegram: Yup.string()
    .matches(
      /^https:\/\/t\.me\/[a-zA-Z0-9_]{5,32}$/,
      "Enter a valid Telegram link, e.g. https://t.me/username"
    )
    .nullable(),

  bio: Yup.string().max(200, "Bio must be 200 characters or less").nullable(),

  dateOfBirth: Yup.date()
    .nullable()
    .typeError("Enter a valid date")
    .test(
      "is-older-than-14",
      "You must be older than 14 years",
      (value) => !value || differenceInYears(new Date(), value) >= 14
    ),

  coordinates: Yup.mixed()
    .test("is-valid-coordinates", "Invalid coordinates", isValidCoordinates)
    .nullable(),
});
