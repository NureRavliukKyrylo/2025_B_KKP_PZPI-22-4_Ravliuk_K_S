import { apiClient } from "../../../../shared/api";

export type ResetPaswordDto = {
  token: string;
  newPassword: string;
};

export const resetPassword = async (data: ResetPaswordDto) => {
  const response = await apiClient.post("Auth/reset-password", data);
  return response.data;
};
