import { useRegister } from "../model/useRegister";
import { useErrorStore } from "../../../../entities/error";
import styles from "./RegistrationForm.module.scss";
import { Input } from "../../../../shared/inputs/Input";
import { AuthButton } from "../../../../shared/buttons/auth/AuthButton";
import { Checkbox } from "../../../../shared/checkBoxes/checkBox";
import { Link } from "react-router-dom";

export const RegistrationForm = () => {
  const { formik, isLoading } = useRegister();
  const { error: errorMessage } = useErrorStore();

  return (
    <div className={styles.registerContainer}>
      <div className={styles.headerRegister}>
        <h2>Registration</h2>
        <h3>Create your account in seconds — it’s fast, easy, and free</h3>
      </div>

      <form onSubmit={formik.handleSubmit} className={styles.registerForm}>
        <Input
          id="fullName"
          name="fullName"
          type="text"
          label="Full name"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.fullName}
          error={formik.submitCount > 0 ? formik.errors.fullName : ""}
        />
        <Input
          id="email"
          name="email"
          type="email"
          label="Email Address or username"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.email}
          error={formik.submitCount > 0 ? formik.errors.email : ""}
        />
        <Input
          id="password"
          name="password"
          type="password"
          label="Password"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.password}
          error={formik.submitCount > 0 ? formik.errors.password : ""}
        />
        <div className={styles.extraRegister}>
          <div className={styles.agreement}>
            <Checkbox
              name="agreeToTerms"
              checked={formik.values.agreeToTerms}
              onChange={formik.handleChange}
            />
            <p>
              I agree to the <a>Terms of services and private policy</a>
            </p>
          </div>
          <div className={styles.toLogin}>
            <p>Already a member?</p>
            <Link to="/login" className={styles.toLoginLink}>
              Sign in
            </Link>
          </div>
          {formik.submitCount > 0 && formik.errors.agreeToTerms && (
            <div className="errorBtn">{formik.errors.agreeToTerms}</div>
          )}
        </div>

        <AuthButton loading={isLoading} label="Sign up" />
        
      </form>

      {errorMessage && <div className="errorBtn">{errorMessage}</div>}
    </div>
  );
};
