import { useNavigate } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { logout as logoutApi } from "../api/logoutApi";
import { useErrorStore } from "../../../../entities/error";
import { useMessageStore } from "../../../../entities/message/MessageStore";
import { useQueryClient } from "@tanstack/react-query";

export const useLogout = () => {
  const navigate = useNavigate();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();
  const queryClient = useQueryClient();
  const mutation = useMutation({
    mutationFn: logoutApi,
    onSuccess: () => {
      clearError();
      localStorage.clear();
      queryClient.removeQueries({ queryKey: ["userRoute"] });
      navigate("/login");
    },
    onError: () => {
      setError("Logout failed. Please try again.");
      setMessage("Logout failed.Try again", "error");
    },
  });

  const handleLogout = () => {
    mutation.mutate();
  };

  return {
    handleLogout,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
