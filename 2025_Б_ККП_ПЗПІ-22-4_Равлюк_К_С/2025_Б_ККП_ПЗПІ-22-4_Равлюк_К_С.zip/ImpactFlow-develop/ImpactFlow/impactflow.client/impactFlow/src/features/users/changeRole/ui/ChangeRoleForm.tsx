import React from "react";
import type { FormikProps } from "formik";
import type { ChangeRole } from "../../../../entities/user/admin/types/usersDetails";
import {
  RoleMap,
  type Role,
} from "../../../../entities/user/volunteer/types/userTypes";
import { CustomSelect } from "../../../../shared/select/CustomSelect";

interface Props {
  formik: FormikProps<ChangeRole>;
}

export const ChangeRoleForm: React.FC<Props> = ({ formik }) => {
  const options = Object.entries(RoleMap).map(([key, label]) => ({
    value: Number(key) as Role,
    label,
  }));
  return (
    <>
      <CustomSelect
        value={formik.values.role}
        onChange={(val) => formik.setFieldValue("role", val)}
        options={options}
      />
    </>
  );
};
