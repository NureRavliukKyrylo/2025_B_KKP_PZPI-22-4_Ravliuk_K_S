import React, { useState } from "react";
import { useUpdateCategory } from "../model/useUpdateCategory";
import { UpdateCategoryForm } from "./UpdateCategoryForm";
import { CreateModal } from "../../../../shared/modals/createModal/CreateModal";
import type { Category } from "../../../../entities/category/types/categoryTypes";
import styles from "./UpdateCategoryButton.module.scss";
import UpdateIcon from "../../../../shared/assets/update_icon.png";

interface Props {
  category: Category;
}

export const UpdateCategoryButton: React.FC<Props> = ({ category }) => {
  const [isOpen, setIsOpen] = useState(false);

  const { formik } = useUpdateCategory(
    category.id,
    {
      name: category.name,
      description: category.description || "",
    },
    () => setIsOpen(false)
  );

  return (
    <>
      <img
        src={UpdateIcon}
        onClick={() => {
          formik.resetForm({
            values: {
              name: category.name,
              description: category.description || "",
            },
          });
          setIsOpen(true);
        }}
        className={styles.buttonImageUpdateCategory}
        alt="Update category"
      />

      {isOpen && (
        <CreateModal
          title="Edit Category"
          description="Please edit the information below to ensure everything is accurate and up to date."
          formik={formik}
          onClose={() => setIsOpen(false)}
          submitText="Edit"
        >
          <UpdateCategoryForm formik={formik} />
        </CreateModal>
      )}
    </>
  );
};
