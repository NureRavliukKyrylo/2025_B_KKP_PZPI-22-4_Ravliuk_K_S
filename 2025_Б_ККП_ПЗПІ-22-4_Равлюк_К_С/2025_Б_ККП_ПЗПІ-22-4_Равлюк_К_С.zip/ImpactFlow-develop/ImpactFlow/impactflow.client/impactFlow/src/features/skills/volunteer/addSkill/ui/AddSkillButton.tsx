import React from "react";
import CreateIcon from "../../../../../shared/assets/add_modal.png";
import styles from "./AddSkillButton.module.scss";
import { Link } from "react-router-dom";

export const AddSkillButton: React.FC = () => {
  return (
    <>
      <Link to="/my-skills/adding" className={styles.cardAddSkillVolunteer}>
        <img
          src={CreateIcon}
          className={styles.buttonImageAddSkill}
          alt="Create skill"
        />
        <h1>Add new Skill</h1>
      </Link>
    </>
  );
};
