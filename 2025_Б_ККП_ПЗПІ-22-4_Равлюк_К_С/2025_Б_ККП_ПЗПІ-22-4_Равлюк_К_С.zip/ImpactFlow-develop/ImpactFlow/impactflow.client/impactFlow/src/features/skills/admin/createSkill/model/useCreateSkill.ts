import { useFormik } from "formik";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createSkill } from "../api/createSkillApi";
import { createSkillSchema } from "../libs/createSkillSchema";
import { useErrorStore } from "../../../../../entities/error";
import type { SkillsDto } from "../../../../../entities/skills/admin/types/skillsTypes";
import { useMessageStore } from "../../../../../entities/message/MessageStore";

interface UseCreateSkillProps {
  onSuccess?: () => void;
}

export const useCreateSkill = ({ onSuccess }: UseCreateSkillProps = {}) => {
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();
  const queryClient = useQueryClient();

  const formik = useFormik<SkillsDto>({
    initialValues: {
      name: "",
      description: "",
    },
    validationSchema: createSkillSchema,
    onSubmit: (values, { setSubmitting }) => {
      mutation.mutate(values, {
        onSettled: () => {
          setSubmitting(false);
        },
      });
    },
  });

  const mutation = useMutation({
    mutationFn: (data: SkillsDto) => createSkill(data),
    onSuccess: () => {
      clearError();
      formik.resetForm();
      onSuccess?.();

      setMessage("Skill added successfully", "success");
      queryClient.invalidateQueries({ queryKey: ["skillsAdmin"] });
    },
    onError: (error: any) => {
      const errorMessage =
        error?.response?.data?.error || "Failed to create skill. Try again.";

      setError(errorMessage);
      setMessage("Failed to add new skill", "error");
    },
  });

  return {
    formik,
    handleSubmit: formik.handleSubmit,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
