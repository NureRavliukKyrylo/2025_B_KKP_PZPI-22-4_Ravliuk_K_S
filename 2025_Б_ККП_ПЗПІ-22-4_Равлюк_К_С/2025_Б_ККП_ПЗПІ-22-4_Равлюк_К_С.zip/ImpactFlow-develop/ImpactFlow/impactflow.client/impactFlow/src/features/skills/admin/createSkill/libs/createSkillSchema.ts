import * as Yup from "yup";

export const createSkillSchema = Yup.object({
  name: Yup.string()
    .min(2, "Minimum length of title 2 characters")
    .max(30, "Max chars 30 ")
    .required("Name of skill is required"),
  description: Yup.string()
    .max(255, "Description must be less than 200 characters")
    .required("Description is required"),
});
