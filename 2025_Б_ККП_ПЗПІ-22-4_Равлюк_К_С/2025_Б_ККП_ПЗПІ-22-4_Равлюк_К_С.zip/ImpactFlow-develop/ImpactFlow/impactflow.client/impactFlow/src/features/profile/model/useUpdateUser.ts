import { useMutation, useQueryClient } from "@tanstack/react-query";
import { updateUser, type UpdateUserDto } from "../api/editProfileApi";
import { useMessageStore } from "../../../entities/message/MessageStore";
import { useErrorStore } from "../../../entities/error";

export const useUpdateUser = () => {
  const { setMessage } = useMessageStore();
  const { setError, clearError } = useErrorStore();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: UpdateUserDto) => {
      console.log("Data being sent to API:", data);
      return updateUser(data);
    },
    onSuccess: () => {
      setMessage("User updated successfully", "success");
      queryClient.invalidateQueries({ queryKey: ["userProfile"] });
      clearError();
    },
    onError: (error: any) => {
      console.error("Update error:", error);
      const errorMessage =
        error?.response?.data?.error || "Failed to update data. Try again.";
      setError(errorMessage);

      setMessage("Failed to update data", "error");
    },
  });
};
