import { useResetPassword } from "../model/useResetPassword";
import { useErrorStore } from "../../../../entities/error";
import styles from "./ResetPasswordForm.module.scss";
import { Input } from "../../../../shared/inputs/Input";
import { AuthButton } from "../../../../shared/buttons/auth/AuthButton";

export const ResetPasswordForm = () => {
  const { formik, isLoading } = useResetPassword();
  const { error: errorMessage } = useErrorStore();

  return (
    <div className={styles.resetPasswordContainer}>
      <div className={styles.headerResetPassword}>
        <h2>Set password </h2>
        <h3>Reset your password! Enter a new one and remember it this time!</h3>
      </div>

      <form onSubmit={formik.handleSubmit} className={styles.resetPasswordForm}>
        <div className={styles.resetPasswordInputs}>
          <Input
            id="newPassword"
            name="newPassword"
            type="password"
            label="New password"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.newPassword}
            error={formik.submitCount > 0 ? formik.errors.newPassword : ""}
          />
          <Input
            id="repeatPassword"
            name="repeatPassword"
            type="password"
            label="Repeat passwword"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.repeatPassword}
            error={formik.submitCount > 0 ? formik.errors.repeatPassword : ""}
          />
        </div>
        <AuthButton loading={isLoading} label="Confirm password change" />
      </form>

      {errorMessage && <div className="errorBtn">{errorMessage}</div>}
    </div>
  );
};
