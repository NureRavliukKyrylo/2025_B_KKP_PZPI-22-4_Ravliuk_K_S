import { useMutation, useQueryClient } from "@tanstack/react-query";
import { updateCategory } from "../api/updateCategoryApi";
import type { CategoryDto } from "../../../../entities/category/types/categoryTypes";
import { useFormik } from "formik";
import { updateCategorySchema } from "../libs/updateCategorySchema";
import { useErrorStore } from "../../../../entities/error";
import { useMessageStore } from "../../../../entities/message/MessageStore";

export const useUpdateCategory = (
  id: string,
  initialValues: CategoryDto,
  onSuccess?: () => void
) => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  const formik = useFormik({
    initialValues,
    validationSchema: updateCategorySchema,
    enableReinitialize: true,
    onSubmit: (values, { setSubmitting }) => {
      mutation.mutate(
        { id, data: values },
        {
          onSettled: () => {
            setSubmitting(false);
          },
        }
      );
    },
  });

  const mutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: CategoryDto }) =>
      updateCategory(id, data),
    onSuccess: () => {
      clearError();
      formik.resetForm();
      onSuccess?.();
      setMessage("Category updated successfully", "success");
      queryClient.invalidateQueries({ queryKey: ["categories"] });
    },
    onError: (error: any) => {
      console.error("Error:", error);
      const errorMessage =
        error?.response?.data?.error || "Failed to update category. Try again.";

      setError(errorMessage);
      setMessage("Failed to update category", "error");
    },
  });

  return {
    formik,
    handleSubmit: formik.handleSubmit,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
