import { apiClient } from "../../../../../shared/api";

export const removeVolunteerSkill = async (id: string): Promise<void> => {
  await apiClient.delete(`Skills/remove`, {
    params: { skillId: id },
  });
};
