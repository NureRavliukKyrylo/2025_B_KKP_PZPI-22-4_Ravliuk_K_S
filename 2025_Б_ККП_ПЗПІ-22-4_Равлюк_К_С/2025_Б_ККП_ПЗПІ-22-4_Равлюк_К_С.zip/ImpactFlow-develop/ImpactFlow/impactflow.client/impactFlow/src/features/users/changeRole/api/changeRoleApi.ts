import type { ChangeRole } from "../../../../entities/user/admin/types/usersDetails";
import { apiClient } from "../../../../shared/api";

export const changeRole = async (data: ChangeRole): Promise<void> => {
  console.log("👉 Axios sending:", data);
  await apiClient.put(`User/role`, null, {
    params: {
      userId: data.userId,
      role: data.role,
    },
  });
};
