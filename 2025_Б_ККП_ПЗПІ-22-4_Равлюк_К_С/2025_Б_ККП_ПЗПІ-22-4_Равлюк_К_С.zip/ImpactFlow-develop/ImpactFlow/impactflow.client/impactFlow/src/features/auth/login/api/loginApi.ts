import { apiClient } from "../../../../shared/api";

export type LoginDto = {
  email: string;
  password: string;
};

export const login = async (data: LoginDto) => {
  const response = await apiClient.post("Auth/login", data);
  return response.data;
};
