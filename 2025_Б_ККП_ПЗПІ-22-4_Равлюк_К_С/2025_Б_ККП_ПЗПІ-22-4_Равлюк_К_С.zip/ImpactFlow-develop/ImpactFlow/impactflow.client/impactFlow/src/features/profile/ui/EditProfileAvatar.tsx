import React, { useEffect, useRef } from "react";
import DefaultProfile from "../../../shared/assets/default_profile.png";
import styles from "./EditProfile.module.scss";
import { BaseButton } from "../../../shared/buttons/base/BaseButton";
import { useUploadAvatar } from "../model/useUploadAvatar";
import { useProfileStore } from "../../../entities/user/volunteer/types/profileAvatarStore";
import { useErrorStore } from "../../../entities/error";

interface EditProfileAvatarProps {
  user: any;
}

export const EditProfileAvatar: React.FC<EditProfileAvatarProps> = ({
  user,
}) => {
  const { mutate: uploadAvatar } = useUploadAvatar();
  const { error: errorMessage } = useErrorStore();
  const setAvatarUrl = useProfileStore((state) => state.setAvatarUrl);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const avatarUrl = useProfileStore((state) => state.avatarUrl);

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  useEffect(() => {
    if (user?.profile?.avatarUrl) {
      setAvatarUrl(user.profile.avatarUrl);
    }
  }, [user?.profile?.avatarUrl]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith("image/")) {
      const imageUrl = URL.createObjectURL(file);
      setAvatarUrl(imageUrl);
      uploadAvatar(file);
    }
  };

  return (
    <>
      <div className={styles.profileEditAvatar}>
        <img
          src={avatarUrl || DefaultProfile}
          alt="User Avatar"
          className={styles.profileAvatarEditPic}
        />
        <input
          type="file"
          accept="image/*"
          ref={fileInputRef}
          style={{ display: "none" }}
          onChange={handleFileChange}
        />
        <BaseButton label="Select an image" onClick={handleClick}></BaseButton>
        {errorMessage && <div className="errorBtn">{errorMessage}</div>}
      </div>
      <div className={styles.dividerEditProfile}>
        <div className={styles.lineDivider}></div>
      </div>
    </>
  );
};
