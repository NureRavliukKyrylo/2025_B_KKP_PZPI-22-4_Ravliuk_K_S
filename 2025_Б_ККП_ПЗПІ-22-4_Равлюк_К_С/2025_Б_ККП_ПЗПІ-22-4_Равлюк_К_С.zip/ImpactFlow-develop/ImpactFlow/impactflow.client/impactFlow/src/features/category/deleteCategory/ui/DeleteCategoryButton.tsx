import React, { useState } from "react";
import { BaseModal } from "../../../../shared/modals/confirmModal/BaseModal";
import { useDeleteCategory } from "../model/useDeleteCategory";
import styles from "./DeleteCategoryButton.module.scss";
import DeleteIcon from "../../../../shared/assets/delete_icon.png";

interface Props {
  categoryId: string;
  categoryName: string;
}

export const DeleteCategoryButton: React.FC<Props> = ({
  categoryId,
  categoryName,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const { mutate: deleteCategory, isPending } = useDeleteCategory();

  const handleConfirm = () => {
    deleteCategory(categoryId, {
      onSuccess: () => {
        setIsOpen(false);
      },
    });
  };

  return (
    <>
      <img
        src={DeleteIcon}
        onClick={() => setIsOpen(true)}
        className={styles.buttonImageDeleteCategory}
        alt="Delete category"
      />

      <BaseModal
        isOpen={isOpen}
        title="Delete category"
        text={`Are you sure you want to delete this category "${categoryName}"? Think before you decide`}
        onConfirm={handleConfirm}
        onCancel={() => setIsOpen(false)}
        confirmText={isPending ? "Deleting..." : "Yes"}
        cancelText="No"
      />
    </>
  );
};
