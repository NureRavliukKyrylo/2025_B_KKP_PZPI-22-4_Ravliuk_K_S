import { useMutation, useQueryClient } from "@tanstack/react-query";
import { leaveProject } from "../api/leaveProject";
import { useErrorStore } from "../../../../entities/error";
import { useMessageStore } from "../../../../entities/message/MessageStore";

export const useLeaveProject = () => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  return useMutation({
    mutationFn: (projectId: string) => leaveProject(projectId),
    onSuccess: () => {
      clearError();
      setMessage("You have successfully left the project", "success");
      queryClient.invalidateQueries({ queryKey: ["signedProjectsVolunteer"] });
    },
    onError: (error) => {
      console.error("ERROR:", error);
      setError("ERROR.");
      setMessage("Failed to leave the project", "error");
    },
  });
};
