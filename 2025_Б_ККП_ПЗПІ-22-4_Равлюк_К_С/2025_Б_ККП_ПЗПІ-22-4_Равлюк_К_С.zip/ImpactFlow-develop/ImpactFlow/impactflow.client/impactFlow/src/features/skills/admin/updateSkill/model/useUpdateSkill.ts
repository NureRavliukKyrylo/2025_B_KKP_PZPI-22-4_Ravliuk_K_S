import { useMutation, useQueryClient } from "@tanstack/react-query";
import { updateSkill } from "../api/updateSkillApi";
import type { SkillsDto } from "../../../../../entities/skills/admin/types/skillsTypes";
import { useFormik } from "formik";
import { updateSkillSchema } from "../libs/updateSkillSchema";
import { useErrorStore } from "../../../../../entities/error";
import { useMessageStore } from "../../../../../entities/message/MessageStore";

export const useUpdateSkill = (
  id: string,
  initialValues: SkillsDto,
  onSuccess?: () => void
) => {
  const queryClient = useQueryClient();
  const { setError, clearError } = useErrorStore();
  const { setMessage } = useMessageStore();

  const formik = useFormik({
    initialValues,
    validationSchema: updateSkillSchema,
    enableReinitialize: true,
    onSubmit: (values, { setSubmitting }) => {
      mutation.mutate(
        { id, data: values },
        {
          onSettled: () => {
            setSubmitting(false);
          },
        }
      );
    },
  });

  const mutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: SkillsDto }) =>
      updateSkill(id, data),
    onSuccess: () => {
      clearError();
      formik.resetForm();
      onSuccess?.();
      setMessage("Skill updated successfully", "success");
      queryClient.invalidateQueries({ queryKey: ["skillsAdmin"] });
    },
    onError: (error: any) => {
      console.error("Error:", error);
      const errorMessage =
        error?.response?.data?.error || "Failed to create category. Try again.";

      setError(errorMessage);
      setMessage("Failed to update skill", "error");
    },
  });

  return {
    formik,
    handleSubmit: formik.handleSubmit,
    isLoading: mutation.isPending,
    error: mutation.error,
  };
};
