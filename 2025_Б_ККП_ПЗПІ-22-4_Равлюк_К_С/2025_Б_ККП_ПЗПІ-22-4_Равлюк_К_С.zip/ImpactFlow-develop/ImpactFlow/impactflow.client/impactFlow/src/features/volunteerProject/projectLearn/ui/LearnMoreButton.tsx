import { Link } from "react-router-dom";
import styles from "./LearnMoreButton.module.scss";

interface LearnMoreButtonProps {
  projectId: string;
}
export const LearnMoreButton: React.FC<LearnMoreButtonProps> = ({
  projectId,
}) => {
  return (
    <Link to={`/initiatives/${projectId}`} className={styles.learnMoreButton}>
      Learn More
    </Link>
  );
};
