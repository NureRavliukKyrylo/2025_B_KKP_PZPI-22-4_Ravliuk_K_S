import { useEffect, useState } from "react";
import { useFilterStore } from "../../../entities/filter/store/filterStore";
import styles from "./RadiusInput.module.scss";
import { useErrorStore } from "../../../entities/error";

interface RadiusProps {
  debounceDelay?: number;
}

export const RadiusInput: React.FC<RadiusProps> = ({ debounceDelay = 500 }) => {
  const radius = useFilterStore((state) => state.radius);
  const setRadius = useFilterStore((state) => state.setRadius);
  const { error: errorMessage, clearError } = useErrorStore();
  const [inputValue, setInputValue] = useState(radius);

  useEffect(() => {
    const handler = setTimeout(() => {
      setRadius(inputValue);
    }, debounceDelay);

    return () => clearTimeout(handler);
  }, [inputValue, debounceDelay, setRadius]);

  useEffect(() => {
    setInputValue(radius);
  }, [radius]);

  return (
    <>
      <input
        className={styles.distanceInput}
        type="number"
        placeholder="Example: 10 km, 25 km, 50 km"
        value={inputValue}
        onChange={(e) => {
          setInputValue(e.target.value);
          clearError();
        }}
      />
      {errorMessage && <div className="errorBtn">{errorMessage}</div>}
    </>
  );
};
