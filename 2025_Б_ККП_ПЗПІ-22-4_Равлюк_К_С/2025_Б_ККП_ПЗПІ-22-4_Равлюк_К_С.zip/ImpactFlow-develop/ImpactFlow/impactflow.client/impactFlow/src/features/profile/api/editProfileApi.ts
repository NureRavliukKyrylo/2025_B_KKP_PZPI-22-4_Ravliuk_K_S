import { apiClient } from "../../../shared/api";

export type UpdateUserDto = {
  fullName: string;
  email: string;
  profile: {
    bio?: string;
    phone?: string;
    dateOfBirth?: string;
    telegram?: string;
    coordinates?: {
      longitude: number;
      latitude: number;
    };
  };
};

export const updateUser = async (data: UpdateUserDto) => {
  const response = await apiClient.put("/User/update", data);
  return response.data;
};

export const uploadAvatar = async (file: File) => {
  const formData = new FormData();
  formData.append("avatar", file);

  const response = await apiClient.post("/User/avatar", formData, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });

  return response.data;
};
