import { useGetCategories } from "../../entities/category/model/useGetCategories";
import { CategoryListWidget } from "../../widgets/category/CategoryListWidget";
import { PageContainer } from "../../shared/containers/page/PageContainer";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { CircularProgress, Box } from "@mui/material";

export const CategoryPage = () => {
  const { data: categories, isLoading, isError } = useGetCategories();

  return (
    <ProfileLayout>
      <HeaderWidget />
      <PageContainer label="Categories" maxWidth="240px" />

      {(isLoading || isError) && (
        <Box
          display="flex"
          flexDirection="column"
          justifyContent="center"
          alignItems="center"
          width="100%"
          minHeight="550px"
          gap={2}
        >
          {isLoading && <CircularProgress size={56} />}
          {isError && (
            <h1 className="errorPage">Failed to load Categories try again</h1>
          )}
        </Box>
      )}

      {!isLoading && !isError && categories && (
        <CategoryListWidget categories={categories} />
      )}
    </ProfileLayout>
  );
};
