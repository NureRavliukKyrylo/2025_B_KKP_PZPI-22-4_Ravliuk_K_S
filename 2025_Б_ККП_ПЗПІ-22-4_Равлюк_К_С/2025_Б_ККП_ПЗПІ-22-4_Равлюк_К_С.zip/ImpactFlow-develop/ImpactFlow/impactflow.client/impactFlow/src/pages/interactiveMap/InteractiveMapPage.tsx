import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import styles from "./InteractiveMapPage.module.scss";
import { useEffect } from "react";
import { hydrateFromUrl } from "../../entities/filter/store/filterStore";
import { FilterBlockInteractiveMap } from "../../widgets/interactiveMap/filters/FilterBlockInteractiveMap";
import { InteractiveMap } from "../../entities/interactiveMap/ui/InteractiveMap";
import { usegetInititativesMap } from "../../entities/initiatives/model/useGetInitiativesMap";
import { useGetCategories } from "../../entities/category/model/useGetCategories";
import { CircularProgress, Box } from "@mui/material";

export const InteractiveMapPage = () => {
  const {
    data: initiatives,
    isLoading: isInitiativesLoading,
    isError: isInitiativesError,
    isError400,
  } = usegetInititativesMap();

  const {
    data: categories,
    isLoading: isCategoriesLoading,
    isError: isCategoriesError,
  } = useGetCategories();

  const isLoading = isInitiativesLoading && isCategoriesLoading;
  const isError = isInitiativesError || isCategoriesError;

  useEffect(() => {
    hydrateFromUrl();
  }, []);

  return (
    <ProfileLayout>
      <HeaderWidget />
      <div className={styles.interactiveMapBlock}>
        {(isLoading || (isError && !isError400)) && (
          <Box
            display="flex"
            flexDirection="column"
            justifyContent="center"
            alignItems="center"
            width="100%"
            minHeight="550px"
            gap={2}
          >
            {isLoading && <CircularProgress size={56} />}
            {isError && (
              <h1 className="errorPage">Failed to load data. Try again.</h1>
            )}
          </Box>
        )}
        {!isLoading &&
          (!isError || isError400) &&
          initiatives &&
          categories && (
            <>
              <div className={styles.filterBlock}>
                <FilterBlockInteractiveMap categories={categories} />
              </div>

              <div className={styles.interactiveMap}>
                <InteractiveMap initiatives={initiatives} />
              </div>
            </>
          )}
      </div>
    </ProfileLayout>
  );
};
