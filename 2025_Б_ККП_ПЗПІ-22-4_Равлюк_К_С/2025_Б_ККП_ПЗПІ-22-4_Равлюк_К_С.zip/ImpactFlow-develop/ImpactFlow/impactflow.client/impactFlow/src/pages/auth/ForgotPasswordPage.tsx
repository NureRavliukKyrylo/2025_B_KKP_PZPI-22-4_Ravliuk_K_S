import { BaseLayout } from "../../shared/layouts/auth";
import { AuthContainer } from "../../shared/containers";
import { ForgotPasswordForm } from "../../features/auth/forgotPassword/ui/ForgotPasswordForm";

export const ForgotPasswordPage = () => {
  return (
    <BaseLayout>
      <AuthContainer variant="login">
        <ForgotPasswordForm></ForgotPasswordForm>
      </AuthContainer>
    </BaseLayout>
  );
};
