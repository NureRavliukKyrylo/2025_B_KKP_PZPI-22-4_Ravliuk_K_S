import React, { useEffect } from "react";
import { useGetMyInitiatives } from "../../entities/myInitiatives/model/useGetMyInitiatives";
import { MyInitiativeListWidget } from "../../widgets/myInitiatives/MyInitiativeListWidget";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { PageContainer } from "../../shared/containers/page/PageContainer";
import { CircularProgress, Box } from "@mui/material";

export const MyInitiativesPage: React.FC = () => {
  const { data: initiatives, isLoading, isError, error } = useGetMyInitiatives();

  useEffect(() => {
    if (isError && error) {
      console.error("Error fetching my initiatives:", error);
    }
  }, [isError, error]);

  return (
    <ProfileLayout>
      <HeaderWidget />
      <PageContainer label="My Initiatives" maxWidth="300px" />

      {isLoading && (
        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          minHeight="200px"
        >
          <CircularProgress />
        </Box>
      )}

      {!isLoading && isError && (
        <div style={{ color: "red", textAlign: "center", marginTop: "20px" }}>
          Failed to load your initiatives.
        </div>
      )}

      {!isLoading && !isError && (
        <MyInitiativeListWidget initiatives={initiatives} />
      )}
    </ProfileLayout>
  );
};
