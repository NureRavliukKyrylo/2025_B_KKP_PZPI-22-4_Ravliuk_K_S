import { PageContainer } from "../../shared/containers/page/PageContainer";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { VolunteerSkillsWidget } from "../../widgets/skills/volunteer/VolunteerSkillsWidget";
import { useGetMySkills } from "../../entities/skills/volunteer/model/useGetMySkills";
import { CircularProgress, Box } from "@mui/material";

export const SkillsVolunteerPage = () => {
  const { data: skills, isLoading, isError } = useGetMySkills();

  return (
    <ProfileLayout>
      <HeaderWidget />
      <PageContainer label="Skills" maxWidth="241px" />

      {(isLoading || isError) && (
        <Box
          display="flex"
          flexDirection="column"
          justifyContent="center"
          alignItems="center"
          width="100%"
          minHeight="550px"
          gap={2}
        >
          {isLoading && <CircularProgress size={56} />}
          {isError && (
            <h1 className="errorPage">Failed to load Your skills try again</h1>
          )}
        </Box>
      )}

      {!isLoading && !isError && skills && (
        <VolunteerSkillsWidget skills={skills} />
      )}
    </ProfileLayout>
  );
};
