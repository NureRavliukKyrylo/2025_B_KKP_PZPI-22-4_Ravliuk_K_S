import { BaseLayout } from "../../shared/layouts/auth";
import { AuthContainer } from "../../shared/containers";
import { RegistrationForm } from "../../features/auth/registration";

export const RegistrationPage = () => {
  return (
    <BaseLayout>
      <AuthContainer variant="register">
        <RegistrationForm></RegistrationForm>
      </AuthContainer>
    </BaseLayout>
  );
};
