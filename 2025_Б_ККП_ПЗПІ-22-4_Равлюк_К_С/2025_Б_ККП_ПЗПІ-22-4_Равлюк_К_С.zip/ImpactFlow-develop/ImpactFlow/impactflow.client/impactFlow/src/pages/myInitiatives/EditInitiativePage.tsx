import React, { useEffect, useRef, useMemo } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Formik, Form, Field, ErrorMessage } from "formik";
import type { FormikProps } from "formik";
import * as Yup from "yup";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { PageContainer } from "../../shared/containers/page/PageContainer";
import { MapLocationPicker } from "../../features/map/userLocation/ui/MapLocationPicker";
import { useGetMyInitiatives } from "../../entities/myInitiatives/model/useGetMyInitiatives";
import { useGetCategories } from "../../entities/category/model/useGetCategories";
import { useUpdateInitiative } from "../../entities/myInitiatives/model/useUpdateInitiative";
import type { UpdateProjectDto } from "../../entities/myInitiatives/types/updateProjectTypes";
import styles from "./CreateInitiativePage.module.scss";
import calendarIcon from "../../shared/assets/calendar.png";

interface FormValues {
  id: string;
  title: string;
  description: string;
  categoryIds: string[];
  endAt: string;
  coordinates: { lat: number | null; lng: number | null };
}

export const EditInitiativePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const { data: initiatives } = useGetMyInitiatives();
  const initiative = initiatives?.find((i) => i.id === id);

  const { data: categories, isLoading: catLoading, isError: catError } = useGetCategories();
  const updateMutation = useUpdateInitiative();
  const hiddenInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!initiative) {
      navigate("/initiator-initiatives");
    }
  }, [initiative, navigate]);

  if (!initiative) return null;

  const isId = (s: string) => /^[0-9a-fA-F]{24}$/.test(s);

  const initialCategoryIds = useMemo(() => {
    if (!categories) return initiative.categoryIds;
    return initiative.categoryIds.map((ci) =>
      isId(ci)
        ? ci
        : categories.find((c) => c.name === ci)?.id ?? ci
    );
  }, [initiative.categoryIds, categories]);

  const initialValues: FormValues = {
    id: initiative.id,
    title: initiative.title,
    description: initiative.description,
    categoryIds: initialCategoryIds,
    endAt: initiative.endAt.slice(0, 16),
    coordinates: {
      lat: initiative.location[0]?.location.coordinates.latitude ?? null,
      lng: initiative.location[0]?.location.coordinates.longitude ?? null,
    },
  };

  const validationSchema = Yup.object({
    title: Yup.string().required("Title is required"),
    description: Yup.string().required("Description is required"),
    categoryIds: Yup.array()
      .of(Yup.string())
      .min(1, "Please select at least one category"),
    endAt: Yup.string().required("Deadline is required"),
    coordinates: Yup.object({
      lat: Yup.number()
        .required("Latitude is required")
        .min(-90, "Latitude must be ≥ -90")
        .max(90, "Latitude must be ≤ 90"),
      lng: Yup.number()
        .required("Longitude is required")
        .min(-180, "Longitude must be ≥ -180")
        .max(180, "Longitude must be ≤ 180"),
    }),
  });

  const handleSubmit = (vals: FormValues) => {
    const dto: UpdateProjectDto = {
      id: vals.id,
      title: vals.title,
      description: vals.description,
      endAt: vals.endAt,
      categoryIds: vals.categoryIds,
      location: [
        {
          latitude: vals.coordinates.lat!,
          longitude: vals.coordinates.lng!,
        },
      ],
    };
    updateMutation.mutate(dto);
  };

  return (
    <ProfileLayout>
      <HeaderWidget />
      <PageContainer label="My Initiatives" maxWidth="300px" />

      <div className={styles.workspace}>
        <h1 className={styles.pageTitle}>Edit initiative</h1>

        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
          enableReinitialize
        >
          {({ values, setFieldValue, isSubmitting }: FormikProps<FormValues>) => (
            <Form>
              <div className={styles.fieldWrapper}>
                <Field
                  id="title"
                  name="title"
                  placeholder="Title"
                  className={styles.titleInput}
                />
                <div className={styles.errorText}>
                  <ErrorMessage name="title" />
                </div>
              </div>

              {/* Опис */}
              <div className={styles.fieldWrapper}>
                <Field
                  as="textarea"
                  id="description"
                  name="description"
                  className={styles.descriptionInput}
                  placeholder="Description"
                  rows={4}
                />
                <div className={styles.errorText}>
                  <ErrorMessage name="description" />
                </div>
              </div>

              <div className={styles.categoriesWrapper}>
                <span className={styles.legend}>Categories</span>
                {catLoading && <p className={styles.loadingText}>Loading…</p>}
                {catError && <p className={styles.errorText}>Failed to load categories</p>}
                {!catLoading && !catError && categories && (
                  <div className={styles.categoriesGrid}>
                    {categories.map((cat) => (
                      <label key={cat.id} className={styles.checkboxLabel}>
                        <Field
                          type="checkbox"
                          name="categoryIds"
                          value={cat.id}
                          className={styles.checkboxInput}
                        />
                        {cat.name}
                      </label>
                    ))}
                  </div>
                )}
                <div className={styles.errorText}>
                  <ErrorMessage name="categoryIds" />
                </div>
              </div>

              <div className={styles.mapFieldWrapper}>
                <label className={styles.label}>Location</label>
                <div className={styles.mapWrapper}>
                  <MapLocationPicker
                    formik={
                      {
                        values: { coordinates: values.coordinates },
                        setFieldValue: (field, val) => {
                          if (field === "coordinates" && typeof val === "object") {
                            setFieldValue(field, val);
                          }
                        },
                      } as FormikProps<FormValues>
                    }
                  />
                </div>

                <div className={styles.mapInfoRow}>
                  <div className={styles.deadlineWrapper}>
                    <span className={styles.deadlineLabel}>Deadline</span>
                    <div className={styles.deadlineContent}>
                      <Field
                        innerRef={hiddenInputRef}
                        id="endAt"
                        name="endAt"
                        type="datetime-local"
                        className={styles.hiddenDateTimeInput}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          setFieldValue("endAt", e.target.value)
                        }
                      />
                      <span className={styles.dateText}>
                        {values.endAt
                          ? new Date(values.endAt).toLocaleDateString("en-GB", {
                              day: "2-digit",
                              month: "long",
                              year: "numeric",
                            })
                          : "-- -- ----"}
                      </span>
                      <span className={styles.timeText}>
                        {values.endAt
                          ? new Date(values.endAt).toLocaleTimeString("en-GB", {
                              hour: "2-digit",
                              minute: "2-digit",
                              hour12: false,
                            })
                          : "--:--"}
                      </span>
                      <img
                        src={calendarIcon}
                        alt="Pick date"
                        className={styles.calendarIcon}
                        onClick={() => {
                          if (hiddenInputRef.current?.showPicker) {
                            hiddenInputRef.current.showPicker();
                          } else {
                            hiddenInputRef.current?.focus();
                          }
                        }}
                      />
                    </div>
                    <div className={styles.deadlineError}>
                      <ErrorMessage name="endAt" />
                    </div>
                  </div>

                  <div className={styles.locationContainer}>
                    <span className={styles.locationLegend}>Coordinates</span>
                    <div className={styles.locationValues}>
                      {values.coordinates.lat != null && values.coordinates.lng != null
                        ? `X = ${values.coordinates.lng.toFixed(4)}  Y = ${values.coordinates.lat.toFixed(4)}`
                        : `X = --   Y = --`}
                    </div>
                    <div className={styles.errorText}>
                      <ErrorMessage name="coordinates.lat" />{" "}
                      <ErrorMessage name="coordinates.lng" />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles.submitWrapper}>
                <button
                  type="submit"
                  className={styles.submitButton}
                  disabled={isSubmitting || updateMutation.isPending}
                >
                  {updateMutation.isPending ? "Updating…" : "Update initiative"}
                </button>
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </ProfileLayout>
  );
};
