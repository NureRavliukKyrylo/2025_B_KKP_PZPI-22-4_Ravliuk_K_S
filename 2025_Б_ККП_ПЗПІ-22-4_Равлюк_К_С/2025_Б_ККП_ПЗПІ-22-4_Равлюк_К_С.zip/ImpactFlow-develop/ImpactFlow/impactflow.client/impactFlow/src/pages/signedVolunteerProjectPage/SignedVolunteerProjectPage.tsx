import { PageContainer } from "../../shared/containers/page/PageContainer";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { SignedVolunteerListWidget } from "../../widgets/signedVolunteerProject/SignedVolunteerListProject";
import styles from "./SignedVolunteerProject.module.scss";
import { FilterBlockSignedVolunteerProject } from "../../widgets/signedVolunteerProject/filterBlock/FilterBlockSignedVolunteerProject";
import { SearchBar } from "../../shared/searchBar/SearchBar";
import { useEffect } from "react";
import { hydrateFromUrl } from "../../entities/filter/store/filterStore";
import { useGetCategories } from "../../entities/category/model/useGetCategories";
import { useGetSignedProjectsVolunteer } from "../../entities/signedProjectsVolunteer/model/useGetSignedProjectsVolunteer";
import { CircularProgress, Box } from "@mui/material";

export const SignedVolunteerProjectPage = () => {
  const {
    data: categories,
    isLoading: isCategoriesLoading,
    isError: isCategoriesError,
  } = useGetCategories();
  const {
    data: signedProjects,
    isLoading: isSignedProjectsLoading,
    isError: isSignedProjectsError,
  } = useGetSignedProjectsVolunteer();

  const isLoading = isSignedProjectsLoading && isCategoriesLoading;
  const isError = isSignedProjectsError || isCategoriesError;

  useEffect(() => {
    hydrateFromUrl();
  }, []);

  return (
    <ProfileLayout>
      <HeaderWidget />
      <PageContainer label="Active initatives" maxWidth="303px"></PageContainer>
      <div className={styles.signedVolunteerProjectBlock}>
        {(isLoading || isError) && (
          <Box
            display="flex"
            flexDirection="column"
            justifyContent="center"
            alignItems="center"
            width="100%"
            minHeight="550px"
            gap={2}
          >
            {isLoading && <CircularProgress size={56} />}
            {isError && (
              <h1 className="errorPage">
                Failed to load Active Initiatives try again
              </h1>
            )}
          </Box>
        )}
        {!isCategoriesLoading && categories && !isSignedProjectsError && (
          <div className={styles.signedVolunteerProjectBlock}>
            <div className={styles.filterBlock}>
              <FilterBlockSignedVolunteerProject categories={categories} />
            </div>

            <div className={styles.projectSignedVolunteerList}>
              <div className={styles.searchBarSignedVolunteerBlock}>
                <SearchBar />
              </div>

              <SignedVolunteerListWidget
                projectSigned={signedProjects}
                isLoading={isSignedProjectsLoading}
                isError={isSignedProjectsError}
              />
            </div>
          </div>
        )}
      </div>
    </ProfileLayout>
  );
};
