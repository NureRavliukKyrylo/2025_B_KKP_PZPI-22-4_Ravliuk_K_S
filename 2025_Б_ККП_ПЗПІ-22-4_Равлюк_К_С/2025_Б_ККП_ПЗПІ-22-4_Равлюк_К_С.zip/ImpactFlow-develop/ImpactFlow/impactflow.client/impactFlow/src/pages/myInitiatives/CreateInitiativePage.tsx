import React, { useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { PageContainer } from "../../shared/containers/page/PageContainer";
import { Formik, Form, Field, ErrorMessage } from "formik";
import type { FormikProps } from "formik";
import * as Yup from "yup";
import { MapLocationPicker } from "../../features/map/userLocation/ui/MapLocationPicker";
import { useCreateInitiative } from "../../entities/myInitiatives/model/useCreateInitiative";
import { useGetCategories } from "../../entities/category/model/useGetCategories";
import type { CreateProjectDto } from "../../entities/myInitiatives/types/createProjectTypes";
import styles from "./CreateInitiativePage.module.scss";
import calendarIcon from "../../shared/assets/calendar.png";

interface CreateInitiativeFormValues {
  title: string;
  description: string;
  categoryIds: string[];
  endAt: string;
  coordinates: { lat: number | null; lng: number | null };
}

export const CreateInitiativePage: React.FC = () => {
  const navigate = useNavigate();
  const createMutation = useCreateInitiative();
  const hiddenInputRef = useRef<HTMLInputElement>(null);

  const {
    data: categoryList,
    isLoading: categoriesLoading,
    isError: categoriesError,
  } = useGetCategories();

  const initialValues: CreateInitiativeFormValues = {
    title: "",
    description: "",
    categoryIds: [],
    endAt: "",
    coordinates: { lat: null, lng: null },
  };

  const validationSchema = Yup.object().shape({
    title: Yup.string().required("Title is required"),
    description: Yup.string().required("Description is required"),
    categoryIds: Yup.array()
      .of(Yup.string())
      .min(1, "Please select at least one category"),
    endAt: Yup.string().required("Deadline is required"),
    coordinates: Yup.object().shape({
      lat: Yup.number()
        .required("Latitude is required")
        .min(-90, "Latitude must be ≥ -90")
        .max(90, "Latitude must be ≤ 90"),
      lng: Yup.number()
        .required("Longitude is required")
        .min(-180, "Longitude must be ≥ -180")
        .max(180, "Longitude must be ≤ 180"),
    }),
  });

  useEffect(() => {
    if (createMutation.isSuccess) {
      navigate("/initiator-initiatives");
    }
  }, [createMutation.isSuccess, navigate]);

  const handleSubmit = (values: CreateInitiativeFormValues) => {
    const categoryNames: string[] = values.categoryIds
      .map((id) => categoryList?.find((c) => c.id === id)?.name)
      .filter((name): name is string => Boolean(name));

    const dto: CreateProjectDto = {
      title: values.title,
      description: values.description,
      endAt: values.endAt,
      categoryIds: categoryNames,
      location: [
        {
          latitude: values.coordinates.lat!,
          longitude: values.coordinates.lng!,
        },
      ],
    };

    createMutation.mutate(dto);
  };

  return (
    <ProfileLayout>
      <HeaderWidget />
      <PageContainer label="My Initiatives" maxWidth="300px" />

      <div className={styles.workspace}>
        <h1 className={styles.pageTitle}>Create initiative</h1>

        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {({
            values,
            setFieldValue,
            isSubmitting,
          }: FormikProps<CreateInitiativeFormValues>) => (
            <Form>
              <div className={styles.fieldWrapper}>
                <Field
                  id="title"
                  name="title"
                  placeholder="Title"
                  className={styles.titleInput}
                />
                <div className={styles.errorText}>
                  <ErrorMessage name="title" />
                </div>
              </div>

              <div className={styles.fieldWrapper}>
                <Field
                  as="textarea"
                  id="description"
                  name="description"
                  className={styles.descriptionInput}
                  placeholder="Description"
                  rows={4}
                />
                <div className={styles.errorText}>
                  <ErrorMessage name="description" />
                </div>
              </div>

              <div className={styles.categoriesWrapper}>
                <span className={styles.legend}>Categories</span>
                {categoriesLoading && (
                  <p className={styles.loadingText}>Loading categories...</p>
                )}
                {!categoriesLoading && categoriesError && (
                  <p className={styles.errorText}>
                    Failed to load categories.
                  </p>
                )}
                {!categoriesLoading && !categoriesError && categoryList && (
                  <div className={styles.categoriesGrid}>
                    {categoryList.map((cat) => (
                      <label key={cat.id} className={styles.checkboxLabel}>
                        <Field
                          type="checkbox"
                          name="categoryIds"
                          value={cat.id}
                          className={styles.checkboxInput}
                        />
                        {cat.name}
                      </label>
                    ))}
                  </div>
                )}
                <div className={styles.errorText}>
                  <ErrorMessage name="categoryIds" />
                </div>
              </div>

              <div className={styles.mapFieldWrapper}>
                <label className={styles.label}>Location</label>
                <div className={styles.mapWrapper}>
                  <MapLocationPicker
                    formik={
                      {
                        values: { coordinates: values.coordinates },
                        setFieldValue: (
                          field: keyof CreateInitiativeFormValues,
                          val: any
                        ) => {
                          if (
                            field === "coordinates" &&
                            typeof val === "object"
                          ) {
                            setFieldValue(field, val);
                          }
                        },
                      } as FormikProps<CreateInitiativeFormValues>
                    }
                  />
                </div>
                <div className={styles.mapInfoRow}>
                  <div className={styles.deadlineWrapper}>
                    <span className={styles.deadlineLabel}>Deadline</span>
                    <div className={styles.deadlineContent}>
                      <Field
                        innerRef={hiddenInputRef}
                        id="endAt"
                        name="endAt"
                        type="datetime-local"
                        className={styles.hiddenDateTimeInput}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                          setFieldValue("endAt", e.target.value);
                        }}
                      />
                      <span className={styles.dateText}>
                        {values.endAt
                          ? new Date(values.endAt).toLocaleDateString(
                              "en-GB",
                              {
                                day: "2-digit",
                                month: "long",
                                year: "numeric",
                              }
                            )
                          : "-- -- ----"}
                      </span>
                      <span className={styles.timeText}>
                        {values.endAt
                          ? new Date(values.endAt).toLocaleTimeString("en-GB", {
                              hour: "2-digit",
                              minute: "2-digit",
                              hour12: false,
                            })
                          : "--:--"}
                      </span>
                      <img
                        src={calendarIcon}
                        alt="Pick date"
                        className={styles.calendarIcon}
                        onClick={() => {
                          if (hiddenInputRef.current?.showPicker) {
                            hiddenInputRef.current.showPicker();
                          } else {
                            hiddenInputRef.current?.focus();
                          }
                        }}
                      />
                    </div>
                    <div className={styles.deadlineError}>
                      <ErrorMessage name="endAt" />
                    </div>
                  </div>

                  <div className={styles.locationContainer}>
                    <span className={styles.locationLegend}>Location</span>
                    <div className={styles.locationValues}>
                      {values.coordinates.lat != null &&
                      values.coordinates.lng != null
                        ? `X = ${values.coordinates.lat.toFixed(
                            4
                          )} Y = ${values.coordinates.lng.toFixed(4)}`
                        : `X = --   Y = --`}
                    </div>
                    <div className={styles.errorText}>
                      <ErrorMessage name="coordinates.lat" />{" "}
                      <ErrorMessage name="coordinates.lng" />
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles.submitWrapper}>
                <button
                  type="submit"
                  className={styles.submitButton}
                  disabled={isSubmitting || createMutation.isPending}
                >
                  {isSubmitting || createMutation.isPending
                    ? "Creating..."
                    : "Create initiative"}
                </button>
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </ProfileLayout>
  );
};
