import React, { useMemo } from "react";
import { useParams } from "react-router-dom";
import { MapContainer, Marker, TileLayer } from "react-leaflet";
import { format } from "date-fns";
import "leaflet/dist/leaflet.css";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { ProfileContainer } from "../../shared/containers/profile/ProfileContainer";
import { useGetInitiativeById } from "../../entities/initiative/model/useGetInitiativeById";
import { userMarkerIcon } from "../../shared/lib/map/map";
import { NotFoundPage } from "../notFound/NotFoundPage";
import { PageContainer }               from "../../shared/containers/page/PageContainer";
import { JoinProjectButton } from "../../features/volunteerProject/joinProject/ui/JoinProjectButton";
import TelegramIcon from "../../shared/assets/telegram.png";
import InfoIcon from "../../shared/assets/info.png";
import CalendarIcon from "../../shared/assets/calendar.png";
import styles from "./InitiativeDetailPage.module.scss";
import type { AxiosError } from "axios";

export const InitiativeDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { data: initiative, isLoading, error } = useGetInitiativeById(id!);

  const deadlineString = useMemo(() => {
    if (!initiative?.endAt) return null;
    try {
      return format(new Date(initiative.endAt), "dd MMMM yyyy HH:mm");
    } catch {
      return null;
    }
  }, [initiative?.endAt]);

  if ((error as AxiosError | undefined)?.response?.status === 404) {
    return <NotFoundPage />;
  }

  const location = initiative?.location;

  return (
    <ProfileLayout>
      <HeaderWidget />
      <PageContainer label="Initiative" maxWidth="300px" />
      <ProfileContainer >
        <div className={styles.detailWrapper}>
          <div className={styles.infoColumn}>
            {isLoading && <p>Loading…</p>}

            {initiative && (
              <>
                <h1 className={styles.title}>{initiative.title}</h1>

                <div className={styles.initiatorLine}>
                  <span className={styles.label}>Initiator:&nbsp;</span>
                  <span>{initiative.initiator.fullName}</span>

                  {initiative.initiator.telegram && (
                    <a
                      href={
                        initiative.initiator.telegram.startsWith("http")
                          ? initiative.initiator.telegram
                          : `https://t.me/${initiative.initiator.telegram}`
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <img
                        src={TelegramIcon}
                        alt="Telegram"
                        className={styles.tgIcon}
                      />
                    </a>
                  )}

                  <img src={InfoIcon} alt="Info" className={styles.infoIcon} />
                </div>

                <p className={styles.description}>{initiative.description}</p>

                <div className={styles.categoriesBox}>
                  <span className={styles.categoriesLegend}>Categories</span>

                  {initiative.categories?.length ? (
                    <div className={styles.chipsRow}>
                      {initiative.categories.map((cat) => (
                        <span key={cat} className={styles.chip}>
                          {cat}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className={styles.noCategories}>No categories</p>
                  )}
                </div>

                <div className={styles.joinBtnWrap}>
                  <JoinProjectButton projectId={initiative.id} />
                </div>
              </>
            )}
          </div>

          <div className={styles.mapColumn}>
            {location ? (
              <>
                <MapContainer
                  center={[location.latitude, location.longitude]}
                  zoom={13}
                  scrollWheelZoom={false}
                  style={{
                    width: "100%",
                    height: "100%",
                    minHeight: 550,      
                    borderRadius: 20,
                    marginBottom: 16,
                  }}
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <Marker
                    position={[location.latitude, location.longitude]}
                    icon={userMarkerIcon}
                  />
                </MapContainer>

                <div className={styles.bottomRow}>
                  {deadlineString && (
                    <div className={styles.deadlineContainer}>
                      <span className={styles.deadlineLabel}>Deadline</span>
                      <div className={styles.deadlinePill}>
                        <span className={styles.deadlineText}>
                          {deadlineString}
                        </span>
                        <img
                          src={CalendarIcon}
                          alt="Calendar"
                          className={styles.calendarIcon}
                        />
                      </div>
                    </div>
                  )}

                  <div className={styles.coordsContainer}>
                    <div className={styles.coordsPill}>
                      <span className={styles.coordsValue}>
                        X&nbsp;=&nbsp;{location.longitude.toFixed(4)}
                        &nbsp;Y&nbsp;=&nbsp;{location.latitude.toFixed(4)}
                      </span>
                    </div>
                    <span className={styles.coordsLabel}>Location</span>
                  </div>
                </div>
              </>
            ) : (
              <div className={styles.placeholderBox}>
                <p className={styles.placeholderText}>No location available</p>
              </div>
            )}
          </div>
        </div>
      </ProfileContainer>
    </ProfileLayout>
  );
};
