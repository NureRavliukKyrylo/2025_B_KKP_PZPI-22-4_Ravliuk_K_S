import React, { useEffect, useMemo } from "react";
import { Box, CircularProgress } from "@mui/material";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { FilterBlockInitiativesList as FilterPanel } from "../../widgets/initiativesList/filters/FilterBlockInitiativesList";
import { SortDropdown } from "../../widgets/initiativesList/sort/SortDropdown";
import { SearchBar } from "../../shared/searchBar/SearchBar";
import { useFilterStore, hydrateFromUrl } from "../../entities/filter/store/filterStore";
import { useGetInitiativesList } from "../../entities/initiativeList/model/useGetInitiativesList";
import { useGetCategories } from "../../entities/category/model/useGetCategories";
import { InitiativeCard } from "../../entities/initiativeList/ui/InitiativeCard";
import type { InitiativeDto } from "../../entities/initiativeList/types/initiativeListTypes";
import styles from "./InitiativesListPage.module.scss";

export const InitiativesListPage: React.FC = () => {
  useEffect(() => {
    hydrateFromUrl();
  }, []);

  const { search, endDate, radius, categories, orderBy } = useFilterStore();
  const radiusKm = radius ? Number(radius) : undefined;

  const {
    data: initiativesRaw,
    isLoading,
    isError,
  } = useGetInitiativesList({
    search,
    endBefore: endDate ? endDate.toISOString() : undefined,
    radiusKm,
    orderBy,
  });

  const { data: allCategories } = useGetCategories();
  const catMap = useMemo(
    () => new Map((allCategories ?? []).map(c => [c.id, c.name])),
    [allCategories]
  );

  const initiatives = useMemo<InitiativeDto[]>(() => {
    if (!initiativesRaw) return [];
    if (categories.length === 0) return initiativesRaw;
    return initiativesRaw.filter(i =>
      categories.every(catId => i.categoryIds.includes(catId))
    );
  }, [initiativesRaw, categories]);

  if (isLoading) {
    return (
      <ProfileLayout>
        <HeaderWidget />
        <Box display="flex" justifyContent="center" mt={8}>
          <CircularProgress />
        </Box>
      </ProfileLayout>
    );
  }

  if (isError || !initiativesRaw) {
    return (
      <ProfileLayout>
        <HeaderWidget />
        <Box display="flex" justifyContent="center" mt={8} fontSize={24}>
          Не вдалося завантажити ініціативи
        </Box>
      </ProfileLayout>
    );
  }

  return (
    <ProfileLayout>
      <HeaderWidget />
      <div className={styles.wrapper}>
        <aside className={styles.sidebar}>
          <FilterPanel />
        </aside>
        <section className={styles.content}>
          <div className={styles.topRow}>
            <div className={styles.sortWrapper}><SortDropdown /></div>
            <div className={styles.searchWrapper}><SearchBar /></div>
          </div>
          <div className={styles.grid}>
            {initiatives.map(init => {
              const names = init.categoryIds
                .map(id => catMap.get(id) ?? id)    
                .filter(Boolean) as string[];
              return (
                <InitiativeCard
                  key={init.id}
                  initiative={init}
                  categoryNames={names}
                />
              );
            })}
          </div>
        </section>
      </div>
    </ProfileLayout>
  );
};
