import React from "react";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";

import KirilPhoto from "../../shared/assets/Kiril.jpg";
import DarynaPhoto from "../../shared/assets/Daryna.jpg";
import MykolaPhoto from "../../shared/assets/Mykola.jpg";

import styles from "./ContactsPage.module.scss";

const team = [
  {
    id: 1,
    color: "#184D00",
    photo: KirilPhoto,
    name: "Ravliuk Kyrylo Stanislavovych",
    role: "Frontend Developer",
    bio: [
      `Kyrylo is a third-year student, just 20 years old, who has already made a big impact on the project by developing a large part of the platform’s front-end. He was responsible for designing and implementing essential features such as user registration, login, password recovery, profile management, initiative filtering, an interactive activity map, and the skills page.`,
      `He also ensured full support for both volunteer and organizer roles. For organizers, Kyrylo built tools to create initiatives, manage participants, and assign team roles.`,
      `Working with modern technologies like React, TypeScript, and Zustand, Kyrylo focused on creating a user-friendly, fast, and intuitive experience for everyone on the platform.`,
    ],
    tg: "https://t.me/divinefright",
  },
  {
    id: 2,
    color: "#D28100",
    photo: DarynaPhoto,
    name: "Suprun Daryna Andriyivna",
    role: "Backend Developer",
    bio: [
      `Daryna is a third-year student who took full responsibility for developing the entire backend of the platform. She designed and implemented the server-side architecture, built the API, configured the database, and ensured secure and stable communication between the frontend and backend.`,
      `Daryna worked with technologies such as ASP.NET Core, C#, Entity Framework Core, MongoDB, SignalR, and JWT authentication. Her backend logic supports user management, project coordination, role-based access, data validation, and real-time features.`,
      `Thanks to her work, the platform operates smoothly, securely, and efficiently, serving as a reliable foundation for all user interactions.`,
    ],
    tg: "https://t.me/darfifi",
  },
  {
    id: 3,
    color: "#190087",
    photo: MykolaPhoto,
    name: "Shestakov Mykola Sarkisovich",
    role: "Frontend Developer, UI/UX designer",
    bio: [
      `Mykola is a third-year student who was responsible for the visual design and user experience of the platform. He developed the overall style of the interface, focusing on clarity, accessibility, and consistency across all pages.`,
      `In addition to design, Mykola also implemented key front-end pages, including the initiative list, detailed initiative view, and full cycle of creating, editing, and deleting initiatives, as well as viewing initiative histories for the administrator.`,
      `By combining strong design skills with hands-on front-end development using React and SCSS, Mykola ensured that the platform not only performed well, but also looked and felt intuitive to every user.`,
    ],
    tg: "https://t.me/SV98R",
  },
] as const;

const ContactCard: React.FC<(typeof team)[number]> = ({
  color,
  photo,
  name,
  role,
  bio,
  tg,
}) => (
  <article className={styles.card} style={{ borderColor: color }}>
    <img src={photo} alt={name} className={styles.avatar} />
    <div className={styles.divider} style={{ background: color }} />
    <div className={styles.info}>
      <h2 className={styles.name} style={{ color }}>
        {name}
      </h2>
      <h3 className={styles.role}>{role}</h3>
      {bio.map((p, i) => (
        <p key={i} className={styles.bio}>
          {p}
        </p>
      ))}
      <a
        href={tg}
        target="_blank"
        rel="noopener noreferrer"
        className={styles.button}
        style={{ borderColor: color, color }}
      >
        Open Telegram
      </a>
    </div>
  </article>
);

export const ContactsPage: React.FC = () => (
  <ProfileLayout>
    <HeaderWidget />
    <main className={styles.container}>
      {team.map((m) => (
        <ContactCard key={m.id} {...m} />
      ))}
    </main>
  </ProfileLayout>
);
