import { ProfileLayout } from "../../../shared/layouts/profile/ProfileLayout";
import styles from "./ForbiddenPage.module.scss";
export const ForbiddenPage = () => {
  return (
    <div className={styles.infoTextForbidden}>
      <div>403</div>
      <div className={styles.forbiddenText}>
        Forbidden<span className={styles.blink}>_</span>
      </div>
    </div>
  );
};
