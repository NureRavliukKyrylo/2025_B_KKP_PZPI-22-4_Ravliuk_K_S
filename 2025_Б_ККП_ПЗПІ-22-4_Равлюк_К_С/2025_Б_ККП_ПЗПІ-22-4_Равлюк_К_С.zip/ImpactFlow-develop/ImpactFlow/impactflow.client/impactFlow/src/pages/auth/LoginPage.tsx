import { BaseLayout } from "../../shared/layouts/auth";
import { AuthContainer } from "../../shared/containers";
import { LoginForm } from "../../features/auth/login";

export const LoginPage = () => {
  return (
    <BaseLayout>
      <AuthContainer variant="login">
        <LoginForm></LoginForm>
      </AuthContainer>
    </BaseLayout>
  );
};
