import { BaseLayout } from "../../shared/layouts/auth";
import { AuthContainer } from "../../shared/containers";
import styles from "./CheckEmailPage.module.scss";
import CheckEmailImage from "./../../shared/assets/check_email_image.png";
import { useProfileStore } from "../../entities/user/volunteer/types/profileAvatarStore";

export const CheckEmailPage = () => {
  const email = useProfileStore((state) => state.emailRecover);
  return (
    <BaseLayout>
      <AuthContainer variant="login">
        <div className={styles.blockCheckEmail}>
          <div className={styles.textCheckEmail}>Check your Email</div>
          <div className={styles.blockImageCheckEmail}>
            <img
              src={CheckEmailImage}
              className={styles.imageCheckEmail}
              alt="check-email"
            />
          </div>
          <div className={styles.textInfoCheckEmail}>
            {email ? (
              <p>
                We have sent a password reset link to your email address {email}
              </p>
            ) : (
              <p>email not found</p>
            )}
          </div>
        </div>
      </AuthContainer>
    </BaseLayout>
  );
};
