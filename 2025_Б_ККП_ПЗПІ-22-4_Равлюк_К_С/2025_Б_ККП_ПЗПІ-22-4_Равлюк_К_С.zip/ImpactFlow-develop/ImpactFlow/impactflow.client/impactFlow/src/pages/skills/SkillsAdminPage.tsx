import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { useGetSkills } from "../../entities/skills/admin/model/useGetSkills";
import { SkillsListWidget } from "../../widgets/skills/admin/SkillsListWidget";
import { CircularProgress, Box } from "@mui/material";
import { PageContainer } from "../../shared/containers/page/PageContainer";

export const SkillsAdminPage = () => {
  const { data: skills, isLoading, isError } = useGetSkills();

  return (
    <ProfileLayout>
      <HeaderWidget />
      <PageContainer label="Skills" maxWidth="241px" />

      {(isLoading || isError) && (
        <Box
          display="flex"
          flexDirection="column"
          justifyContent="center"
          alignItems="center"
          width="100%"
          minHeight="550px"
          gap={2}
        >
          {isLoading && <CircularProgress size={56} />}
          {isError && (
            <h1 className="errorPage">Failed to load Skills try again</h1>
          )}
        </Box>
      )}

      {!isLoading && !isError && skills && <SkillsListWidget skills={skills} />}
    </ProfileLayout>
  );
};
