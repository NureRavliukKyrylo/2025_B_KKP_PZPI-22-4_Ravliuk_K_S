import { BaseLayout } from "../../shared/layouts/auth";
import { AuthContainer } from "../../shared/containers";
import { ResetPasswordForm } from "../../features/auth/resetPassword/ui/ResetPasswordForm";

export const ResetPasswordPage = () => {
  return (
    <BaseLayout>
      <AuthContainer variant="login">
        <ResetPasswordForm></ResetPasswordForm>
      </AuthContainer>
    </BaseLayout>
  );
};
