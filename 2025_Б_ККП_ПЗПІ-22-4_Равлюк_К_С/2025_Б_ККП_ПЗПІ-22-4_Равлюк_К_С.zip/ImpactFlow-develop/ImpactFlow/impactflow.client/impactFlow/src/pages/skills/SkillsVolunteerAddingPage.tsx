import { useEffect } from "react";
import { CircularProgress, Box, Typography } from "@mui/material";

import { PageContainer } from "../../shared/containers/page/PageContainer";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { useGetSkills } from "../../entities/skills/admin/model/useGetSkills";
import { VolunteerSkillsAddingWidget } from "../../widgets/skills/volunteer/VolunteerSkillsAddingWidget";
import styles from "./SkillsVolunteerAddingPage.module.scss";
import { SearchBar } from "../../shared/searchBar/SearchBar";
import { hydrateFromUrl } from "../../entities/filter/store/filterStore";

export const SkillsVolunteerAddingPage = () => {
  useEffect(() => {
    hydrateFromUrl();
  }, []);

  const { data: skills, isLoading, isError } = useGetSkills();

  return (
    <ProfileLayout>
      <HeaderWidget />
      <PageContainer label="Add new skills to your profile" maxWidth="452px" />

      <div className={styles.projectSignedVolunteerList}>
        {!isError && (
          <div className={styles.searchBarSignedVolunteerBlock}>
            <SearchBar />
          </div>
        )}
        {!isLoading && !isError && skills && (
          <VolunteerSkillsAddingWidget skills={skills} isLoading={isLoading} />
        )}
      </div>

      {(isLoading || isError) && (
        <Box
          display="flex"
          flexDirection="column"
          justifyContent="center"
          alignItems="center"
          width="100%"
          minHeight="550px"
          gap={2}
        >
          {isLoading && <CircularProgress size={56} />}
          {isError && (
            <h1 className="errorPage">Failed to load Skills try again</h1>
          )}
        </Box>
      )}
    </ProfileLayout>
  );
};
