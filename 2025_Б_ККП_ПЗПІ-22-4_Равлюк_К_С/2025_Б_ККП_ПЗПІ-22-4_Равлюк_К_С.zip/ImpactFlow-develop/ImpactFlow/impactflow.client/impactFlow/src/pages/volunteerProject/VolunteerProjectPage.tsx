import { useParams } from "react-router-dom";
import { useGetVolunteersProject } from "../../entities/volounteerProject/model/useGetVolunteersProject";
import { VolunteersListWidget } from "../../widgets/volunteerProject/ListVolunteersProject";
import { PageContainer } from "../../shared/containers/page/PageContainer";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";

export const VolunteersProjectPage = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const {
    data: project,
    isLoading,
    isError,
  } = useGetVolunteersProject(projectId!);

  return (
    <ProfileLayout>
      <HeaderWidget />
      <PageContainer label="My initatives" maxWidth="241px"></PageContainer>
      {project && (
        <VolunteersListWidget
          projectId={project.id}
          projectTitle={project.title}
          volunteers={project.volunteers.map((v) => ({
            id: v.id,
            fullName: v.fullName,
            roleInProject: v.roleInProject,
          }))}
        />
      )}
    </ProfileLayout>
  );
};
