import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { PageContainer } from "../../shared/containers/page/PageContainer";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { EditProfileWidget } from "../../widgets/profile/EditProfileWidget";
import { useGetUserInfo } from "../../entities/user/volunteer/model/useGetUserInfo";
import { CircularProgress, Box } from "@mui/material";

export const EditProfilePage = () => {
  const { data: user, isLoading, isError } = useGetUserInfo();

  return (
    <ProfileLayout>
      <HeaderWidget></HeaderWidget>
      <PageContainer
        label="Edit profile information"
        maxWidth="445px"
      ></PageContainer>
      {(isLoading || isError) && (
        <Box
          display="flex"
          flexDirection="column"
          justifyContent="center"
          alignItems="center"
          width="100%"
          minHeight="550px"
          gap={2}
        >
          {isLoading && <CircularProgress size={56} />}
          {isError && (
            <h1 className="errorPage">Failed to load Profile try again</h1>
          )}
        </Box>
      )}

      {!isLoading && !isError && user && (
        <EditProfileWidget user={user}></EditProfileWidget>
      )}
    </ProfileLayout>
  );
};
