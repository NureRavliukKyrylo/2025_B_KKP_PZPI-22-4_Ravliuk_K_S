import React, { useEffect, useState, useRef, useMemo } from "react";
import { Link } from "react-router-dom";
import { FiArrowRight } from "react-icons/fi";
import styles from "./NotFoundPage.module.scss";

const SPEED_CODE = 200;
const SPEED_TEXT = 35;
const PAUSE_BETWEEN = 1000;
const SHOW_BUTTON_MS = 6000;

export const NotFoundPage: React.FC = () => {
  const lines = useMemo(
    () => [
      "404",
      "Page Not Found",
      "The page you’re looking for doesn’t exist. Maybe it was moved, or you just typed the wrong URL."
    ],
    []
  );

  const [lineIdx, setLineIdx] = useState(0);
  const [charIdx, setCharIdx] = useState(0);
  const [showBtn, setShowBtn] = useState(false);

  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  useEffect(() => () => timersRef.current.forEach(clearTimeout), []);

  useEffect(() => {
    const currentLine = lines[lineIdx];
    const speed = lineIdx === 0 ? SPEED_CODE : SPEED_TEXT;

    if (charIdx < currentLine.length) {
      timersRef.current.push(setTimeout(() => setCharIdx(c => c + 1), speed));
      return;
    }

    timersRef.current.push(
      setTimeout(() => {
        if (lineIdx < lines.length - 1) {
          setLineIdx(i => i + 1);
          setCharIdx(0);
        } else {
          setShowBtn(true);
          timersRef.current.push(
            setTimeout(() => {
              setShowBtn(false);
              setLineIdx(0);
              setCharIdx(0);
            }, SHOW_BUTTON_MS)
          );
        }
      }, PAUSE_BETWEEN)
    );
  }, [charIdx, lineIdx, lines]);

  const typedCode = lineIdx === 0 ? lines[0].slice(0, charIdx) : lines[0];
  const typedTitle =
    lineIdx >= 1 ? (lineIdx === 1 ? lines[1].slice(0, charIdx) : lines[1]) : "";
  const typedText =
    lineIdx >= 2 ? (lineIdx === 2 ? lines[2].slice(0, charIdx) : lines[2]) : "";

  const cursor = <span className={styles.cursor} />;

  return (
    <div className={styles.wrapper}>
      <h1 className={styles.code}>
        {typedCode}
        {lineIdx === 0 && charIdx < lines[0].length && cursor}
      </h1>

      {!!typedTitle && (
        <h2 className={styles.title}>
          {typedTitle}
          {lineIdx === 1 && charIdx < lines[1].length && cursor}
        </h2>
      )}

      {!!typedText && (
        <p className={styles.text}>
          {typedText}
          {lineIdx === 2 && charIdx < lines[2].length && cursor}
        </p>
      )}

      {showBtn && (
        <Link to="/home" className={styles.homeLink}>
          Go&nbsp;Home
          <FiArrowRight className={styles.icon} />
        </Link>
      )}
    </div>
  );
};
