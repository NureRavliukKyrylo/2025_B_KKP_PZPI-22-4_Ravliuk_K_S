import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { PageContainer } from "../../shared/containers/page/PageContainer";
import { UserProfileWidget } from "../../widgets/profile/UserProfileWidget";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { useGetUserInfo } from "../../entities/user/volunteer/model/useGetUserInfo";
import { CircularProgress, Box } from "@mui/material";

export const ProfilePage = () => {
  const { data: user, isLoading, isError } = useGetUserInfo();
  return (
    <ProfileLayout>
      <HeaderWidget></HeaderWidget>
      <PageContainer label="Profile" maxWidth="241px"></PageContainer>
      {(isLoading || isError) && (
        <Box
          display="flex"
          flexDirection="column"
          justifyContent="center"
          alignItems="center"
          width="100%"
          minHeight="550px"
          gap={2}
        >
          {isLoading && <CircularProgress size={56} />}
          {isError && (
            <h1 className="errorPage">Failed to load Profile try again</h1>
          )}
        </Box>
      )}

      {!isLoading && !isError && user && (
        <UserProfileWidget user={user}></UserProfileWidget>
      )}
    </ProfileLayout>
  );
};
