import React, { useMemo } from "react";
import { Box, CircularProgress } from "@mui/material";
import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { InitiativeCard } from "../../entities/initiativeList/ui/InitiativeCard";
import { useGetInitiativesList } from "../../entities/initiativeList/model/useGetInitiativesList";
import { useGetCategories } from "../../entities/category/model/useGetCategories";
import type { InitiativeDto } from "../../entities/initiativeList/types/initiativeListTypes";
import heroCss from "./HomePage.module.scss";
import carouselCss from "./InitiativeCarousel.module.scss";
import Logo from "../../shared/assets/logo_impact_flow.png";
import { MapContainer, TileLayer } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { MapMarker } from "../../entities/initiatives/ui/MapMarker";

export const HomePage: React.FC = () => {
  const { data: initiatives, isLoading, isError } = useGetInitiativesList();

  const { data: cats } = useGetCategories();
  const catMap = useMemo(
    () => new Map((cats ?? []).map((c) => [c.id, c.name])),
    [cats]
  );

  const loop = useMemo<InitiativeDto[]>(
    () => (initiatives?.length ? [...initiatives, ...initiatives] : []),
    [initiatives]
  );

  return (
    <ProfileLayout>
      <HeaderWidget />

      <section className={heroCss.hero}>
        <h1 className={heroCss.title}>
          Unite volunteers.
          <br />
          Help effectively.
        </h1>

        <p className={heroCss.subtitle}>
          A single platform for coordinating volunteer initiatives across the
          country
        </p>

        <div className={heroCss.actions}>
          <button
            className={`${heroCss.actionBtn} ${heroCss.listBtn}`}
            onClick={() => window.location.assign("/initiatives")}
          >
            Open initiatives list
          </button>

          <button
            className={`${heroCss.actionBtn} ${heroCss.activeBtn}`}
            onClick={() => window.location.assign("/volunteer-initiatives")}
          >
            Open active initiatives
          </button>
        </div>
      </section>

      <section className={carouselCss.carousel}>
        {isLoading && (
          <Box py={4} display="flex" justifyContent="center">
            <CircularProgress />
          </Box>
        )}

        {isError && (
          <Box py={4} textAlign="center" fontSize={24}>
            Failed to load initiatives
          </Box>
        )}

        {loop.length > 0 && (
          <div className={carouselCss.track}>
            {loop.map((i, idx) => (
              <div className={carouselCss.cardWrap} key={`${i.id}-${idx}`}>
                <InitiativeCard
                  initiative={i}
                  categoryNames={
                    i.categoryIds
                      .map((id) => catMap.get(id))
                      .filter(Boolean) as string[]
                  }
                />
              </div>
            ))}
          </div>
        )}
      </section>

      <section className={heroCss.divider}>
        <img src={Logo} alt="ImpactFlow" className={heroCss.logoDivider} />
      </section>

      <section className={heroCss.mapSection}>
        <div className={heroCss.mapWrap}>
          <MapContainer
            center={[50.45, 30.523]}
            zoom={13}
            scrollWheelZoom={false}
            style={{ width: "100%", height: "100%" }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/">OSM</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            {initiatives?.map((init) => (
              <MapMarker key={init.id} markerInitiative={init as any} />
            ))}
          </MapContainer>
        </div>

        <div className={heroCss.mapText}>
          <h2 className={heroCss.mapTitle}>We unite for action!</h2>

          <p className={heroCss.mapParagraph}>
            In today's world, where every minute can be crucial, effective
            coordination of volunteer assistance is not a luxury but a
            necessity. However, today volunteer initiatives often operate in a
            fragmented information space: social media posts, manual search for
            help, difficulties with logistics and engagement. We are changing
            this.
          </p>

          <button
            className={heroCss.mapBtn}
            onClick={() => window.location.assign("/map")}
          >
            Open the initiative map
          </button>
        </div>
      </section>
      <section className={heroCss.footnote}>
        ImpactFlow is an innovative online platform designed to connect
        volunteers, organizations and charities into a single digital ecosystem.
      </section>
    </ProfileLayout>
  );
};
