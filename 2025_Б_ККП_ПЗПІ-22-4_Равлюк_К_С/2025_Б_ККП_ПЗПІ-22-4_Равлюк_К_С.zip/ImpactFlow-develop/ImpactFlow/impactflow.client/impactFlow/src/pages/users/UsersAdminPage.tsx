import { useEffect } from "react";
import { CircularProgress, Box, Typography } from "@mui/material";

import { ProfileLayout } from "../../shared/layouts/profile/ProfileLayout";
import { HeaderWidget } from "../../widgets/header/HeaderWidget";
import { useGetAllUsers } from "../../entities/user/admin/model/useGetAllUsers";
import { UserListWidget } from "../../widgets/users/UserListWidget";
import { SearchBar } from "../../shared/searchBar/SearchBar";
import styles from "./UsersAdminPage.module.scss";
import { PageContainer } from "../../shared/containers/page/PageContainer";
import { hydrateFromUrl } from "../../entities/filter/store/filterStore";

export const UsersAdminPage = () => {
  useEffect(() => {
    hydrateFromUrl();
  }, []);

  const { data: users, isLoading, isError } = useGetAllUsers();

  const isEmpty = !isLoading && !isError && users && users.length === 0;

  return (
    <ProfileLayout>
      <HeaderWidget />
      <PageContainer label="Users" maxWidth="241px" />

      <div className={styles.adminUsersList}>
        {!isError && (
          <div className={styles.searchBarAdminUsersList}>
            <SearchBar />
          </div>
        )}

        {!isLoading && !isError && users && (
          <UserListWidget
            users={users}
            isEmpty={isEmpty}
            isLoading={isLoading}
          />
        )}
      </div>

      {(isLoading || isError) && (
        <Box
          display="flex"
          flexDirection="column"
          justifyContent="center"
          alignItems="center"
          width="100%"
          minHeight="550px"
          gap={2}
        >
          {isLoading && <CircularProgress size={56} />}
          {isError && (
            <h1 className="errorPage">Failed to load Users try again</h1>
          )}
        </Box>
      )}
    </ProfileLayout>
  );
};
