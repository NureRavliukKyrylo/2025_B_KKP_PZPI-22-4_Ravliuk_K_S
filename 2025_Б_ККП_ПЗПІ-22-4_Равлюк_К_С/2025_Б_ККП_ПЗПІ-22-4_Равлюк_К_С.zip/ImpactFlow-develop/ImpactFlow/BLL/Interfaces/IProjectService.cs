﻿using Core.Enums;
using Core.Models;

namespace BLL.Interfaces
{
    public interface IProjectService : IGenericService<Project>
    {
        Task<Result<string>> CreateProject(Project project);
        Task<Result> UpdateProject(Project project);
        Task<Result> DeleteProject(string id);
        Task<Result<List<Project>>> GetProjectsByOwner(string ownerId);
        Task<Result<List<Project>>> GetAllProjects(
            ProjectSortingParams orderBy = ProjectSortingParams.Default,
            DateTime? endBefore = null,
            List<string>? categoryIds = null,
            double? radiusKm = null,
            string? userId = null,
            string? search = null);
        Task<Result> SignUpVolunteer(string projectId, string userId);
        Task<Result<List<Project>>> GetEnrolledProjects(string userId);
        Task<Result> RemoveVolunteerFromProject(string projectId, string volunteerId, string currentUserId, bool isAdmin);
        Task<Result<List<Participation>>> GetActiveParticipationsForUser(string userId);
        Task<Result<List<Participation>>> GetActiveParticipationsForOwner(string ownerId);
        Task<Result<List<Participation>>> GetAllParticipationsForProject(string projectId);
        Task<Result> UpdateParticipationRole(string projectId, string volunteerId, string newRole, string currentUserId, bool isAdmin);
        Task<Result> LeaveProject(string projectId, string userId);
    }
}
