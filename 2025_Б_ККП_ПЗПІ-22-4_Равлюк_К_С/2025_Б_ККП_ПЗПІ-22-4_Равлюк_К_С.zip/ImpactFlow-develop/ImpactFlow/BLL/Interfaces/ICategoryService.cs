﻿using Core.Models;

namespace BLL.Interfaces
{
    public interface ICategoryService : IGenericService<Category>
    {
        Task<Result<string>> CreateCategory(Category category);
        Task<Result> UpdateCategory(Category category);
        Task<Result> DeleteCategory(string id);
    }
}
