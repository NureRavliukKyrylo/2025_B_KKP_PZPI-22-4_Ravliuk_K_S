﻿using Core.Models;
using Microsoft.AspNetCore.Http;

namespace BLL.Interfaces
{
    public interface IUserService : IGenericService<User>
    {
        Task<Result<User>> GetUser();
        Task<Result> UpdateUser(User user);
        Task<Result> DeleteUser();
        Task<Result<string>> UpdateUserAvatarAsync(IFormFile avatarFile);
        Task<Result> DeleteUserById(string userId);
        Task<Result<List<User>>> GetAllUsers();
    }
}
