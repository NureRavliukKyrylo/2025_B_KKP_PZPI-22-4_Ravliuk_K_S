﻿namespace BLL.Interfaces
{
    public interface IAzureBlobService
    {
        Task<string> UploadAsync(Stream fileStream, string fileName, string contentType);
        Task DeleteAsync(string fileName);
        string GetUrl(string fileName);
    }
}
