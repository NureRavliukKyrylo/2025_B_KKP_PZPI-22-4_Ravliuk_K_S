﻿using System.Linq.Expressions;
using Core.Models;

namespace BLL.Interfaces;

public interface IGenericService<T> where T : class
{
    Task<Result<T>> GetById(string id);
    Task<Result<List<T>>> GetByPredicate(
        Expression<Func<T, bool>> filter = null,
        Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null);
    Task<Result<List<T>>> GetAll();
    Task<Result<T>> GetCurrentUser();
}
