﻿using Core.Enums;
using Core.Models;

namespace BLL.Interfaces
{
    public interface ISkillService : IGenericService<Skill>
    {
        Task<Result<string>> CreateSkill(Skill skill);
        Task<Result> UpdateSkill(Skill skill);
        Task<Result> DeleteSkill(string id);

        Task<Result> AddSkillToVolunteer(string userId, string skillId, SkillLevel level);

        Task<Result> UpdateVolunteerSkillLevel(string userId, string skillId, SkillLevel newLevel);

        Task<Result> VerifyVolunteerSkill(string userId, string skillId);

        Task<Result> RemoveVolunteerSkill(string userId, string skillId);

        Task<Result<List<VolunteerSkill>>> GetSkillsForVolunteer(string userId);

        Task<Result<List<VolunteerSkill>>> GetVolunteersWithSkill(string skillId);

        Task<Result<List<Skill>>> GetAllSkills(string? search = null);
    }
}
