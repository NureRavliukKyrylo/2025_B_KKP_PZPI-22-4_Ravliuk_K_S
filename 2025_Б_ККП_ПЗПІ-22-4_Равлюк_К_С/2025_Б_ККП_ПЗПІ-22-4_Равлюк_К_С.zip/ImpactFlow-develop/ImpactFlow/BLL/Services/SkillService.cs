﻿using System.Linq.Expressions;
using BLL.Interfaces;
using Core.Enums;
using Core.Models;
using DAL.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace BLL.Services
{
    public class SkillService : GenericService<Skill>, ISkillService
    {
        private readonly ILogger<SkillService> _logger;

        public SkillService(UnitOfWork unitOfWork, ILogger<SkillService> logger, IHttpContextAccessor contextAccessor)
            : base(unitOfWork, unitOfWork.Skills, contextAccessor)
        {
            _logger = logger;
        }

        public async Task<Result<string>> CreateSkill(Skill skill)
        {
            _logger.LogInformation("Creating new skill");

            if (skill == null)
            {
                _logger.LogError("Skill creation failed - skill is null");
                return new Result<string>(false);
            }

            try
            {
                skill.Id = null!;
                await _repository.AddAsync(skill);
                _logger.LogInformation("Skill created successfully with ID {Id}", skill.Id);
                return new Result<string>(true, skill.Id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to create skill: {Error}", ex.Message);
                return new Result<string>(false);
            }
        }

        public async Task<Result> UpdateSkill(Skill skill)
        {
            _logger.LogInformation("Updating skill with ID {Id}", skill.Id);

            if (skill == null)
            {
                _logger.LogError("Skill update failed - skill is null");
                return new Result(false);
            }

            try
            {
                await _repository.UpdateAsync(skill.Id, skill);
                _logger.LogInformation("Skill {Id} updated successfully", skill.Id);
                return new Result(true);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to update skill {Id}: {Error}", skill.Id, ex.Message);
                return new Result(false);
            }
        }

        public async Task<Result> DeleteSkill(string id)
        {
            _logger.LogInformation("Initiating cascade deletion for skill {SkillId}", id);

            var skill = await _repository.GetByIdAsync(id);
            if (skill == null)
            {
                _logger.LogWarning("Skill {SkillId} not found", id);
                return new Result(false);
            }

            try
            {
                var volunteerSkills = await _unitOfWork.VolunteerSkills.FindAsync(vs => vs.SkillId == id);
                _logger.LogInformation("Found {Count} volunteer skills with skill {SkillId}", volunteerSkills.Count, id);

                foreach (var vs in volunteerSkills)
                {
                    _logger.LogInformation("Removing skill {SkillId} from user {UserId}", id, vs.UserId);

                    var removeResult = await RemoveVolunteerSkill(vs.UserId, id);
                    if (!removeResult.IsSuccessful)
                    {
                        _logger.LogWarning("Failed to remove VolunteerSkill for user {UserId} and skill {SkillId}", vs.UserId, id);
                        continue;
                    }

                    var user = await _unitOfWork.Users.GetByIdAsync(vs.UserId);
                    if (user != null)
                    {
                        var beforeCount = user.Skills.Count;
                        user.Skills.RemoveAll(s => s.SkillId == id);
                        var afterCount = user.Skills.Count;

                        if (beforeCount != afterCount)
                        {
                            await _unitOfWork.Users.UpdateAsync(user.Id, user);
                            _logger.LogInformation("Removed skill {SkillId} from User.Skills list for user {UserId}", id, user.Id);
                        }
                    }
                }

                await _repository.DeleteAsync(id);
                _logger.LogInformation("Skill {SkillId} deleted successfully", id);

                return new Result(true);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to delete skill {SkillId}: {Error}", id, ex.Message);
                return new Result(false);
            }
        }

        public async Task<Result> AddSkillToVolunteer(string userId, string skillId, SkillLevel level)
        {
            _logger.LogInformation("Adding skill {SkillId} to user {UserId} with level {Level}", skillId, userId, level);

            var exists = await _unitOfWork.VolunteerSkills.FindAsync(vs => vs.UserId == userId && vs.SkillId == skillId);
            if (exists.Any())
            {
                _logger.LogWarning("User {UserId} already has skill {SkillId}", userId, skillId);
                return new Result(false);
            }

            var vs = new VolunteerSkill
            {
                UserId = userId,
                SkillId = skillId,
                Level = level,
                Verified = false,
                AddedAt = DateTime.UtcNow
            };

            await _unitOfWork.VolunteerSkills.AddAsync(vs);
            _logger.LogInformation("Skill {SkillId} successfully added to user {UserId}", skillId, userId);
            return new Result(true);
        }

        public async Task<Result> UpdateVolunteerSkillLevel(string userId, string skillId, SkillLevel newLevel)
        {
            _logger.LogInformation("Updating skill level for user {UserId} and skill {SkillId} to {Level}", userId, skillId, newLevel);

            var vs = (await _unitOfWork.VolunteerSkills.FindAsync(v => v.UserId == userId && v.SkillId == skillId)).FirstOrDefault();
            if (vs == null)
            {
                _logger.LogWarning("No skill found for user {UserId} with skill {SkillId}", userId, skillId);
                return new Result(false);
            }

            vs.Level = newLevel;
            await _unitOfWork.VolunteerSkills.UpdateAsync(vs.Id, vs);

            _logger.LogInformation("Skill level updated for user {UserId}, skill {SkillId}", userId, skillId);
            return new Result(true);
        }

        public async Task<Result> VerifyVolunteerSkill(string userId, string skillId)
        {
            _logger.LogInformation("Verifying skill {SkillId} for user {UserId}", skillId, userId);

            var vs = (await _unitOfWork.VolunteerSkills.FindAsync(v => v.UserId == userId && v.SkillId == skillId)).FirstOrDefault();
            if (vs == null)
            {
                _logger.LogWarning("No skill found to verify for user {UserId} with skill {SkillId}", userId, skillId);
                return new Result(false);
            }

            vs.Verified = true;
            await _unitOfWork.VolunteerSkills.UpdateAsync(vs.Id, vs);

            _logger.LogInformation("Skill {SkillId} verified for user {UserId}", skillId, userId);
            return new Result(true);
        }

        public async Task<Result> RemoveVolunteerSkill(string userId, string skillId)
        {
            _logger.LogInformation("Attempting to remove skill {SkillId} from user {UserId}", skillId, userId);

            try
            {
                var vs = (await _unitOfWork.VolunteerSkills.FindAsync(v => v.UserId == userId && v.SkillId == skillId)).FirstOrDefault();
                if (vs == null)
                {
                    _logger.LogWarning("Volunteer skill not found for user {UserId} and skill {SkillId}", userId, skillId);
                    return new Result(false);
                }

                await _unitOfWork.VolunteerSkills.DeleteAsync(vs.Id);
                _logger.LogInformation("Successfully removed skill {SkillId} from user {UserId}", skillId, userId);
                return new Result(true);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing skill {SkillId} from user {UserId}: {Error}", skillId, userId, ex.Message);
                return new Result(false);
            }
        }

        public async Task<Result<List<VolunteerSkill>>> GetSkillsForVolunteer(string userId)
        {
            _logger.LogInformation("Retrieving skills for volunteer {UserId}", userId);

            try
            {
                var skills = await _unitOfWork.VolunteerSkills.FindAsync(v => v.UserId == userId);
                _logger.LogInformation("Found {Count} skills for volunteer {UserId}", skills.Count, userId);
                return new Result<List<VolunteerSkill>>(true, skills);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error retrieving skills for user {UserId}: {Error}", userId, ex.Message);
                return new Result<List<VolunteerSkill>>(false);
            }
        }

        public async Task<Result<List<VolunteerSkill>>> GetVolunteersWithSkill(string skillId)
        {
            _logger.LogInformation("Retrieving volunteers with skill {SkillId}", skillId);

            try
            {
                var volunteers = await _unitOfWork.VolunteerSkills.FindAsync(v => v.SkillId == skillId);
                _logger.LogInformation("Found {Count} volunteers with skill {SkillId}", volunteers.Count, skillId);
                return new Result<List<VolunteerSkill>>(true, volunteers);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error retrieving volunteers with skill {SkillId}: {Error}", skillId, ex.Message);
                return new Result<List<VolunteerSkill>>(false);
            }
        }

        public async Task<Result<List<Skill>>> GetAllSkills(string? search = null)
        {
            _logger.LogInformation("Retrieving all skills{Filter}", string.IsNullOrWhiteSpace(search) ? "" : $" with filter: {search}");

            Expression<Func<Skill, bool>>? filter = null;

            if (!string.IsNullOrWhiteSpace(search))
            {
                filter = s =>
                    s.Name.ToLower().Contains(search.ToLower()) ||
                    (s.Description != null && s.Description.ToLower().Contains(search.ToLower()));
            }

            try
            {
                return await GetByPredicate(filter);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to retrieve skills: {Error}", ex.Message);
                return new Result<List<Skill>>(false);
            }
        }
    }
}
