﻿using System.Linq.Expressions;
using System.Security.Claims;
using BLL.Interfaces;
using Core.Models;
using DAL.Repositories;
using Microsoft.AspNetCore.Http;

namespace BLL.Services;

public class GenericService<T> : IGenericService<T> where T : class
{
    protected readonly UnitOfWork _unitOfWork;
    protected readonly IRepository<T> _repository;
    protected readonly IHttpContextAccessor _contextAccessor;

    protected string? CurrentUserId =>
        _contextAccessor.HttpContext?.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

    public GenericService(
        UnitOfWork unitOfWork,
        IRepository<T> repository,
        IHttpContextAccessor contextAccessor)
    {
        _unitOfWork = unitOfWork;
        _repository = repository;
        _contextAccessor = contextAccessor;
    }

    public async Task<Result<T>> GetById(string id)
    {
        try
        {
            var entity = await _repository.GetByIdAsync(id);

            return entity != null
                ? new Result<T>(true, entity)
                : new Result<T>(false);
        }
        catch (Exception ex)
        {
            return new Result<T>(false);
        }
    }

    public async Task<Result<List<T>>> GetByPredicate(
    Expression<Func<T, bool>> filter = null,
    Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null)
    {
        try
        {
            var result = filter != null
                ? await _repository.FindAsync(filter)
                : await _repository.GetAllAsync();

            return result != null
                ? new Result<List<T>>(true, result)
                : new Result<List<T>>(false);
        }
        catch
        {
            return new Result<List<T>>(false);
        }
    }

    public async Task<Result<List<T>>> GetAll()
    {
        try
        {
            var result = await _repository.GetAllAsync();
            return result != null
                ? new Result<List<T>>(true, result)
                : new Result<List<T>>(false);
        }
        catch
        {
            return new Result<List<T>>(false);
        }
    }

    public async Task<Result<T>> GetCurrentUser()
    {
        if (string.IsNullOrEmpty(CurrentUserId))
            return new Result<T>(false);

        return await GetById(CurrentUserId);
    }
}
