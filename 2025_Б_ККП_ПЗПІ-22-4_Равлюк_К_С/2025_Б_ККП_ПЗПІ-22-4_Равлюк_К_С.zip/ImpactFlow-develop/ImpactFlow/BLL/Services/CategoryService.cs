﻿using BLL.Interfaces;
using Core.Models;
using DAL.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace BLL.Services
{
    public class CategoryService : GenericService<Category>, ICategoryService
    {
        private readonly ILogger<CategoryService> _logger;
        private readonly IProjectService _projectService;
        public CategoryService(
            UnitOfWork unitOfWork,
            ILogger<CategoryService> logger,
            IHttpContextAccessor contextAccessor,
            IProjectService projectService)
            : base(unitOfWork, unitOfWork.Categories, contextAccessor)
        {
            _logger = logger;
            _projectService = projectService;
        }

        public async Task<Result<string>> CreateCategory(Category category)
        {
            _logger.LogInformation("Creating a new category");

            if (category == null)
            {
                _logger.LogError("Category creation failed - input is null");
                return new Result<string>(false);
            }

            try
            {
                await _repository.AddAsync(category);
                _logger.LogInformation("Category '{Name}' created successfully with ID: {Id}", category.Name, category.Id);
                return new Result<string>(true, category.Id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to create category: {Error}", ex.Message);
                return new Result<string>(false);
            }
        }

        public async Task<Result> UpdateCategory(Category category)
        {
            _logger.LogInformation("Updating category with ID: {Id}", category.Id);

            if (category == null)
            {
                _logger.LogError("Category update failed - input is null");
                return new Result(false);
            }

            try
            {
                await _repository.UpdateAsync(category.Id, category);
                _logger.LogInformation("Category with ID {Id} updated successfully", category.Id);
                return new Result(true);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to update category with ID {Id}: {Error}", category.Id, ex.Message);
                return new Result(false);
            }
        }

        public async Task<Result> DeleteCategory(string id)
        {
            _logger.LogInformation("Starting cascade deletion for category {CategoryId}", id);

            try
            {
                var category = await _repository.GetByIdAsync(id);
                if (category == null)
                {
                    _logger.LogWarning("Category with ID {CategoryId} not found", id);
                    return new Result(false);
                }

                var projectsResult = await _projectService.GetAllProjects();
                if (projectsResult.IsSuccessful)
                {
                    foreach (var project in projectsResult.Data.Where(p => p.CategoryIds.Contains(id)))
                    {
                        project.CategoryIds.Remove(id);
                        var updateResult = await _projectService.UpdateProject(project);

                        if (updateResult.IsSuccessful)
                        {
                            _logger.LogInformation("Removed category {CategoryId} from project {ProjectId}", id, project.Id);
                        }
                        else
                        {
                            _logger.LogWarning("Failed to update project {ProjectId} after removing category {CategoryId}", project.Id, id);
                        }
                    }
                }
                else
                {
                    _logger.LogWarning("Failed to retrieve projects for category cleanup");
                }

                await _repository.DeleteAsync(id);
                _logger.LogInformation("Category {CategoryId} deleted successfully", id);

                return new Result(true);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to delete category {CategoryId}: {Error}", id, ex.Message);
                return new Result(false);
            }
        }
    }
}
