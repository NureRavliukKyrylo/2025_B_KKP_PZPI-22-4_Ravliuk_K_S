﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using BLL.Interfaces;
using Core.Configurations;
using Microsoft.Extensions.Options;

namespace BLL.Services
{
    public class AzureBlobService : IAzureBlobService
    {
        private readonly BlobContainerClient _containerClient;

        public AzureBlobService(IOptions<AzureBlobSettings> options)
        {
            var settings = options.Value;
            var blobServiceClient = new BlobServiceClient(settings.ConnectionString);
            _containerClient = blobServiceClient.GetBlobContainerClient(settings.ContainerName);
        }

        public async Task<string> UploadAsync(Stream fileStream, string fileName, string contentType)
        {
            var blobClient = _containerClient.GetBlobClient(fileName);

            var blobHttpHeader = new BlobHttpHeaders
            {
                ContentType = contentType
            };

            await blobClient.UploadAsync(fileStream, new BlobUploadOptions
            {
                HttpHeaders = blobHttpHeader
            });

            return blobClient.Uri.ToString();
        }

        public async Task DeleteAsync(string fileName)
        {
            var blobClient = _containerClient.GetBlobClient(fileName);
            await blobClient.DeleteIfExistsAsync();
        }

        public string GetUrl(string fileName)
        {
            return _containerClient.GetBlobClient(fileName).Uri.ToString();
        }
    }
}
