﻿using BLL.Interfaces;
using Core.Enums;
using Core.Helpers;
using Core.Models;
using DAL.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace BLL.Services
{
    public class UserService : GenericService<User>, IUserService
    {
        private readonly ILogger<UserService> _logger;
        private readonly IAzureBlobService _blobService;
        private readonly IProjectService _projectService;
        private readonly ISkillService _skillService;

        public UserService(
            UnitOfWork unitOfWork,
            ILogger<UserService> logger,
            IAzureBlobService blobService,
            IHttpContextAccessor contextAccessor,
            IProjectService projectService,
            ISkillService skillService)
            : base(unitOfWork, unitOfWork.Users, contextAccessor)
        {
            _logger = logger;
            _blobService = blobService;
            _projectService = projectService;
            _skillService = skillService;
        }

        public async Task<Result<User>> GetUser()
        {
            _logger.LogInformation("Getting current user");

            var result = await GetCurrentUser();
            if (!result.IsSuccessful || result.Data is null)
                return new Result<User>(false);

            return new Result<User>(true, result.Data);
        }

        public async Task<Result> UpdateUser(User updatedUser)
        {
            _logger.LogInformation("Updating current user");

            var result = await GetCurrentUser();
            if (!result.IsSuccessful || result.Data is null)
                return new Result(false);

            var existingUser = result.Data;

            existingUser.MapFrom(updatedUser);
            existingUser.Availability = updatedUser.Availability ?? new List<AvailabilitySlot>();

            if (updatedUser.Profile != null)
            {
                if (!IsProfileValid(updatedUser.Profile, out string error))
                {
                    _logger.LogWarning("Profile update failed: {Error}", error);
                    return new Result(false);
                }

                if (existingUser.Profile?.AvatarUrl != null &&
                    existingUser.Profile.AvatarUrl != updatedUser.Profile.AvatarUrl)
                {
                    await DeleteAvatar(existingUser.Profile.AvatarUrl);
                }

                existingUser.Profile ??= new UserProfile();
                existingUser.Profile.MapFrom(updatedUser.Profile);
            }

            await _unitOfWork.Users.UpdateAsync(existingUser.Id, existingUser);
            return new Result(true);
        }

        public async Task<Result> DeleteUser()
        {
            _logger.LogInformation("Deleting current user with full cascade cleanup");

            var result = await GetCurrentUser();
            if (!result.IsSuccessful || result.Data is null)
            {
                _logger.LogWarning("User not found or not authenticated");
                return new Result(false);
            }

            var user = result.Data;

            if (!string.IsNullOrEmpty(user.Profile?.AvatarUrl))
            {
                await DeleteAvatar(user.Profile.AvatarUrl);
                _logger.LogInformation("Deleted avatar for user {UserId}", user.Id);
            }

            if (user.Role == UserRole.Initiator)
            {
                var ownedProjects = await _projectService.GetProjectsByOwner(user.Id);
                if (ownedProjects.IsSuccessful && ownedProjects.Data.Any())
                {
                    foreach (var project in ownedProjects.Data)
                    {
                        _logger.LogInformation("Deleting project {ProjectId} owned by user {UserId}", project.Id, user.Id);
                        await _projectService.DeleteProject(project.Id);
                    }
                }
            }

            if (user.Role == UserRole.Volunteer)
            {
                var skills = await _skillService.GetSkillsForVolunteer(user.Id);
                if (skills.IsSuccessful)
                {
                    foreach (var vs in skills.Data)
                    {
                        _logger.LogInformation("Removing VolunteerSkill {SkillId} from user {UserId}", vs.SkillId, user.Id);
                        await _skillService.RemoveVolunteerSkill(user.Id, vs.SkillId);
                    }
                }

                var projects = await _projectService.GetAllProjects();
                if (projects.IsSuccessful)
                {
                    foreach (var proj in projects.Data.Where(p => p.VolunteerIds.Contains(user.Id)))
                    {
                        _logger.LogInformation("Removing user {UserId} from project {ProjectId}", user.Id, proj.Id);
                        await _projectService.RemoveVolunteerFromProject(proj.Id, user.Id, "system", true);
                    }
                }
            }

            var participations = await _unitOfWork.Participations.FindAsync(p => p.UserId == user.Id);
            foreach (var p in participations)
            {
                _logger.LogInformation("Removing user {UserId} from participation {ParticipationId}", user.Id, p.Id);
                await _unitOfWork.Participations.DeleteAsync(p.Id);
            }

            await _unitOfWork.Users.DeleteAsync(user.Id);
            _logger.LogInformation("User {UserId} fully deleted with cascade", user.Id);

            return new Result(true);
        }

        public async Task<Result> DeleteUserProfile()
        {
            _logger.LogInformation("Deleting current user's profile");

            var result = await GetCurrentUser();
            if (!result.IsSuccessful || result.Data == null)
            {
                _logger.LogWarning("User not found");
                return new Result(false);
            }

            var user = result.Data;

            if (!string.IsNullOrEmpty(user.Profile?.AvatarUrl))
            {
                await DeleteAvatar(user.Profile.AvatarUrl);
            }

            user.Profile = null;
            await _unitOfWork.Users.UpdateAsync(user.Id, user);

            return new Result(true);
        }

        private async Task DeleteAvatar(string avatarUrl)
        {
            try
            {
                var blobName = GetBlobNameFromUrl(avatarUrl);
                await _blobService.DeleteAsync(blobName);
                _logger.LogInformation("Avatar deleted: {BlobName}", blobName);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error deleting avatar: {Message}", ex.Message);
            }
        }

        private static string GetBlobNameFromUrl(string url)
        {
            return new Uri(url).Segments.Last();
        }

        private static bool IsProfileValid(UserProfile profile, out string error)
        {
            error = "";

            if (profile.DateOfBirth is { } dob)
            {
                if (dob > DateTime.UtcNow)
                {
                    error = "Date of birth is in the future.";
                    return false;
                }

                var age = DateTime.UtcNow.Year - dob.Year;
                if (dob > DateTime.UtcNow.AddYears(-age)) age--;

                if (age < 14)
                {
                    error = "User must be at least 14 years old.";
                    return false;
                }

                if (age > 125)
                {
                    error = "User age exceeds 125 years.";
                    return false;
                }
            }

            return true;
        }

        public async Task<Result<string>> UpdateUserAvatarAsync(IFormFile avatarFile)
        {
            _logger.LogInformation("Uploading avatar and updating user profile");

            var userResult = await GetCurrentUser();
            if (!userResult.IsSuccessful || userResult.Data is null)
                return new Result<string>(false);

            var user = userResult.Data;

            if (!string.IsNullOrEmpty(user.Profile?.AvatarUrl))
                await DeleteAvatar(user.Profile.AvatarUrl);

            var extension = Path.GetExtension(avatarFile.FileName);
            var fileName = $"avatars/{Guid.NewGuid()}{extension}";

            using var stream = avatarFile.OpenReadStream();
            var avatarUrl = await _blobService.UploadAsync(stream, fileName, avatarFile.ContentType);

            user.Profile ??= new UserProfile();
            user.Profile.AvatarUrl = avatarUrl;

            await _unitOfWork.Users.UpdateAsync(user.Id, user);

            return new Result<string>(true, avatarUrl);
        }

        public async Task<Result> DeleteUserById(string userId)
        {
            _logger.LogInformation("Starting cascade deletion for user {UserId}", userId);

            var user = await _unitOfWork.Users.GetByIdAsync(userId);
            if (user == null)
            {
                _logger.LogWarning("User {UserId} not found", userId);
                return new Result(false);
            }

            if (!string.IsNullOrEmpty(user.Profile?.AvatarUrl))
            {
                await DeleteAvatar(user.Profile.AvatarUrl);
                _logger.LogInformation("Deleted avatar for user {UserId}", userId);
            }

            if (user.Role == UserRole.Initiator || user.Role == UserRole.Admin)
            {
                var ownedProjects = await _projectService.GetProjectsByOwner(userId);
                if (ownedProjects.IsSuccessful && ownedProjects.Data.Any())
                {
                    foreach (var project in ownedProjects.Data)
                    {
                        _logger.LogInformation("Deleting project {ProjectId} owned by user {UserId}", project.Id, userId);
                        await _projectService.DeleteProject(project.Id);
                    }
                }
            }

            if (user.Role == UserRole.Volunteer)
            {
                var skills = await _skillService.GetSkillsForVolunteer(userId);
                if (skills.IsSuccessful)
                {
                    foreach (var vs in skills.Data)
                    {
                        _logger.LogInformation("Removing VolunteerSkill {SkillId} from user {UserId}", vs.SkillId, userId);
                        await _skillService.RemoveVolunteerSkill(userId, vs.SkillId);
                    }
                }

                var projects = await _projectService.GetAllProjects();
                if (projects.IsSuccessful)
                {
                    foreach (var proj in projects.Data.Where(p => p.VolunteerIds.Contains(userId)))
                    {
                        _logger.LogInformation("Removing user {UserId} from project {ProjectId}", userId, proj.Id);
                        await _projectService.RemoveVolunteerFromProject(proj.Id, userId, "system", true);
                    }
                }
            }

            var participations = await _unitOfWork.Participations.FindAsync(p => p.UserId == userId);
            foreach (var p in participations)
            {
                _logger.LogInformation("Removing user {UserId} from participation {ParticipationId}", userId, p.Id);
                await _unitOfWork.Participations.DeleteAsync(p.Id);
            }

            await _unitOfWork.Users.DeleteAsync(userId);
            _logger.LogInformation("User {UserId} fully deleted with cascade", userId);

            return new Result(true);
        }

        public async Task<Result<List<User>>> GetAllUsers()
        {
            try
            {
                var result = await _repository.GetAllAsync();

                var filtered = result.Where(u => Enum.IsDefined(typeof(UserRole), u.Role)).ToList();

                return new Result<List<User>>(true, filtered);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in GetAll: {Message}", ex.Message);
                return new Result<List<User>>(false);
            }
        }

    }
}
