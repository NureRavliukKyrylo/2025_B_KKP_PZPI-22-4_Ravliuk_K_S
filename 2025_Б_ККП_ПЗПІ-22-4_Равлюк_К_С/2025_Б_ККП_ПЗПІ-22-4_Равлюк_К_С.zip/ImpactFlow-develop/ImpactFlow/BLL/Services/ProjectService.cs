﻿using BLL.Interfaces;
using Core.Enums;
using Core.Models;
using DAL.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace BLL.Services
{
    public class ProjectService : GenericService<Project>, IProjectService
    {
        private readonly ILogger<ProjectService> _logger;
        private readonly Dictionary<ProjectSortingParams, Func<IQueryable<Project>, IOrderedQueryable<Project>>> _sortingDictionary =
            new()
            {
                { ProjectSortingParams.Default, q => q.OrderBy(p => p.Title) },
                { ProjectSortingParams.Newest, q => q.OrderByDescending(p => p.CreatedAt) },
                { ProjectSortingParams.TitleAsc, q => q.OrderBy(p => p.Title) },
                { ProjectSortingParams.TitleDesc, q => q.OrderByDescending(p => p.Title) },
                { ProjectSortingParams.EndingSoon, q => q.OrderBy(p => p.EndAt) }
            };
        private static double GetDistanceInKm(double lat1, double lon1, double lat2, double lon2)
        {
            double R = 6371; // Earth radius in km
            double dLat = DegreesToRadians(lat2 - lat1);
            double dLon = DegreesToRadians(lon2 - lon1);

            double a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                       Math.Cos(DegreesToRadians(lat1)) * Math.Cos(DegreesToRadians(lat2)) *
                       Math.Sin(dLon / 2) * Math.Sin(dLon / 2);

            double c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
            return R * c;
        }

        private static double DegreesToRadians(double deg) => deg * Math.PI / 180;

        public ProjectService(
            UnitOfWork unitOfWork,
            ILogger<ProjectService> logger,
            IHttpContextAccessor contextAccessor)
            : base(unitOfWork, unitOfWork.Projects, contextAccessor)
        {
            _logger = logger;
        }

        public async Task<Result<string>> CreateProject(Project project)
        {
            _logger.LogInformation("Creating project");

            if (project == null)
            {
                _logger.LogError("Failed to create project - project is null");
                return new Result<string>(false);
            }

            try
            {
                project.Id = null!;
                project.CreatedAt = DateTime.UtcNow;
                project.EndAt = project.EndAt == default ? DateTime.UtcNow.AddMonths(1) : project.EndAt;
                project.VolunteerIds = new List<string>();

                await _repository.AddAsync(project);

                _logger.LogInformation("Project created successfully with ID {Id}", project.Id);
                return new Result<string>(true, project.Id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to create project: {Error}", ex.Message);
                return new Result<string>(false);
            }
        }

        public async Task<Result> UpdateProject(Project project)
        {
            _logger.LogInformation("Updating project with ID {Id}", project.Id);

            if (project == null)
            {
                _logger.LogError("Update failed - project is null");
                return new Result(false);
            }

            try
            {
                await _repository.UpdateAsync(project.Id, project);
                _logger.LogInformation("Project {Id} updated successfully", project.Id);
                return new Result(true);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to update project {Id}: {Error}", project.Id, ex.Message);
                return new Result(false);
            }
        }

        public async Task<Result> DeleteProject(string id)
        {
            _logger.LogInformation("Starting cascade deletion for project {ProjectId}", id);

            var project = await _repository.GetByIdAsync(id);
            if (project == null)
            {
                _logger.LogWarning("Project {ProjectId} not found", id);
                return new Result(false);
            }

            var participationsResult = await GetAllParticipationsForProject(id);
            if (participationsResult.IsSuccessful)
            {
                foreach (var participation in participationsResult.Data)
                {
                    var deleteResult = await DeleteParticipation(participation.Id);
                    if (!deleteResult.IsSuccessful)
                        _logger.LogWarning("Failed to delete participation {ParticipationId}", participation.Id);
                }
            }

            await _repository.DeleteAsync(id);
            _logger.LogInformation("Project {ProjectId} deleted successfully", id);

            return new Result(true);
        }

        public async Task<Result> DeleteParticipation(string participationId)
        {
            _logger.LogInformation("Deleting participation {ParticipationId}", participationId);

            try
            {
                var participation = await _unitOfWork.Participations.GetByIdAsync(participationId);
                if (participation == null)
                {
                    _logger.LogWarning("Participation {ParticipationId} not found", participationId);
                    return new Result(false);
                }

                var project = await _repository.GetByIdAsync(participation.ProjectId);
                if (project != null && project.VolunteerIds.Contains(participation.UserId))
                {
                    project.VolunteerIds.Remove(participation.UserId);
                    await _repository.UpdateAsync(project.Id, project);
                    _logger.LogInformation("Removed user {UserId} from project {ProjectId} volunteer list", participation.UserId, project.Id);
                }

                await _unitOfWork.Participations.DeleteAsync(participationId);
                _logger.LogInformation("Deleted participation {ParticipationId}", participationId);

                return new Result(true);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to delete participation {ParticipationId}: {Error}", participationId, ex.Message);
                return new Result(false);
            }
        }

        public async Task<Result<List<Project>>> GetProjectsByOwner(string ownerId)
        {
            _logger.LogInformation("Retrieving projects for owner {OwnerId}", ownerId);

            try
            {
                var projects = await _repository.FindAsync(p => p.OwnerId == ownerId);
                _logger.LogInformation("Successfully retrieved {Count} projects for owner {OwnerId}", projects.Count, ownerId);
                return new Result<List<Project>>(true, projects);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to retrieve projects for owner {OwnerId}: {Error}", ownerId, ex.Message);
                return new Result<List<Project>>(false);
            }
        }

        public async Task<Result<List<Project>>> GetAllProjects(
             ProjectSortingParams orderBy = ProjectSortingParams.Default,
             DateTime? endBefore = null,
             List<string>? categoryIds = null,
             double? radiusKm = null,
             string? userId = null,
             string? search = null)
        {
            _logger.LogInformation("Retrieving all projects with filters");

            try
            {
                var projects = (await _repository.GetAllAsync()).AsQueryable();

                projects = projects.Where(p => p.EndAt >= DateTime.UtcNow);

                if (!string.IsNullOrWhiteSpace(search))
                {
                    projects = projects.Where(p =>
                        p.Title.Contains(search, StringComparison.OrdinalIgnoreCase));
                }

                if (endBefore != null)
                {
                    projects = projects.Where(p => p.EndAt <= endBefore.Value);
                }

                if (categoryIds != null && categoryIds.Any())
                {
                    projects = projects.Where(p => categoryIds.All(id => p.CategoryIds.Contains(id)));
                }

                if (radiusKm.HasValue && !string.IsNullOrEmpty(userId))
                {
                    var user = await _unitOfWork.Users.GetByIdAsync(userId);
                    var userCoord = user?.Profile?.Coordinates?.Coordinates;

                    if (userCoord != null)
                    {
                        projects = projects.Where(p => p.Location.Any(loc =>
                            loc.Location != null &&
                            GetDistanceInKm(
                                userCoord.Latitude, userCoord.Longitude,
                                loc.Location.Coordinates.Latitude, loc.Location.Coordinates.Longitude
                            ) <= radiusKm.Value));
                    }
                    else
                    {
                        _logger.LogWarning("User {UserId} has no coordinates; skipping distance filter", userId);
                        return new Result<List<Project>>(
                                    false,
                                    errorCode: 400
                                );
                    }
                }

                if (_sortingDictionary.TryGetValue(orderBy, out var sorter) && sorter != null)
                {
                    projects = sorter(projects);
                }

                var result = projects.ToList();
                _logger.LogInformation("Successfully returned {Count} projects", result.Count);
                return new Result<List<Project>>(true, result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to retrieve filtered projects: {Error}", ex.Message);
                return new Result<List<Project>>(false);
            }
        }

        public async Task<Result> SignUpVolunteer(string projectId, string userId)
        {
            _logger.LogInformation("Starting sign-up process for user {UserId} on project {ProjectId}", userId, projectId);

            var project = await _repository.GetByIdAsync(projectId);
            if (project == null)
            {
                _logger.LogWarning("Project with ID {ProjectId} not found", projectId);
                return new Result(false);
            }

            _logger.LogDebug("Found project: {Title}", project.Title);

            var participations = await _unitOfWork.Participations.FindAsync(p => p.ProjectId == projectId && p.UserId == userId);
            _logger.LogDebug("Found {Count} participation records for user {UserId} in project {ProjectId}", participations.Count, userId, projectId);

            var activeParticipation = participations.FirstOrDefault(p =>
                p.LeaveDates == null || p.LeaveDates.Count < p.JoinDates.Count);

            if (activeParticipation != null)
            {
                _logger.LogWarning("User {UserId} is already actively participating in project {ProjectId}", userId, projectId);
                return new Result(false);
            }

            Participation participation;

            if (participations.Any())
            {
                participation = participations.First();
                _logger.LogInformation("Reusing existing inactive participation record {ParticipationId}", participation.Id);

                participation.JoinDates.Add(DateTime.UtcNow);
                _logger.LogDebug("Added new JoinDate: {Date}", participation.JoinDates.Last());

                await _unitOfWork.Participations.UpdateAsync(participation.Id, participation);
                _logger.LogInformation("Participation record {ParticipationId} updated", participation.Id);
            }
            else
            {
                participation = new Participation
                {
                    ProjectId = projectId,
                    UserId = userId,
                    JoinDates = new List<DateTime> { DateTime.UtcNow }
                };

                await _unitOfWork.Participations.AddAsync(participation);
                _logger.LogInformation("Created new participation record for user {UserId} in project {ProjectId}", userId, projectId);
            }

            if (!project.VolunteerIds.Contains(userId))
            {
                project.VolunteerIds.Add(userId);
                await _repository.UpdateAsync(project.Id, project);
                _logger.LogInformation("Added user {UserId} to project.VolunteerIds list", userId);
            }
            else
            {
                _logger.LogDebug("User {UserId} already present in project.VolunteerIds list", userId);
            }

            _logger.LogInformation("User {UserId} successfully signed up for project {ProjectId}", userId, projectId);
            return new Result(true);
        }

        public async Task<Result<List<Project>>> GetEnrolledProjects(string userId)
        {
            _logger.LogInformation("Retrieving enrolled projects for user {UserId}", userId);

            try
            {
                var participations = await _unitOfWork.Participations.FindAsync(p =>
                    p.UserId == userId &&
                    (p.LeaveDates == null || p.LeaveDates.Count < p.JoinDates.Count));

                if (!participations.Any())
                {
                    _logger.LogInformation("No active participations found for user {UserId}", userId);
                    return new Result<List<Project>>(true, new List<Project>());
                }

                var projectIds = participations.Select(p => p.ProjectId).Distinct().ToList();
                var allProjects = await _repository.FindAsync(p => projectIds.Contains(p.Id));

                _logger.LogInformation("Found {Count} active enrolled projects for user {UserId}", allProjects.Count, userId);
                return new Result<List<Project>>(true, allProjects);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to retrieve enrolled projects for user {UserId}: {Error}", userId, ex.Message);
                return new Result<List<Project>>(false);
            }
        }

        public async Task<Result> RemoveVolunteerFromProject(string projectId, string volunteerId, string currentUserId, bool isAdmin)
        {
            _logger.LogInformation("User {CurrentUser} attempts to remove volunteer {VolunteerId} from project {ProjectId}",
                currentUserId, volunteerId, projectId);

            var project = await _repository.GetByIdAsync(projectId);
            if (project == null)
            {
                _logger.LogWarning("Project {ProjectId} not found", projectId);
                return new Result(false);
            }

            var participation = (await _unitOfWork.Participations.FindAsync(p =>
        p.ProjectId == projectId && p.UserId == volunteerId)).FirstOrDefault();

            if (participation == null)
            {
                _logger.LogWarning("Volunteer {VolunteerId} not enrolled in project {ProjectId}", volunteerId, projectId);
                return new Result(false);
            }

            var isOwner = project.OwnerId == currentUserId;
            var isSelf = volunteerId == currentUserId;

            if (!(isAdmin || isOwner || isSelf))
            {
                _logger.LogWarning("User {CurrentUser} is not authorized to remove volunteer {VolunteerId} from project {ProjectId}",
                    currentUserId, volunteerId, projectId);
                return new Result(false);
            }

            participation.LeaveDates ??= new List<DateTime>();
            participation.LeaveDates.Add(DateTime.UtcNow);

            await _unitOfWork.Participations.UpdateAsync(participation.Id, participation);

            if (project.VolunteerIds.Contains(volunteerId))
            {
                project.VolunteerIds.Remove(volunteerId);
                await _repository.UpdateAsync(project.Id, project);
                _logger.LogInformation("Volunteer {VolunteerId} also removed from project.VolunteerIds", volunteerId);
            }

            _logger.LogInformation("Volunteer {VolunteerId} removed from project {ProjectId}", volunteerId, projectId);
            return new Result(true);
        }

        public async Task<Result<List<Participation>>> GetActiveParticipationsForUser(string userId)
        {
            _logger.LogInformation("Getting active participations for volunteer {UserId}", userId);

            try
            {
                var participations = await _unitOfWork.Participations.FindAsync(p =>
                    p.UserId == userId &&
                    (p.LeaveDates == null || p.JoinDates.Count > p.LeaveDates.Count));

                return new Result<List<Participation>>(true, participations);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error retrieving participations for user {UserId}: {Error}", userId, ex.Message);
                return new Result<List<Participation>>(false);
            }
        }

        public async Task<Result<List<Participation>>> GetActiveParticipationsForOwner(string ownerId)
        {
            _logger.LogInformation("Getting active participations in projects owned by {OwnerId}", ownerId);

            try
            {
                var ownedProjects = await _repository.FindAsync(p => p.OwnerId == ownerId);
                var ownedProjectIds = ownedProjects.Select(p => p.Id).ToList();

                if (!ownedProjectIds.Any())
                    return new Result<List<Participation>>(true, new List<Participation>());

                var participations = await _unitOfWork.Participations.FindAsync(p =>
                    ownedProjectIds.Contains(p.ProjectId) &&
                    (p.LeaveDates == null || p.JoinDates.Count > p.LeaveDates.Count));

                return new Result<List<Participation>>(true, participations);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error retrieving participations for owner {OwnerId}: {Error}", ownerId, ex.Message);
                return new Result<List<Participation>>(false);
            }
        }

        public async Task<Result<List<Participation>>> GetAllParticipationsForProject(string projectId)
        {
            _logger.LogInformation("Getting all participations for project {ProjectId}", projectId);

            try
            {
                var project = await _repository.GetByIdAsync(projectId);
                if (project == null)
                {
                    _logger.LogWarning("Project {ProjectId} not found", projectId);
                    return new Result<List<Participation>>(false);
                }

                var participations = await _unitOfWork.Participations.FindAsync(p => p.ProjectId == projectId);
                _logger.LogInformation("Found {Count} participations for project {ProjectId}", participations.Count, projectId);

                return new Result<List<Participation>>(true, participations);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to retrieve participations for project {ProjectId}: {Error}", projectId, ex.Message);
                return new Result<List<Participation>>(false);
            }
        }

        public async Task<Result> UpdateParticipationRole(string projectId, string volunteerId, string newRole, string currentUserId, bool isAdmin)
        {
            _logger.LogInformation("Updating volunteer role in project {ProjectId} by user {CurrentUserId}", projectId, currentUserId);

            var project = await _repository.GetByIdAsync(projectId);
            if (project == null)
            {
                _logger.LogWarning("Project {ProjectId} not found", projectId);
                return new Result(false);
            }

            var isOwner = project.OwnerId == currentUserId;
            if (!(isAdmin || isOwner))
            {
                _logger.LogWarning("User {CurrentUserId} not authorized to assign roles in project {ProjectId}", currentUserId, projectId);
                return new Result(false);
            }

            var participation = (await _unitOfWork.Participations.FindAsync(p =>
                p.ProjectId == projectId && p.UserId == volunteerId)).FirstOrDefault();

            if (participation == null)
            {
                _logger.LogWarning("Participation not found for volunteer {VolunteerId} in project {ProjectId}", volunteerId, projectId);
                return new Result(false);
            }

            participation.RoleInProject = newRole;
            await _unitOfWork.Participations.UpdateAsync(participation.Id, participation);

            _logger.LogInformation("Updated volunteer {VolunteerId} role in project {ProjectId} to {Role}", volunteerId, projectId, newRole);
            return new Result(true);
        }

        public async Task<Result> LeaveProject(string projectId, string userId)
        {
            _logger.LogInformation("User {UserId} attempts to leave project {ProjectId}", userId, projectId);

            var project = await _repository.GetByIdAsync(projectId);
            if (project == null)
            {
                _logger.LogWarning("Project {ProjectId} not found", projectId);
                return new Result(false);
            }

            var participation = (await _unitOfWork.Participations.FindAsync(p =>
                p.ProjectId == projectId && p.UserId == userId)).FirstOrDefault();

            if (participation == null)
            {
                _logger.LogWarning("No active participation found for user {UserId} in project {ProjectId}", userId, projectId);
                return new Result(false);
            }

            if (participation.LeaveDates == null)
                participation.LeaveDates = new List<DateTime>();

            if (participation.LeaveDates.Count >= participation.JoinDates.Count)
            {
                _logger.LogWarning("User {UserId} already left project {ProjectId}", userId, projectId);
                return new Result(false);
            }

            participation.LeaveDates.Add(DateTime.UtcNow);
            await _unitOfWork.Participations.UpdateAsync(participation.Id, participation);

            if (project.VolunteerIds.Contains(userId))
            {
                project.VolunteerIds.Remove(userId);
                await _repository.UpdateAsync(project.Id, project);
                _logger.LogInformation("Removed user {UserId} from project volunteer list", userId);
            }

            _logger.LogInformation("User {UserId} left project {ProjectId}", userId, projectId);
            return new Result(true);
        }
    }
}
