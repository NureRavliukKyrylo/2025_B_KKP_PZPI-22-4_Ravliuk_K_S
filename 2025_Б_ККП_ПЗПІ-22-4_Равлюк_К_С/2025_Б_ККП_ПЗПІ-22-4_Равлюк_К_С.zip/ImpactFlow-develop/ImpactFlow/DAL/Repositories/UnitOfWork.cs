﻿using Core.Models;
using DAL.Context;
using Microsoft.Extensions.Logging;

namespace DAL.Repositories
{
    public class UnitOfWork
    {
        private readonly MongoContext _context;
        private readonly ILoggerFactory _loggerFactory;

        private MongoRepository<User>? _userRepository;
        private MongoRepository<Project>? _projectRepository;
        private MongoRepository<ProjectTask>? _taskRepository;
        private MongoRepository<Event>? _eventRepository;
        private MongoRepository<Participation>? _participationRepository;
        private MongoRepository<EventParticipation>? _eventParticipationRepository;
        private MongoRepository<Review>? _reviewRepository;
        private MongoRepository<Badge>? _badgeRepository;
        private MongoRepository<UserBadge>? _userBadgeRepository;
        private MongoRepository<Skill>? _skillRepository;
        private MongoRepository<VolunteerSkill>? _volunteerSkillRepository;
        private MongoRepository<Category>? _categoryRepository;

        public UnitOfWork(MongoContext context, ILoggerFactory loggerFactory)
        {
            _context = context;
            _loggerFactory = loggerFactory;
        }

        public MongoRepository<User> Users =>
            _userRepository ??= new MongoRepository<User>(_context, "users");

        public MongoRepository<Project> Projects =>
            _projectRepository ??= new MongoRepository<Project>(_context, "projects");

        public MongoRepository<ProjectTask> Tasks =>
            _taskRepository ??= new MongoRepository<ProjectTask>(_context, "tasks");

        public MongoRepository<Event> Events =>
            _eventRepository ??= new MongoRepository<Event>(_context, "events");

        public MongoRepository<Participation> Participations =>
            _participationRepository ??= new MongoRepository<Participation>(_context, "participations");

        public MongoRepository<EventParticipation> EventParticipations =>
            _eventParticipationRepository ??= new MongoRepository<EventParticipation>(_context, "eventParticipations");

        public MongoRepository<Review> Reviews =>
            _reviewRepository ??= new MongoRepository<Review>(_context, "reviews");

        public MongoRepository<Badge> Badges =>
            _badgeRepository ??= new MongoRepository<Badge>(_context, "badges");

        public MongoRepository<UserBadge> UserBadges =>
            _userBadgeRepository ??= new MongoRepository<UserBadge>(_context, "userBadges");

        public MongoRepository<Skill> Skills =>
            _skillRepository ??= new MongoRepository<Skill>(_context, "skills");

        public MongoRepository<VolunteerSkill> VolunteerSkills =>
            _volunteerSkillRepository ??= new MongoRepository<VolunteerSkill>(_context, "volunteerSkills");

        public MongoRepository<Category> Categories =>
            _categoryRepository ??= new MongoRepository<Category>(_context, "categories");

    }
}
